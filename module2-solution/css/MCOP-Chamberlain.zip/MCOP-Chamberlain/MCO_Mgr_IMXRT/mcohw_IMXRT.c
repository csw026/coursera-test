/**************************************************************************
MODULE:    MCOHW_LPC1
CONTAINS:  Driver implementation for NXP i.MX RT 10xx derivatives with
           CAN interface. Compiled and Tested with MCUXpresso 10.2.
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-04-13 18:19:09 +0200 (Fri, 13 Apr 2018) $
           $LastChangedRevision: 4276 $
***************************************************************************/

#include "mcohw.h"
#include "canfifo.h"
#include <string.h>

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* Select 80M clock divided by USB1 PLL (480 MHz) as master flexcan clock source */
#define FLEXCAN_CLOCK_SOURCE_SELECT (2U)
/* Clock divider for master flexcan clock source */
#define FLEXCAN_CLOCK_SOURCE_DIVIDER (3U)
/* Get frequency of flexcan clock */
#define CAN_CLK_FREQ ((CLOCK_GetFreq(kCLOCK_Usb1PllClk) / 6) / (FLEXCAN_CLOCK_SOURCE_DIVIDER + 1U))

//#define TIMER_USE_PIT

#ifdef TIMER_USE_PIT
/* Get source clock for PIT driver */
#define PIT_SOURCE_CLOCK (CLOCK_GetFreq(kCLOCK_OscClk))
#define TIMER_IRQHandler PIT_IRQHandler
#else // use GPT (more precise)
#define GPT_SELECT GPT2
#define GPT_IRQ GPT2_IRQn
#define TIMER_IRQHandler GPT2_IRQHandler
/* Select IPG Clock as PERCLK_CLK clock source */
#define GPT_CLOCK_SOURCE_SELECT (0U)
/* Clock divider for PERCLK_CLK clock source */
#define GPT_CLOCK_DIVIDER_SELECT (0U)
/* Get source clock for GPT driver (GPT prescaler = 0) */
#define GPT_CLK_FREQ (CLOCK_GetFreq(kCLOCK_IpgClk) / (GPT_CLOCK_DIVIDER_SELECT + 1U))
#endif

// On the i.MX RT 10xx several CAN ports are supported, this is the number
// of the CAN port used (1-2)
// The CAN interface/port to use with the stack

#ifdef MCO_INSTANCE  // multi-instance port configuration
  #if   MCO_INSTANCE == 1
    #define CAN_PORT_NUM 1
  #elif MCO_INSTANCE == 2
    #define CAN_PORT_NUM 2
  #endif
#else
  #define CAN_PORT_NUM 2 // Select 1 or 2 as default
#endif

#if CAN_PORT_NUM == 1
  #define CAN_PORT CAN1
  #define RX_MESSAGE_BUFFER_NUM (9)
  #define TX_MESSAGE_BUFFER_NUM (8)
#elif CAN_PORT_NUM == 2
  #define CAN_PORT CAN2
  #define RX_MESSAGE_BUFFER_NUM (11)
  #define TX_MESSAGE_BUFFER_NUM (10)
#else
  #error CAN port not supported!
#endif

#ifndef MCO_INSTANCE
  // Declare, for usage in IRQ Vector
  #ifdef __ARMCC_VERSION
    // ARM compiler version
    void __irq PIT_IRQHandler (void);
  #else
    // GNU compiler verison
    #define __irq
    void TIMER_IRQHandler (void) __attribute__ ((interrupt));
  #endif
#endif


/**************************************************************************
GLOBAL VARIABLES
***************************************************************************/ 

// This structure holds all node specific configuration
extern MCO_CONFIG MEM_FAR gMCOConfig;

// Global timer/counter variable, incremented every millisecond
UNSIGNED16 volatile gTimCnt = 0;


/**************************************************************************
LOCAL VARIABLES
***************************************************************************/ 
static flexcan_handle_t mFlexcanHandle;
static volatile bool mTxComplete = true;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
static flexcan_fd_frame_t mRxFrame;
#else
static flexcan_frame_t mRxFrame;
#endif


/**************************************************************************
LOCAL FUNCTIONS
***************************************************************************/ 
static void MCOHW_CANISR_Rx (void);
static void MCOHW_CANISR_Err (UNSIGNED8, UNSIGNED32);


/**************************************************************************
PUBLIC FUNCTIONS
***************************************************************************/ 

/**************************************************************************
DOES:    This function returns the global status variable.
CHANGES: The status can be changed anytime by this module, for example from 
         within an interrupt service routine or by any of the other 
         functions in this module.
BITS:    0: INIT - set to 1 after a completed initialization
                   left 0 if not yet inited or init failed
         1: CERR - set to 1 if a CAN bit or frame error occurred
         2: ERPA - set to 1 if a CAN "error passive" occurred
         3: RXOR - set to 1 if a receive queue overrun occurred
         4: TXOR - set to 1 if a transmit queue overrun occurred
         5: Reserved
         6: TXBSY - set to 1 if Transmit queue is not empty
         7: BOFF - set to 1 if a CAN "bus off" error occurred
**************************************************************************/
UNSIGNED8 MCOHW_GetStatus (
  void
  )
{
  // Transmit FIFO or buffer in use?
  if ((CANTXFIFO_GetOutPtr() != 0) || (!mTxComplete))
  { // Busy transmitting
    gMCOConfig.HWStatus |= HW_TXBSY;
  }
  else
  { // all Tx buffers empty
    gMCOConfig.HWStatus &= ~HW_TXBSY;
  }

  return gMCOConfig.HWStatus;
}


/**************************************************************************
DOES:    This function implements a CAN receive queue. With each
         function call a message is pulled from the queue.
RETURNS: 1 Message was pulled from receive queue
         0 Queue empty, no message received
**************************************************************************/
UNSIGNED8 MCOHW_PullMessage (
  MEM_FAR CAN_MSG *pReceiveBuf
  )
{
MEM_FAR CAN_MSG *pSrc;

  // Check if message is in Rx FIFO  
  pSrc = CANRXFIFO_GetOutPtr();
  if (pSrc != 0)
  {
    // copy message
    MEM_CPY_FAR(pReceiveBuf,pSrc,sizeof(CAN_MSG));
    // copying complete, update FIFO
    CANRXFIFO_OutDone();
    return TRUE; // msg received
  }
  return FALSE; // no msg rcvd 
}


#if MGR_MONITOR_ALL_NODES
/**************************************************************************
DOES:    This function is used by the manager to poll messages that are
         needed by the manager
RETURNS: TRUE or FALSE, if no message was received
**************************************************************************/
UNSIGNED8 MCOHWMGR_PullMessage (
  MEM_FAR CAN_MSG *pReceiveBuf // buffer to witch a received message is copied
  )
{ 
MEM_FAR CAN_MSG *pSrc;

  // Check if message is in Rx FIFO  
  pSrc = CANMGRFIFO_GetOutPtr();
  if (pSrc != 0)
  {
    // copy message
    memcpy(pReceiveBuf,pSrc,sizeof(CAN_MSG));
    // copying complete, update FIFO
    CANMGRFIFO_OutDone();
    return TRUE; // msg received
  }
  return FALSE; // no msg rcvd 
}
#endif // MGR_MONITOR_ALL_NODES


/**************************************************************************
DOES: If there is something in the transmit queue, and if the transmit
      buffer is available, copy next message from queue to transmit buffer
***************************************************************************/ 
void MCOHW_CheckTxQueue (
  void
  )
{
MEM_FAR CAN_MSG *pMsg;
UNSIGNED8 *pCandata;
flexcan_mb_transfer_t txXfer;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
flexcan_fd_frame_t frame;
#else
flexcan_frame_t frame;
#endif

  // Get next message from FIFO
  pMsg = CANTXFIFO_GetOutPtr();

  if (mTxComplete && (pMsg != 0))
  { // Transmit channel is available and message is in queue
    
    mTxComplete = false;

    frame.id = FLEXCAN_ID_STD(pMsg->ID);
    frame.format = kFLEXCAN_FrameFormatStandard;
    frame.type = kFLEXCAN_FrameTypeData;
    frame.length = pMsg->LEN;
    // Write data bytes
    pCandata = &(pMsg->BUF[0]);
    frame.dataByte0 = *pCandata++;
    frame.dataByte1 = *pCandata++;
    frame.dataByte2 = *pCandata++;
    frame.dataByte3 = *pCandata++;
    frame.dataByte4 = *pCandata++;
    frame.dataByte5 = *pCandata++;
    frame.dataByte6 = *pCandata++;
    frame.dataByte7 = *pCandata;
    txXfer.mbIdx = TX_MESSAGE_BUFFER_NUM;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
    txXfer.framefd = &frame;
    FLEXCAN_TransferFDSendNonBlocking(CAN_PORT, &mFlexcanHandle, &txXfer);
#else
    txXfer.frame = &frame;
    FLEXCAN_TransferSendNonBlocking(CAN_PORT, &mFlexcanHandle, &txXfer);
#endif

    // Update Out pointer
    CANTXFIFO_OutDone();
  }

  return;
}


/**************************************************************************
DOES:    Adding a CAN message to the transmit queue
RETURNS: TRUE or FALSE if queue overrun
***************************************************************************/ 
UNSIGNED8 MCOHW_PushMessage (
  MEM_FAR CAN_MSG *pTransmitBuf // Data structure with message to be send
  )
{
MEM_FAR CAN_MSG *pDst; // Destination pointer
UNSIGNED8 ret_val = FALSE;

  // Get next message space available in FIFO
  RESOURCE_LOCK(RSRC_TXFIFO);
  pDst = CANTXFIFO_GetInPtr();
  if (pDst != 0)
  {
    // Copy message to transmit queue
    MEM_CPY_FAR(pDst,pTransmitBuf,sizeof(CAN_MSG));
    // Copy completed
    CANTXFIFO_InDone();
    ret_val = TRUE;
  }
  else
  {
    // Overrun occurred
    // Signal overrun to status variable
    gMCOConfig.HWStatus |= HW_TXOR;
  }
  RESOURCE_UNLOCK(RSRC_TXFIFO);
  return ret_val;
}


/**************************************************************************
DOES:    CAN error interrupt handler
**************************************************************************/
static void MCOHW_CANISR_Err (
  UNSIGNED8  err_type,     // 0: receive overflow, 1: other errors
  UNSIGNED32 error_flags   // flags depending on err_type
  )
{

  // INSERT APPLICATION SPECIFIC CODE AS NEEDED

  if (0u == err_type)
  { // Data overrun
    gMCOConfig.HWStatus |= HW_RXOR;
#if USE_LEDS
    gMCOConfig.LEDErr = LED_FLASH1;
#endif
  }
  else if (1u == err_type)
  {
    if (0ul != (error_flags & (kFLEXCAN_TxWarningIntFlag | kFLEXCAN_RxWarningIntFlag)))
    { // Error warning/Error passive
      gMCOConfig.HWStatus |= HW_ERPA;
#if USE_LEDS
      gMCOConfig.LEDErr = LED_FLASH1;
#endif
    }
    else if (0ul != (error_flags & kFLEXCAN_BusOffIntFlag))
    { // Bus off
      gMCOConfig.HWStatus |= HW_BOFF;
#if USE_LEDS
      gMCOConfig.LEDErr = LED_ON;
#endif
    }
    else if (0ul != (error_flags & (kFLEXCAN_ErrorIntFlag | kFLEXCAN_ErrorFlag)))
    { // Other errors
      gMCOConfig.HWStatus |= HW_CERR;
#if USE_LEDS
      gMCOConfig.LEDErr = LED_FLASH1;
#endif
    }
  }

  return;
}


/**************************************************************************
DOES:    CAN receive handler
**************************************************************************/
static void MCOHW_CANISR_Rx (
  void
  )
{
MEM_FAR CAN_MSG *pDst;
UNSIGNED8 *pDest;
UNSIGNED32 canid;
flexcan_mb_transfer_t rxXfer;

  if ((0u == mRxFrame.type) && (0u == mRxFrame.format))  // data frame and standard 11-bit id?
  {
    canid = (mRxFrame.id >> CAN_ID_STD_SHIFT);

#if MGR_MONITOR_ALL_NODES
    if ((MY_NMT_STATE == NMTSTATE_OP)
#if USE_MLSS_MANAGER || USE_LSS_MANAGER
      || IS_CANID_LSS_RESPONSE(canid)
#endif
     )
    { // only work on manager when operational or LSS response received
      if (
#if USE_MLSS_MANAGER || USE_LSS_MANAGER
           IS_CANID_LSS_RESPONSE(canid) || // LSS Response  
#endif
           IS_CAN_ID_EMERGENCY(canid) ||
           IS_CAN_ID_HEARTBEAT(canid) ||
           IS_CAN_ID_SDORESPONSE(canid)
         )
      { // This is a message for the CANopen Manager

        // initialize destination pointer into FIFO
        pDst = CANMGRFIFO_GetInPtr();

        if (pDst != 0)
        { // FIFO available
          // copy ID
          pDst->ID = canid;
          // copy DLC
          pDst->LEN = mRxFrame.length;
          // copy data
          pDest = &(pDst->BUF[0]);
          *pDest++ = mRxFrame.dataByte0;
          *pDest++ = mRxFrame.dataByte1;
          *pDest++ = mRxFrame.dataByte2;
          *pDest++ = mRxFrame.dataByte3;
          *pDest++ = mRxFrame.dataByte4;
          *pDest++ = mRxFrame.dataByte5;
          *pDest++ = mRxFrame.dataByte6;
          *pDest   = mRxFrame.dataByte7;
          // copying is all done
          CANMGRFIFO_InDone();
        }
        else
        { // overrun, message lost
          gMCOConfig.HWStatus |= HW_RXOR;
        }
      }
    }
#endif // MGR_MONITOR_ALL_NODES

    if (CANSWFILTER_Match(canid))
    { // Message needs to be received

      // initialize destination pointer into FIFO
      pDst = CANRXFIFO_GetInPtr();

      if (pDst != 0)
      { // FIFO available
        // copy ID
        pDst->ID = canid;
        // copy DLC
        pDst->LEN = mRxFrame.length;
        // copy data
        pDest = &(pDst->BUF[0]);
        *pDest++ = mRxFrame.dataByte0;
        *pDest++ = mRxFrame.dataByte1;
        *pDest++ = mRxFrame.dataByte2;
        *pDest++ = mRxFrame.dataByte3;
        *pDest++ = mRxFrame.dataByte4;
        *pDest++ = mRxFrame.dataByte5;
        *pDest++ = mRxFrame.dataByte6;
        *pDest   = mRxFrame.dataByte7;
        // copying is all done
        CANRXFIFO_InDone();
      }
      else
      { // overrun, message lost
        gMCOConfig.HWStatus |= HW_RXOR;
      }
      
    }
  }

  /* Start receive data through Rx Message Buffer. */
  rxXfer.mbIdx = RX_MESSAGE_BUFFER_NUM;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
  rxXfer.framefd = &mRxFrame;
  FLEXCAN_TransferFDReceiveNonBlocking(CAN_PORT, &mFlexcanHandle, &rxXfer);
#else
  rxXfer.frame = &mRxFrame;
  FLEXCAN_TransferReceiveNonBlocking(CAN_PORT, &mFlexcanHandle, &rxXfer);
#endif

  return;
}


/**************************************************************************
DOES:    CAN interrupt handler
**************************************************************************/
#ifndef MCO_INSTANCE
void CAN_CallbackHandler (
#else
  #if    MCO_INSTANCE == 1
void CAN_CallbackHandler_1 (
  #elif  MCO_INSTANCE == 2
void CAN_CallbackHandler_2 (
  #endif
#endif
  CAN_Type *base, flexcan_handle_t *handle, status_t status, uint32_t result, void *userData)
{
  switch (status)
  {
    case kStatus_FLEXCAN_TxBusy:
      break;

    case kStatus_FLEXCAN_TxIdle:
      if (TX_MESSAGE_BUFFER_NUM == result)
      {
        mTxComplete = true;
      }
      break;

    case kStatus_FLEXCAN_TxSwitchToRx:
      break;

    case kStatus_FLEXCAN_RxBusy:
      break;

    case kStatus_FLEXCAN_RxIdle:
      if (RX_MESSAGE_BUFFER_NUM == result)
      {
        MCOHW_CANISR_Rx();
      }
      break;

    case kStatus_FLEXCAN_RxOverflow:
      MCOHW_CANISR_Err(0, result);
      break;

    case kStatus_FLEXCAN_RxFifoBusy:
      break;

    case kStatus_FLEXCAN_RxFifoIdle:
      break;

    case kStatus_FLEXCAN_RxFifoOverflow:
      break;

    case kStatus_FLEXCAN_RxFifoWarning:
      break;

    case kStatus_FLEXCAN_ErrorStatus:
      MCOHW_CANISR_Err(1, result);
      break;

    case kStatus_FLEXCAN_UnHandled:
      break;

    default:
      break;
  }

  return;
}


/**************************************************************************
DOES:    Timer interrupt handler (1ms)
**************************************************************************/
#ifndef MCO_INSTANCE
void __irq TIMER_IRQHandler (void)
#else
void MCOHW_TimerISR (void)
#endif
{
  gTimCnt++; // increment global timer counter
  MCOHW_CheckTxQueue(); // check if something is in the Tx queue
#ifndef MCO_INSTANCE
#ifdef TIMER_USE_PIT
  /* Clear interrupt flag.*/
  PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
#else
  /* Clear interrupt flag.*/
  GPT_ClearStatusFlags(GPT_SELECT, kGPT_OutputCompare1Flag);
  /* Add for ARM errata 838869, affects Cortex-M4, Cortex-M4F, Cortex-M7, Cortex-M7F Store immediate overlapping
    exception return operation might vector to incorrect interrupt */
#if defined __CORTEX_M && (__CORTEX_M == 4U || __CORTEX_M == 7U)
  __DSB();
#endif
#endif
#endif
}


/**************************************************************************
DOES:    This function implements the initialization of the CAN interface.
RETURNS: 1 if init is completed 
         0 if init failed, bit INIT of MCOHW_GetStatus stays 0
**************************************************************************/
UNSIGNED8 MCOHW_Init (
  UNSIGNED16 baudrate
  )
{
flexcan_config_t flexcanConfig;
flexcan_rx_mb_config_t mbConfig;
flexcan_mb_transfer_t rxXfer;
#ifdef TIMER_USE_PIT
pit_config_t pitConfig;
#else
uint32_t gptFreq;
gpt_config_t gptConfig;
#endif

  switch (baudrate)
  {
    case 20:
    case 50:
    case 125:
    case 250:
    case 500:
    case 800:
    case 1000:
      break;
      
    default:
      return 0;  // Not supported
  }

  /*Clock setting for FLEXCAN*/
  CLOCK_SetMux(kCLOCK_CanMux, FLEXCAN_CLOCK_SOURCE_SELECT);
  CLOCK_SetDiv(kCLOCK_CanDiv, FLEXCAN_CLOCK_SOURCE_DIVIDER);

  /* Get FlexCAN module default Configuration. */
  /*
   * flexcanConfig.clkSrc = kFLEXCAN_ClkSrcOsc;
   * flexcanConfig.baudRate = 1000000U;
   * flexcanConfig.maxMbNum = 16;
   * flexcanConfig.enableLoopBack = false;
   * flexcanConfig.enableSelfWakeup = false;
   * flexcanConfig.enableIndividMask = false;
   * flexcanConfig.enableDoze = false;
   * flexcanConfig.timingConfig = timingConfig;
   */
  FLEXCAN_GetDefaultConfig(&flexcanConfig);

  /* Init FlexCAN module. */
#if (!defined(FSL_FEATURE_FLEXCAN_SUPPORT_ENGINE_CLK_SEL_REMOVE)) || !FSL_FEATURE_FLEXCAN_SUPPORT_ENGINE_CLK_SEL_REMOVE
  flexcanConfig.clkSrc = kFLEXCAN_ClkSrcPeri;
#endif /* FSL_FEATURE_FLEXCAN_SUPPORT_ENGINE_CLK_SEL_REMOVE */
  flexcanConfig.baudRate = baudrate*1000u;
  /* If special quantum setting is needed, set the timing parameters. */
#if (defined(SET_CAN_QUANTUM) && SET_CAN_QUANTUM)
  flexcanConfig.timingConfig.phaseSeg1 = PSEG1;
  flexcanConfig.timingConfig.phaseSeg2 = PSEG2;
  flexcanConfig.timingConfig.propSeg = PROPSEG;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
  flexcanConfig.timingConfig.fphaseSeg1 = FPSEG1;
  flexcanConfig.timingConfig.fphaseSeg2 = FPSEG2;
  flexcanConfig.timingConfig.fpropSeg = FPROPSEG;
#endif
#endif
  FLEXCAN_Init(CAN_PORT, &flexcanConfig, CAN_CLK_FREQ);
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
  /* Enable CAN FD operation with flexible payload and data rate. */
  FLEXCAN_FDEnable(CAN_PORT, BYTES_IN_MB, false);
#endif

  /* Create FlexCAN handle structure and set call back function. */
#ifndef MCO_INSTANCE
  FLEXCAN_TransferCreateHandle(CAN_PORT, &mFlexcanHandle, &CAN_CallbackHandler, NULL);
#else
  #if    MCO_INSTANCE == 1
  FLEXCAN_TransferCreateHandle(CAN_PORT, &mFlexcanHandle, &CAN_CallbackHandler_1, NULL);
  #elif  MCO_INSTANCE == 2
  FLEXCAN_TransferCreateHandle(CAN_PORT, &mFlexcanHandle, &CAN_CallbackHandler_2, NULL);
  #endif
#endif

  /* Set Rx Masking mechanism. */
  FLEXCAN_SetRxMbGlobalMask(CAN_PORT, FLEXCAN_RX_MB_STD_MASK(0x000, 1, 1));
//  FLEXCAN_SetRxIndividualMask(CAN_PORT, RX_MESSAGE_BUFFER_NUM, FLEXCAN_RX_MB_STD_MASK(0x000, 0, 0));
  /* Setup Rx Message Buffer. */
  mbConfig.format = kFLEXCAN_FrameFormatStandard;
  mbConfig.type = kFLEXCAN_FrameTypeData;
  mbConfig.id = FLEXCAN_ID_STD(0);
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
  FLEXCAN_SetFDRxMbConfig(CAN_PORT, RX_MESSAGE_BUFFER_NUM, &mbConfig, true);
#else
  FLEXCAN_SetRxMbConfig(CAN_PORT, RX_MESSAGE_BUFFER_NUM, &mbConfig, true);
#endif
  /* Start receive data through Rx Message Buffer. */
  rxXfer.mbIdx = RX_MESSAGE_BUFFER_NUM;
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
  rxXfer.framefd = &mRxFrame;
  FLEXCAN_TransferFDReceiveNonBlocking(CAN_PORT, &mFlexcanHandle, &rxXfer);
#else
  rxXfer.frame = &mRxFrame;
  FLEXCAN_TransferReceiveNonBlocking(CAN_PORT, &mFlexcanHandle, &rxXfer);
#endif

  /* Setup Tx Message Buffer. */
#if (defined(FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE) && FSL_FEATURE_FLEXCAN_HAS_FLEXIBLE_DATA_RATE)
  FLEXCAN_SetFDTxMbConfig(CAN_PORT, TX_MESSAGE_BUFFER_NUM, true);
#else
  FLEXCAN_SetTxMbConfig(CAN_PORT, TX_MESSAGE_BUFFER_NUM, true);
#endif

  // Init CAN receive SW filter
  CANSWFILTER_Init();

#if (TXFIFOSIZE > 0)
  // Init Tx FIFO
  CANTXFIFO_Flush();
#endif  

#if (RXFIFOSIZE > 0)
  // Init RxFIFO
  CANRXFIFO_Flush();
#endif  

#if MGR_MONITOR_ALL_NODES && (MGRFIFOSIZE > 0)
  // Init MGRFIFO
  CANMGRFIFO_Flush();
#endif  

#ifndef MCO_INSTANCE
  // Initialize Timer Interrupt

#ifdef TIMER_USE_PIT
  /*
   * pitConfig.enableRunInDebug = false;
   */
  PIT_GetDefaultConfig(&pitConfig);

  /* Init pit module */
  PIT_Init(PIT, &pitConfig);

  /* Set 1 ms timer period for channel 0 */
  PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, USEC_TO_COUNT(1000U, PIT_SOURCE_CLOCK));

  /* Enable timer interrupts for channel 0 */
  PIT_EnableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);

  /* Enable at the NVIC */
  EnableIRQ(PIT_IRQn);
  
  /* Start channel 0 */
  PIT_StartTimer(PIT, kPIT_Chnl_0);

#else  // use GPT

  /*Clock setting for GPT*/
  CLOCK_SetMux(kCLOCK_PerclkMux, GPT_CLOCK_SOURCE_SELECT);
  CLOCK_SetDiv(kCLOCK_PerclkDiv, GPT_CLOCK_DIVIDER_SELECT);

  GPT_GetDefaultConfig(&gptConfig);

  /* Initialize GPT module */
  GPT_Init(GPT_SELECT, &gptConfig);

  /* Divide GPT clock source frequency by 3 inside GPT module */
  GPT_SetClockDivider(GPT_SELECT, 3);

  /* Get GPT clock frequency */
  gptFreq = GPT_CLK_FREQ;

  /* Set GPT OC values to 1 millisecond duration */
  GPT_SetOutputCompareValue(GPT_SELECT, kGPT_OutputCompare_Channel1, gptFreq / 3 / 1000);

  /* Enable GPT Output Compare1 interrupt */
  GPT_EnableInterrupts(GPT_SELECT, kGPT_OutputCompare1InterruptEnable);

  /* Enable at the Interrupt */
  EnableIRQ(GPT_IRQ);

  /* Start Timer */
  GPT_StartTimer(GPT_SELECT);
#endif

#endif

  // Init HW status variable
  gMCOConfig.HWStatus = HW_INIT;

  return 1;
}


/**************************************************************************
DOES:    This function implements the initialization of a CAN ID hardware
         filter as supported by many CAN controllers.
RETURNS: 1 if filter was set 
         2 if this HW does not support filters 
           (in this case HW will receive EVERY CAN message)
         0 if no more filter is available
**************************************************************************/
UNSIGNED8 MCOHW_SetCANFilter (
  UNSIGNED16 CANID
  )
{
  return CANSWFILTER_Set(CANID);
}


/**************************************************************************
DOES:    This function implements the deletion of a previously set CAN ID 
         hardware filter as supported by many CAN controllers.
RETURNS: 1 if filter was deleted
         0 if filter could not be deleted
**************************************************************************/
UNSIGNED8 MCOHW_ClearCANFilter (
  UNSIGNED16 CANID
  )
{
  return CANSWFILTER_Clear(CANID);
}


#if MGR_MONITOR_ALL_NODES
/**************************************************************************
DOES:    This function implements an additional CAN receive filter
         used by the manager. Messages received using this ID are pulled
         by the manager using function MCOHWMGR_PullMessage
         Filter set receives messages from 0x81 to 0xFF and 0x581 to 0x5FF
RETURNS: TRUE or FALSE, if filter was not set
**************************************************************************/
UNSIGNED8 MCOHWMGR_SetCANFilter (
  void
  )
{ 
  // In this driver no HW filters are used, SW only
  return TRUE;
}
#endif // MGR_MONITOR_ALL_NODES


/**************************************************************************
DOES:    This function reads a 1 millisecond timer tick. The timer tick
         must be a UNSIGNED16 and must be incremented once per millisecond.
RETURNS: 1 millisecond timer tick
**************************************************************************/
UNSIGNED16 MCOHW_GetTime (void)
{
  return gTimCnt;
}


/**************************************************************************
DOES:    This function compares a UNSIGNED16 timestamp to the internal 
         timer tick and returns 1 if the timestamp expired/passed.
RETURNS: 1 if timestamp expired/passed
         0 if timestamp is not yet reached
NOTES:   The maximum timer runtime measurable is 0x8000 (about 32 seconds).
         For the usage in MicroCANopen that is sufficient. 
**************************************************************************/
UNSIGNED8 MCOHW_IsTimeExpired (
  UNSIGNED16 timestamp
  )
{
UNSIGNED16 time_now;

  time_now = gTimCnt;
  if (time_now >= timestamp)
  {
    if ((time_now - timestamp) < 0x8000)
      return 1;
    else
      return 0;
  }
  else
  {
    if ((timestamp - time_now) >= 0x8000)
      return 1;
    else
      return 0;
  }
}


#if USE_SLEEP
/**************************************************************************
DOES:    Sets the processor into sleep or power down mode.
         Called when a sleep request was received and confirmed.
         Wakeup MUST be through a reset.
**************************************************************************/
void MCOHW_Sleep (
  void
  )
{ // Here: simplified implementation, waiting for next CAN message
  while (CANRXFIFO_GetOutPtr() != 0)
  {
  }
  // Do a full reset now
  MCOUSER_ResetApplication();
}
#endif
/*----------------------- END OF FILE ----------------------------------*/
