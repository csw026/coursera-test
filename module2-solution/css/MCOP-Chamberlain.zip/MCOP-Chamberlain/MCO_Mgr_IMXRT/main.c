/**************************************************************************
MODULE:    MAIN
CONTAINS:  Example application using MicroCANopen
           NXP i.MX RT 105x derivatives with CAN interface.
           Compiled and Tested with MCUXpresso 10.2
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-04-11 12:07:31 +0200 (Wed, 11 Apr 2018) $
           $LastChangedRevision: 4275 $
***************************************************************************/ 

// Include all MicroCANopen Plus Manager relevant files
#include "mcop_mgr_inc.h"



/**************************************************************************
DOES:    Working on the application
RETURNS: nothing
**************************************************************************/
void USER_ProcessApp(
  void
  )
{
UNSIGNED8 buf[4];    // buffer to process image
static UNSIGNED16 pot;  // Analog value / counter
static UNSIGNED16 last;  // Analog value / counter
UNSIGNED16 now;

#ifdef P620001_DIGOUTPUT8_1
  // Update process data
  // Echo Digital Output
  MCO_ReadProcessData(buf,2,P620001_DIGOUTPUT8_1);
  MCO_WriteProcessData(P600001_DIGINPUT8_1,2,buf);
#endif

  // Every 10000 cycles, timer to process data
  pot++;
  if (pot > 10000)
  {
    now = MCOHW_GetTime();
    buf[0] = now & 0x00FF; // lo byte
    buf[1] = (now >> 8) & 0x00FF; // hi byte
    buf[2] = (now-last) & 0x00FF;
    buf[3] = ((now-last) >> 8) & 0x00FF;
    last = now;
    // Write analog data to process image
#ifdef P640101_ANALOGINPUT16_1
    MCO_WriteProcessData(P640101_ANALOGINPUT16_1,4,buf);
#endif
    pot = 0;
  }
}

/**************************************************************************
DOES:    The main function
RETURNS: nothing
**************************************************************************/
int main(
  void
  )
{
  UNSIGNED8 do_nmtreset = TRUE;  // reset all slave nodes once
  UNSIGNED16 nmtreset_delay; // delay before resetting slave nodes

  /* Board pin, clock, debug console init */
  BOARD_ConfigMPU();
  BOARD_InitPins();
  BOARD_BootClockRUN();
  BOARD_InitDebugConsole();

  /* Enable clock gate for GPIO1 */
  CLOCK_EnableClock(kCLOCK_Gpio1);

  /* Set PERCLK_CLK source to OSC_CLK*/
  CLOCK_SetMux(kCLOCK_PerclkMux, 1U);
  /* Set PERCLK_CLK divider to 2 */
  CLOCK_SetDiv(kCLOCK_PerclkDiv, 1U);

  /* Initialize and enable LED */
  USER_LED_INIT(LOGIC_LED_OFF);

  // Reset/Initialize CANopen communication
  MCOUSER_ResetCommunication();

  // NMT reset delay
  nmtreset_delay = MCOHW_GetTime() + 500;

  // foreground loop
  while(1)
  {
    // Operate on CANopen protocol stack, slave
    MCO_ProcessStack();
    // Operate on application
    USER_ProcessApp();

    if (MY_NMT_STATE == NMTSTATE_OP)
    { // Only work on manager when we are operational
      // Operate on CANopen protocol stack, manager
      MGR_ProcessMgr();
      // Operate on custom CANopen manager application
      USER_ProcessMgr();
    }

    if (do_nmtreset && MCOHW_IsTimeExpired(nmtreset_delay))
    { // after delay, reset all slave nodes
      // restart all nodes
      MGR_TransmitNMT(NMTMSG_RESETAPP,0);
      do_nmtreset = FALSE;  // only do it once
    }

  } // end of while(1)
} // end of main


