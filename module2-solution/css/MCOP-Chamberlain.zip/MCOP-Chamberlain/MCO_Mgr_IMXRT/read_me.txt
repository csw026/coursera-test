MicroCANopen Plus Manager Example Implementation 
================================================

CONTAINS:  Example application using MicroCANopen Plus
           Tested with NXP MIMXRT1050 development board
           Using the MCUXpresso 10.2 IDE
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN
           See file license_commercial_mgr.txt
VERSION:   6.30, ESA 18-SEP-17


Implementation Description
==========================

ONLY CAN INTERFACE 2 IS USED

Baudrate: 125kbit


MANAGER MODE
------------
In CANopen Manager mode (MONITOR_ALL_NODES defined), the 
Manager detects new nodes of type CiA 401 and scans them 
automatcially.

Both a blocking access as well as non-blocking are used to 
illustrate the difference SDO client modes.

For testing with CANopen Magic Ultimate ensure that nodes 
are added to the simulation and are running when executing 
this manager code. Depending on node ID, different accesses
will be made. 
Node ID 2, 4 and 5: read of 1008h, write of 1017h, blocking
Node ID 3: read of 2221h and [2222h,23h], blocking
Node ID > 5: read of 1009h, non blocking

Process Data of Manager:

P620001_DIGOUTPUT8_1: 16bit echo of input
P620003_DIGOUTPUT8_3: 32bit vendor ID of last completed scan
P620007_DIGOUTPUT8_7: 8bit node id of last node status change
P620008_DIGOUTPUT8_8: 8bit status of last node status change

P640101_ANALOGINPUT16_1: Millisecond timer, and timer since last update
                         updated all 10000 while(1) cycles
