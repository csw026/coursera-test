/**************************************************************************
MODULE:    NODECFG.H
CONTAINS:  MicroCANopen node configuration
HERE:      Manager Configuration
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#ifndef _NODECFG_H
#define _NODECFG_H


// CANopen Data Types
#include "mco_types.h"

// Hardware configuration
#include "mcohw_cfg.h"


/**************************************************************************
DEFINES: DEFAULT CONFIGURATION
NOTE:    ESAcademy only tests this code with ENFORCE_DEFAULT_CONFIGURATION
         set to one. Disabling allows setting several optimization features
**************************************************************************/
#define ENFORCE_DEFAULT_CONFIGURATION 1


/**************************************************************************
DEFINES: DEFAULT NODE ID
**************************************************************************/

// Define the default Node ID that is used to initialize the CANopen
// stack if no user-specific setting is implemented in
// MCOUSER_ResetCommunication(). If the Node ID from auto-generated code
// via CANopen Architect EDS is to be used, set it to NODE_ID, if node ID
// can change (e.g. by LSS) set to MY_NODE_ID
#ifdef __SIMULATION__
#define NODEID simconfiguration.nodeid
#else
#define NODEID NODEID_DCF
#endif


/**************************************************************************
DEFINES: ENABLING/DISABLING CODE FUNCTIONALITY
         Do not define, if default should be used
**************************************************************************/

// If enabled, node starts up automatically (does not wait for NMT master)
#define AUTOSTART 1

// If enabled, parameters passed to functions are checked for consistency. 
// On failures, the user function MCOUSER_FatalError is called.
#define CHECK_PARAMETERS 1

// If enabled, CANopen indicator lights are implemented
#define USE_LEDS 1


/**************************************************************************
DEFINES: ADDITIONAL ENABLING/DISABLING CODE FUNCTIONALITY OF PLUS PACKAGE
         Do not define, if default should be used
**************************************************************************/

// Using the "plus" functionality of MicroCANopen
#define USE_MCOP 1

// If enabled, Emergency Messages are used
#define USE_EMCY 1
// If EMCYs are used, size of error field history [1003h]
#define ERROR_FIELD_SIZE 4

// If enabled, extended SDO handling (segmented transfer) is used
#define USE_EXTENDED_SDO 1

// If enabled, blocked SDO transfers are allowed
#define USE_BLOCKED_SDO 1
// Max size of a block supported (4 to 127)
#define BLK_MAX_SIZE 8
#define BLK_B2B_TIMEOUT 4

// If enabled, the function Store Parameters [1010h] is supported
// The driver must provide funtcions NVOL_ReadByte and NVOL_WriteByte
#define USE_STORE_PARAMETERS 0
// Nr of Subindexes used at [1010h]
#define NROF_STORE_PARAMETERS 4
// Specify offset and size of non-volatile memory,
#define NVOL_STORE_START 2
#define NVOL_STORE_SIZE 200


/**************************************************************************
DEFINES: ENABLING CANopen DATA CALL-BACK FUNCTIONS
         DEFAULT IMPLEMENTATION IN user_cbdata.c
**************************************************************************/

// if enabled, the call-back function MCOUSER_NMTChange() is called
// every time the CANopen stack changes it NMT slave state
#define USECB_NMTCHANGE 1

// If enabled, the call-back function MCOUSER_ODData() is called every 
// time data is received into the process image 
// NOTE: PI Access, RPDO or SDO write
#define USECB_ODDATARECEIVED 1

// If enabled, the call-back function MCOUSER_RPDOReceived() is called 
// every time the CANopen stack receives an RPDO
// NOTE: PI Access, RPDO 
#define USECB_RPDORECEIVE 0

// If enabled, the call-back function MCOUSER_TPDOReady() is called every
// time right before the CANopen stack sends a TPDO
// NOTE: PI Access, TPDO 
#define USECB_TPDORDY 1

// If enabled, the call-back function MCOUSER_SYNCReceived() is called 
// every time the CANopen stack receives the SYNC message
// NOTE: No data, RPDO data needs to be applied, TPDO uses USECB_TPDORDY
#define USECB_SYNCRECEIVE 1

// If enabled, the call back functions MCOUSER_SDORdPI(), 
// MCOUSER_SDOWrPI(), MCOUSER_SDORdAft() and MCOUSER_SDOWrAft() are called 
// before/after every expedited SDO access to the process image
// NOTE: SDO access to PI
#define USECB_SDO_RD_PI    0
#define USECB_SDO_RD_AFTER 0
#define USECB_SDO_WR_PI    0
#define USECB_SDO_WR_AFTER 0

// If enabled, the call back functions MCOUSER_AppSDOReadInit() with
// MCOUSER_AppSDOReadComplete or MCOUSER_AppSDOWriteInit() with
// MCOUSER_AppSDOWriteComplete() are called before/after every segmented 
// SDO request. Allows implementation of application specific, custom 
// segmented SDOs (e.g dynamic length entries)
// NOTE: segmented SDO access, also outside PI
#define USECB_APPSDO_READ  1
#define USECB_APPSDO_WRITE 1


/**************************************************************************
DEFINES: ADDITIONAL ENABLING/DISABLING CODE FUNCTIONALITY OF MANAGER
**************************************************************************/

// Use the CANopen Manager
#define MGR_MONITOR_ALL_NODES 1

// Allows to enable the optional LSS Manager
#ifndef USE_LSS_MANAGER
#define USE_LSS_MANAGER 0
#endif

// If defined, use MicroLSS/LSS FastScan Manager 
#ifndef USE_MLSS_MANAGER
#define USE_MLSS_MANAGER 0
#endif


/**************************************************************************
DEFINES: required definitions when using the Manager
**************************************************************************/

// How many heartbeat timeouts are checked with each call to ProcessMgr
#define NR_OF_HBCHECKS_PERCYCLE 4

// Maximum number of nodes, 1 to 127
#define MAX_NR_OF_NODES 32

// Default settings for number of SDO clients
#define NR_OF_SDO_CLIENTS 32
// Default SDO client timeout in milliseconds
#define SDO_REQUEST_TIMEOUT 50
// SDO client back-to-back transmit timeout in milliseconds
#define SDO_BACK2BACK_TIMEOUT 3
// SDO client supports block mode
#define USE_BLOCKED_SDO_CLIENT 0
// SDO block transfer max number of blocks (4 to 127)
#define SDO_BLK_MAX_SIZE 8
// The concised DCF option, when enabled, allows to process multiple
// SDO write commands automatically from a table.
#define USE_CONCISEDCF 1
// If enabled, allow SDO client writes/downloads of longer data than local
// buffer. Enables SDOCLNTCB_SDOWriteInit and SDOCLNTCB_SDOWriteComplete.
#define SDOCLNTCB_APPSDO_WRITE 0



/**************************************************************************
DEFINES: required definitions when using the MLSS Manager
**************************************************************************/

#if USE_MLSS_MANAGER

// node ID to assign to first node found. All other nodes will be assigned
// sequential node IDs
#define MLSSM_STARTNODEID 0x02
// scan timeout in milliseconds
#ifdef __SIMULATION__
#define MLSSM_TIMEOUT 50
#else
#define MLSSM_TIMEOUT 80
#endif
// timeout increase after fail
#define MLSSM_TIMEOUTINCREASE 10
// number of fails allowed
#define MLSSM_MAXFAIL 8
// timeout between scans for new devices
#define MLSSM_SCANTIME 1000

#endif // USE_MLSS_MANAGER


/**************************************************************************
DEFINES: Application Profile Specific Support
**************************************************************************/

// If enabled, support of car-add on devices is implemented
#define USE_CiA447 0

// If enabled, support of proprietary fully-meshed SDO communication is
// implemented
#define USE_SDOMESH 0

#if USE_CiA447
#define NR_OF_SDOSERVER 16
#else
#if USE_SDOMESH
#define NR_OF_SDOSERVER 16
#else
#define NR_OF_SDOSERVER 1
#endif
#endif

// Support of generic data pointer for OD contents.
// Set to zero, if all data is in process image.
#define USE_GENOD_PTR 0


#endif // _NODECFG_H

/*----------------------- END OF FILE ----------------------------------*/
