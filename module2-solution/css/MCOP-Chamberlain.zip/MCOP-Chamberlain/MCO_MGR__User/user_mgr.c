/**************************************************************************
MODULE:    USER_MGR
CONTAINS:  Default functions for manager application
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-08-18 15:32:45 -0500 (Sat, 18 Aug 2018) $
           $LastChangedRevision: 4337 $
***************************************************************************/ 

// Include all MicroCANopen Plus Manager relevant files
#include "mcop_mgr_inc.h"

#ifdef __SIMULATION__
#include "simdriver.h"
#endif

#if (MAX_NR_OF_NODES != NR_OF_SDO_CLIENTS)
#error This example requires one SDO channel for each node
#endif

/**************************************************************************
MODUL VARIABLES, here handling of OD entries that get automatically scanned
***************************************************************************/ 

// auto scan list, which object dictionary entries to read/write from/to each node
static MEM_FAR UNSIGNED8 mScanList[] = {
                           SL_ENTRY(0x1017,0,SL_WRITE|2), // 0
                           SL_ENTRY(0x1000,0,SL_READ |4),  // 1
                           SL_ENTRY(0x1018,1,SL_READ |4),  // 2
                           SL_ENTRY(0x1018,2,SL_READ |4),  // 3
                           SL_ENTRY(0x1018,3,SL_READ |4),  // 4
                           SL_END
                          };

// mScanList entry numbers
typedef enum {
  SL_ENTRY_WRITE_1017_0 = 0,  // Entry number to write Heartbeat
  SL_ENTRY_READ_1000_0,       // Entry number to read Device Type
  SL_ENTRY_READ_1018_1,       // Entry number to read Vendor ID
  SL_ENTRY_READ_1018_2,       // Entry number to read Product Code
  SL_ENTRY_READ_1018_3,       // Entry number to read Revision Number
} ScanListEntryNumbers;

// Length of auto scan list
#define SCAN_NROFENTRIES (sizeof(mScanList)/SL_ENTRY_SIZE - 1)

#define DEFAULT_SDODELAY        100 // Default SDO delay between transfers in ms
#define DEFAULT_SLAVE_HEARTBEAT 750 // Default slave heartbeat in ms

#if USE_CONCISEDCF
// CDCF example, here three entries, writing to 1017h,0 first with 0 and then 1000
// then 0x5A to 6200h,1
static MEM_FAR UNSIGNED8 cdcf[] = {0x03,0x00,0x00,0x00,
                            0x17,0x10,  0x00,   0x02,0x00,0x00,0x00,   0x00, 0x00,
                            0x17,0x10,  0x00,   0x02,0x00,0x00,0x00,   0xE8, 0x03,
                            0x00,0x62,  0x01,   0x01,0x00,0x00,0x00,   0x5A
                           };
static MEM_FAR UNSIGNED8 *pCDCF_stat;
static UNSIGNED8 do_once = FALSE;
#endif

// Internal state of node
#define NODE_OP_MSK          3  // mask for bits for operational mode   
#define NODE_NON             0  // not on network,    
#define NODE_ON_INIT         1  // on network, not yet usable,    
#define NODE_ON_PREOP        2  // on network, pre-op or stopped   
#define NODE_ON_OP           3  // on network, operational   
#define NODE_SDO_SCAN     0x08  // auto scan ongoing
#define NODE_SDO_MSK      0x30  // mask for bits for SDO channel state   
#define NODE_SDO_INUSE    0x10  // SDO channel in use   
#define NODE_SDO_ABORT    0x20  // SDO channel in had abort   

// Collected data for node management
typedef struct {
  UNSIGNED8 node_state;
  UNSIGNED16 delay; // delay in between SDO cycles
  UNSIGNED8 buffer[32]; // buffer for SDO client transfers
  UNSIGNED8 scan_data[SCAN_NROFENTRIES*SD_ENTRY_SIZE]; //  auto scan read/write data
} NodeManageType;

static MEM_FAR NodeManageType mNodeManage[MAX_NR_OF_NODES];

static MEM_FAR SDOCLIENT *pSC4; // here: sdo client for node 4
static MEM_FAR SDOCLIENT *pSC5; // here: sdo client for node 5
static UNSIGNED8 nodelp = 0; // working on nodes found
static UNSIGNED8 rcv_buf[128]; // buffer for larger SDO client transfers
static UNSIGNED16 abort_cnt = 0; // counting the number of SDO aborts


/**************************************************************************
DOES:    Called when an SDO client transfer is completed
RETURNS: nothing
**************************************************************************/
void SDOCLNTCB_SDOComplete (
  UNSIGNED8 channel, // SDO channel number in range of 1 to NR_OF_SDO_CLIENTS
  UNSIGNED32 abort_code // status, error, abort code
  )
{
  // need to know if transfer aborted or not?
  mNodeManage[channel-1].node_state &= ~NODE_SDO_MSK;  // SDO channel is idle
  if (abort_code != SDOERR_OK)
  {
    mNodeManage[channel-1].node_state |= NODE_SDO_ABORT;
  }
}


/**************************************************************************
DOES:    Call-back function, status change of a node on the network
         NODESTATUS_BOOT          node booted
         NODESTATUS_STOPPED       node changed into operational mode
         NODESTATUS_OPERATIONAL   node changed into operational mode
         NODESTATUS_PREOP         node changed into pre-operational mode
         NODESTATUS_EMCY_OVER     Emergency clear
         NODESTATUS_EMCY_NEW      New emergency occured
         NODESTATUS_HBACTIVE      HB monitoring is now active
         NODESTATUS_HBLOST        HB was lost
         NODESTATUS_SCANCOMPLETE  Auto-scan of node completed (in nodelist)
         NODESTATUS_SCANABORTED  Auto-scan of node completed (in nodelist)
RETURNS: Nothing
**************************************************************************/
void MGRCB_NodeStatusChanged (
  UNSIGNED8 node_id, // Node ID of the node with a new status
  UNSIGNED8 status,  // NODESTATUS_xxx
  UNSIGNED8 wait     // if TRUE, blocking allowed
  )
{
UNSIGNED8 chn;

#ifdef P600007_DIGINPUT8_7
UNSIGNED8 buf[2];

  // Debug help/test: put node ID into digital input
  buf[0] = node_id;
  buf[1] = status;
  MCO_WriteProcessData(P600007_DIGINPUT8_7,2,buf);
#endif

  // in this example SDO channel = node ID
  chn = node_id;

  if ((node_id > 0) && (node_id <= MAX_NR_OF_NODES))
  {
    if (status == NODESTATUS_BOOT)
    { 
      // Make sure node is in pre-operational mode for configuration
      MGR_TransmitNMT(NMTMSG_PREOP,node_id);
      // All write entries' data has to be initialized at this point, using little-endian byte ordering.
      // Initialize the default heartbeat for slave nodes.
      GEN_WR16(&mNodeManage[node_id-1].scan_data[SL_ENTRY_WRITE_1017_0 * SD_ENTRY_SIZE],DEFAULT_SLAVE_HEARTBEAT);
      // trigger scan write/read to ensure we get a heartbeat early on
      MGRSCAN_Init(chn,node_id,mScanList,mNodeManage[node_id-1].scan_data,DEFAULT_SDODELAY);
      mNodeManage[node_id-1].node_state |= NODE_SDO_SCAN;
      // At the same time, set up the heartbeat consumer for the node, using three times the heartbeat rate
      // to be on the safe side.
      MGR_InitHBConsumer(node_id,DEFAULT_SLAVE_HEARTBEAT*3);
    } 
    else if (status == NODESTATUS_SCANCOMPLETE)
    { // Node was auto scanned, SDO is idle now
      mNodeManage[node_id-1].node_state &= ~NODE_SDO_SCAN;
      mNodeManage[node_id-1].delay = MCOHW_GetTime() + 500; // 500ms timeout to start operation in USER_ProcessMgr()
      // start node
      MGR_TransmitNMT(NMTMSG_OP,node_id);

#ifdef P600003_DIGINPUT8_3
      // Debug help/test: put vendor ID into digital input
      MCO_WriteProcessData(P600003_DIGINPUT8_3,4,(UNSIGNED8 *) &(mNodeManage[node_id-1].scan_data[SL_ENTRY_READ_1018_1 * SD_ENTRY_SIZE]));
#endif
    }
    else if (status == NODESTATUS_HBLOST)
    { // Node was lost, send a reset
      MGR_TransmitNMT(NMTMSG_RESETAPP,node_id);
      mNodeManage[node_id-1].node_state = NODE_NON;
    }
    if ((status == NODESTATUS_STOPPED) || (status == NODESTATUS_PREOP))
    {
      mNodeManage[node_id-1].node_state &= ~NODE_OP_MSK;
      mNodeManage[node_id-1].node_state |= NODE_ON_PREOP;
      // if not in operational mode, outside of scan, start node
      if (!(mNodeManage[node_id-1].node_state & NODE_SDO_SCAN))
      {
        MGR_TransmitNMT(NMTMSG_OP,node_id);
      }
    }
    else if (status == NODESTATUS_OPERATIONAL)
    {
      mNodeManage[node_id-1].node_state &= ~NODE_OP_MSK;
      mNodeManage[node_id-1].node_state |= NODE_ON_OP;
    }
  }
}


#if USE_LSS_MANAGER
void MGRCB_LSSIdentified (
  MEM_FAR UNSIGNED8 *pDat // Pointer to 8 data bytes received
  )
{
  pDat = pDat;
}
#endif // USE_LSS_MANAGER


/**************************************************************************
DOES:    Working on user specific management functions
RETURNS: nothing
**************************************************************************/
void USER_ProcessMgr (void)
{
UNSIGNED8 chn;
UNSIGNED16 hrtbt_time; // to write heartbeat time

  // ensure that nodelp runs from 1 to MAX_NR_OF_NODES
  nodelp++;
  if (nodelp > MAX_NR_OF_NODES)
  {
    nodelp = 1;
  }

  // Here: SDO channel number is identical to node ID
  chn = nodelp;

  if ( ((mNodeManage[nodelp-1].node_state & NODE_OP_MSK) >= NODE_ON_PREOP) &&
       (!(mNodeManage[nodelp-1].node_state & NODE_SDO_SCAN)) &&
       (MCOHW_IsTimeExpired(mNodeManage[nodelp-1].delay))
     )
  { // node has SDO channel free, delay is over
    // set new delay, here, max of one transfer per 200ms
    mNodeManage[nodelp-1].delay = MCOHW_GetTime() + 200;
    // now work on node
    if (nodelp == 3)
    { // node ID 3 is default from MCOP slave examples, read extended entries
      //  check if Device Profile is CiA 401
      if ((GEN_RD32(&mNodeManage[nodelp-1].scan_data[(int)SL_ENTRY_READ_1000_0 * SD_ENTRY_SIZE]) & 0x0000FFFF) == 401)
      {
        // SDO client read access, long data entry, blocking version
        SDOCLNT_ReadCycle(chn,nodelp,0x2221,0,rcv_buf,128,100);
        SDOCLNT_ReadCycle(chn,nodelp,0x2222,0x23,rcv_buf,128,100);
      }
    }
    else if (nodelp == 4)
    { // node 4, read 1009h
      // SDO client example using non-blocking call and call-back SDOCLNT_SDOComplete
      pSC4 = SDOCLNT_Init(chn,0x600+nodelp,0x580+nodelp,&(mNodeManage[nodelp-1].buffer[0]),32);
      // read [0x1009,0x00] of node 
      SDOCLNT_Read(pSC4,0x1009,0x00);
      // now mark channel used
      mNodeManage[nodelp-1].node_state &= ~NODE_SDO_MSK;
      mNodeManage[nodelp-1].node_state |= NODE_SDO_INUSE;
    }
    else if (nodelp == 5)
    { // node 5, read 100Ah
      // SDO client example using non-blocking call and SDOCLNT_IsTransferComplete
      if (pSC5 == 0)
      { // Channel was never initialized
        pSC5 = SDOCLNT_Init(chn,0x600+nodelp,0x580+nodelp,&(mNodeManage[nodelp-1].buffer[0]),32);
      }
      if (SDOCLNT_GetStatus(pSC5) != SDOERR_RUNNING)
      { // currently no transfer running
        hrtbt_time = 900;
        SDOCLNT_WriteXtd(pSC5,0x1017,0,(UNSIGNED8 *)&(hrtbt_time),2,50);
        // Wait until this transfer completed
        SDOCLNT_BlockUntilCompleted(pSC5);
        // read [0x1009,0x00] of node 
        SDOCLNT_ReadXtd(pSC5,0x1009,0x00,&(mNodeManage[nodelp-1].buffer[0]),32,100);
        // continue, SDOCLNT_GetStatus(pSC5) will now be 0xFF until transfer completed
        // now mark channel used, not blocking, comes back here when completed
        mNodeManage[nodelp-1].node_state &= ~NODE_SDO_MSK;
        mNodeManage[nodelp-1].node_state |= NODE_SDO_INUSE;
      }
    }
#if USE_CONCISEDCF
    else if (nodelp == 6)
    { // node 6, write DCF
      if (!(do_once))
      { // only do this once
        pCDCF_stat = CDCF_Write(chn,6,&(cdcf[0]),100);
        do_once = TRUE;
      }
      // no change to mNodeState[nodelp-1].node_state, process above needs to be executed
      if (*pCDCF_stat < CDCF_COMPLETE)
      { // keep workin on file until complete
        CDCF_Process();
        // next msg in 10ms
        mNodeManage[nodelp-1].delay = MCOHW_GetTime() + 10;
      }
      else
      { // done, repeat in 10s
        mNodeManage[nodelp-1].node_state &= ~NODE_SDO_MSK;
        mNodeManage[nodelp-1].delay = MCOHW_GetTime() + 1000;
        do_once = FALSE;
      }
    }
#endif
    else
    { 
      // for all other nodes, read 1008h (dummy read, just for demonstration) every time we reach this
      SDOCLNT_ReadCycle(chn,nodelp,0x1008,0x00,&(mNodeManage[nodelp-1].buffer[0]),32,0);
    }
  }
  else if  (mNodeManage[nodelp-1].node_state & NODE_SDO_ABORT)
  { // node had an abort
    abort_cnt++;
    mNodeManage[nodelp-1].delay = MCOHW_GetTime() + 1000; // 1s timeout after abort 
    mNodeManage[nodelp-1].node_state &= ~NODE_SDO_MSK;  // mark channel free again to start over
  }

  // Check for CAN Err, auto-recover
  if (MCOHW_GetStatus() & HW_BOFF)
  {
    MCOUSER_FatalError(0xF6F6);
  }

}


/**************************************************************************
END-OF-FILE 
***************************************************************************/ 

