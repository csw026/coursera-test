/**************************************************************************
MODULE:    USER
CONTAINS:  MicroCANopen Object Dictionary and Process Image implementation
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-01-29 05:50:53 -0600 (Mon, 29 Jan 2018) $
           $LastChangedRevision: 4186 $
***************************************************************************/ 

#include "mco.h"
#include "mcop.h"
#include "mcohwPCSIM.h"
#include "mcohw.h"
#include "string.h"
#include "lss.h"

#if MGR_MONITOR_ALL_NODES
#include "comgr.h"
#endif

#if USE_LEDS
#include "mcohw_LEDs.h"
#endif

#if USE_XOD_ACCESS
#include "xod.h"
#endif

#include "entriesandreplies.h"
#include "stackinit.h"

#ifdef __SIMULATION__
// header files to create dll
#include <windows.h>
#include "mcohwpcsim.h"
#include "simnodehandler.h"
#endif

// Global config data
extern MCO_CONFIG gMCOConfig;

#if USE_XOD_ACCESS
extern UNSIGNED8 *gBinaryConfiguration;
#endif

/**************************************************************************
DOES:    Call-back function for occurance of a fatal error. 
         Stops operation and displays blnking error pattern on LED
**************************************************************************/
void MCOUSER_FatalError (UNSIGNED16 ErrCode)
{
#ifdef __SIMULATION__
  SimDriver_printf("FATAL ERROR - 0x%4.4X\n", ErrCode);
#endif

  // Remember last error for stack
  gMCOConfig.last_fatal = ErrCode;

#if USE_LEDS
  LED_ERR_ON;
  gMCOConfig.LEDErr = LED_ON;
#endif

#if USE_EMCY
  MCOP_PushEMCY(0x6100,(UNSIGNED8)(ErrCode >> 8),(UNSIGNED8)ErrCode,0,0,0);
#endif // USE_EMCY

  // Wait 10ms
  Sleep(10);

  if (ErrCode >= ERR_FATAL)
  { // Fatal error, should abort/reset
    MCOUSER_ResetApplication();
  }

  // Warning only, simply timeout, then continue
}

/**************************************************************************
DOES:    Call-back function for reset application.
         Starts the watchdog and waits until watchdog causes a reset.
RETURNS: nothing
**************************************************************************/
void MCOUSER_ResetApplication (
  void
  )
{
#ifdef __SIMULATION__
  SimDriver_printf("Reset Application\n");
#endif
  // if reset callback function has been passed from the simnodehandler
  // then call it
  // reset function does not return
#if (MGR_MONITOR_ALL_NODES == 0)   // If this node is not an NMT master
  if (mpReset != 0) mpReset();  
#endif
}

/**************************************************************************
DOES:    Call-back function for reset communication.
         Re-initializes the process image and the entire MicroCANopen
         communication.
**************************************************************************/
void MCOUSER_ResetCommunication (void)
{
UNSIGNED16 can_bps;
UNSIGNED8 node_id;
#if USE_XOD_ACCESS && (USE_LSS_SLAVE == 0)
UNSIGNED32 hblen;
UNSIGNED8 *phbval;
#endif // USE_XOD_ACCESS && (USE_LSS_SLAVE == 0)
#ifdef __SIMULATION__
SIMCONFIGURATION simconfiguration;

  // Get Node ID from simulation driver
  SimDriver_GetConfiguration(&simconfiguration);
  SimDriver_printf("\nResest Communication of MicroCANopen Plus simulation V6.14\n\n");
#endif

#if USE_LSS_SLAVE == 1

  // using LSS

  LSS_LoadConfiguration(&can_bps,&node_id);
  if (node_id == 0) // unconfigured? start using LSS
  {
#ifdef __SIMULATION__
    SimDriver_printf("Starting LSS, wait for node ID assignemnt\n");
#endif
    LSS_Init(node_id);
  }
  else
  {
#ifdef __SIMULATION__
    SimDriver_printf("LSS node ID assigned: %d\n",node_id);
#endif
  }

#else

  // not using LSS

#ifdef __SIMULATION__

  // not using LSS, using simulation

  node_id = simconfiguration.nodeid;
  can_bps = 0; // ignored by simulation system
  SimDriver_printf("Node ID assigned by simulation system: %d\n",node_id);
#else

  // not using LSS, not using simulation

#if USE_XOD_ACCESS
  // extract node id and can bitrate from binary configuration
  OD_GetLayerSettings((UNSIGNED8 *)&(gBinaryConfiguration[0]),&node_id,&can_bps);
#else
  node_id = NODEID_DCF;
  can_bps = CAN_BITRATE_DCF;
#endif

#endif

#endif

  if (MCO_Init(can_bps,node_id,DEFAULT_HEARTBEAT)) 
  {

#if USE_LSS_SLAVE == 0
    //Initialization of PDOs comes from EDS
    INITPDOS_CALLS

    // Initialization of heartbeat consumers from EDS
    INITHBCONSUMER_CALLS

#if USE_XOD_ACCESS
    // Activate alternate, loaded configuration
    OD_SwitchObjectDictionary((UNSIGNED8 *)&(gBinaryConfiguration[0]));

    // configure heartbeat producer time using loaded configuration
    if (OD_FindODDataEntry(3, 0x1017, 0x00, &hblen, &phbval))
    {
      gMCOConfig.heartbeat_time = phbval[1];
      gMCOConfig.heartbeat_time = (gMCOConfig.heartbeat_time << 8) + phbval[0];
      // reset heartbeat time for immediate transmission or current time plus new heartbeat time?
      // Current 3.01 conformance test 9.4 (state 04) requires this to be current time plus new heartbeat time
      // gMCOConfig.heartbeat_timestamp = MCOHW_GetTime();
      gMCOConfig.heartbeat_timestamp = MCOHW_GetTime() + gMCOConfig.heartbeat_time;

#ifdef __SIMULATION__
      SimDriver_printf("Setting heartbeat producer time to %dms\n", gMCOConfig.heartbeat_time);
#endif // __SIMULATION__
    }
#endif

#if USE_STORE_PARAMETERS
    MCOSP_GetStoredParameters();
#endif
#endif

#if MGR_MONITOR_ALL_NODES
    MCOHWMGR_SetCANFilter();
    MGR_InitMgr();
#endif
  }
}


#if USECB_NMTCHANGE
/**************************************************************************
DOES:    Called when the NMT state of the stack changes
RETURNS: nothing
**************************************************************************/
void MCOUSER_NMTChange
  (
  UNSIGNED8 nmtstate    // new nmt state of stack
  )
{
#if USE_XOD_ACCESS && (USE_LSS_SLAVE == 1)
UNSIGNED32 hblen;
UNSIGNED8 *phbval;
#endif // USE_XOD_ACCESS && (USE_LSS_SLAVE == 1)

#ifdef __SIMULATION__
SIMCONFIGURATION simconfiguration;

  // Get access to Node ID from simulation driver
  SimDriver_GetConfiguration(&simconfiguration);

  SimDriver_printf("Own node ID: %d, NMT state: ",MY_NODE_ID);
  switch (nmtstate)
  {
    case NMTSTATE_BOOT:  SimDriver_printf("bootup\n");         break;
    case NMTSTATE_STOP:  SimDriver_printf("stopped\n");        break;
    case NMTSTATE_OP:    SimDriver_printf("operational\n");    break;
    case NMTSTATE_PREOP: SimDriver_printf("preoperational\n"); break;
    default:             SimDriver_printf("UNKNOWN\n");        break;
  }

  SimDriver_UpdateNMTState(nmtstate);

  if (nmtstate == NMTSTATE_BOOT)
  {
    SimDriver_UpdateNodeID(gMCOConfig.Node_ID);
  }
#endif

#if USE_LSS_SLAVE == 1
  if (nmtstate == NMTSTATE_BOOT)
  {
    //Initialization of PDOs comes from EDS
    INITPDOS_CALLS

    // Initialization of heartbeat consumers from EDS
    INITHBCONSUMER_CALLS

#if USE_XOD_ACCESS
    // Activate alternate, loaded configuration
    OD_SwitchObjectDictionary((UNSIGNED8 *)&(gBinaryConfiguration[0]));

    // configure heartbeat producer time using loaded configuration
    if (OD_FindODDataEntry(3, 0x1017, 0x00, &hblen, &phbval))
    {
      gMCOConfig.heartbeat_time = phbval[1];
      gMCOConfig.heartbeat_time = (gMCOConfig.heartbeat_time << 8) + phbval[0];
      // reset heartbeat time for immediate transmission or current time plus new heartbeat time?
      // Current 3.01 conformance test 9.4 (state 04) requires this to be current time plus new heartbeat time
      // gMCOConfig.heartbeat_timestamp = MCOHW_GetTime();
      gMCOConfig.heartbeat_timestamp = MCOHW_GetTime() + gMCOConfig.heartbeat_time;

#ifdef __SIMULATION__
      SimDriver_printf("Setting heartbeat producer time to %dms\n", gMCOConfig.heartbeat_time);
#endif // __SIMULATION__
    }
#endif

#if USE_STORE_PARAMETERS
    MCOSP_GetStoredParameters();
#endif
  }
#endif
}
#endif


#if USECB_ODSERIAL
/**************************************************************************
DOES:    This function is called upon read requests to Object Dictionary
         entry [1018h,4] - serial number
RETURNS: The 32bit serial number
**************************************************************************/
UNSIGNED32 MCOUSER_GetSerial (
  void
  )
{
#ifdef __SIMULATION__
SIMCONFIGURATION simconfiguration;

  // Get serial number from simulation driver
  SimDriver_GetConfiguration(&simconfiguration);
  SimDriver_printf("Serial number requested: 0x%8.8X\n", simconfiguration.serialnumber);
  return simconfiguration.serialnumber;
#else
  // replace with code to read serial number, for example from 
  // non-volatile memory
  return 0x12345678;
#endif
}
#endif // USECB_ODSERIAL


/**************************************************************************
DOES:    Call-back function, heartbeat lost, timeout occured.
         Gets called when a heartbeat timeout occured for a node.
RETURNS: Nothing
**************************************************************************/
void MCOUSER_HeartbeatLost (
  UNSIGNED8 node_id
  )
{
#ifdef __SIMULATION__
  SimDriver_printf("Heartbeat of node %d lost\n", node_id);
#endif

  // Add code to react on the loss of heartbeat,
  // if node is essential, switch to pre-operational mode
  MCO_HandleNMTRequest(NMTMSG_PREOP);
}


#if USECB_TIMEOFDAY
/**************************************************************************
DOES:    This function is called if the message with the time object has
         been received. This example implementtion calculates the current
         time in hours, minutes, seconds.
RETURNS: nothing
**************************************************************************/
// Global variables holding clock info
UNSIGNED32 hours;
UNSIGNED32 minutes;
UNSIGNED32 seconds;

void MCOUSER_TimeOfDay (
  UNSIGNED32 millis, // Milliseconds since midnight
  UNSIGNED16 days  // Number of days since January 1st, 1984
  )
{
  if (millis < (1000UL * 60 * 60 * 24))
  { // less Milliseconds as one day has
    // calculate hours, minutes & seconds since midnight
    hours = millis / (1000UL * 60 * 60);
    minutes = (millis - (hours * 1000UL * 60 * 60)) / (1000UL * 60);
    seconds = (millis - (hours * 1000UL * 60 * 60) - (minutes * 1000UL * 60)) / 1000;
  }
}
#endif // USECB_TIMEOFDAY


/**************************************************************************
END-OF-FILE 
***************************************************************************/ 
