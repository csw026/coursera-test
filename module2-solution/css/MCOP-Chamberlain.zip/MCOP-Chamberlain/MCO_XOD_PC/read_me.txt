MicroCANopen Plus XOD Example Implementation
============================================

CONTAINS:  Example application using MicroCANopen, XOD loadable Obejct Dictionary
           Tested with PCANopen Magic ProS Simulation System
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION "MicroCANopen Plus"
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17



Implementation Description
==========================

This code is base for the simulation DLLs used by CANopen Magic Ultimate
