/**************************************************************************
MODULE:    MCOHW
CONTAINS:  MicroCANopen and MicroCANopen Plus driver
           Written for CANopen Magic Ultimate simulation system
           www.canopenmagic.com
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "mcop.h"
#include "mcohw.h"
#include "canfifo.h"
#include "simdll.h"
#include "simnodehandler.h"


/**************************************************************************
DEFINES
**************************************************************************/


/**************************************************************************
GLOBAL VARIABLES
**************************************************************************/

// This structure holds all node specific configuration
extern MCO_CONFIG gMCOConfig;

// Global timer/conter variable, incremented every millisecond
UNSIGNED16 volatile gTimCnt = 0;

// Counts number of filters (CAN message objects) used
UNSIGNED8 gCANFilter = 0;

// flags to enable/disable timer and can "interrupts"
UNSIGNED8 ECAN = 0;
UNSIGNED8 ETIM = 0;


/**************************************************************************
MODULE VARIABLES
**************************************************************************/


/**************************************************************************
PRIVATE, LOCAL FUNCTIONS
**************************************************************************/

/**************************************************************************
DOES:    Timer interrupt service routine                          
         Increments the global millisecond counter tick           
         This function needs to be called once every millisecond  
RETURNS: nothing                                                     
**************************************************************************/
void MCOHW_TimerISR
  (
  void
  )
{
  // is timer interrupt disabled? then ignore tick count
  if (!ETIM)
  {
    return;
  }

  // increment global counter
  gTimCnt++;
}


/**************************************************************************
PUBLIC, GLOBAL FUNCTIONS
**************************************************************************/

/**************************************************************************
DOES:    Initializes the CAN interface.                           
CAUTION: Does not initialize filters - nothing will be received   
         unless screeners are set using set_screener_std          
RETURNS: 0 for failed init, 1 for successful init                 
**************************************************************************/
UNSIGNED8 MCOHW_Init
  (
  UNSIGNED16 BaudRate  // desired baudrate in kbps
  )
{
  // we don't configure anything, we simply use the baud rate the can
  // bus is already configured to use

  // no can filters configured
  gCANFilter = 0;

  // enable can receive
  ECAN = 1;
  // enable tick timer
  ETIM = 1;

  return 1;
}


/**************************************************************************
DOES:    Initializes the next available filter                    
RETURNS: 0 for failed init, 1 for successful init                 
**************************************************************************/
UNSIGNED8 MCOHW_SetCANFilter
  (
  UNSIGNED16 CANID  // identifier to receive
  )                 // highest bit set == remote request
{
  return CANSWFILTER_Set(CANID);
}

/**************************************************************************
DOES:    This function implements the deletion of a previously set CAN ID
         hardware filter as supported by many CAN controllers.
RETURNS: 1 if filter was deleted
         0 if filter could not be deleted
**************************************************************************/
UNSIGNED8 MCOHW_ClearCANFilter (
  UNSIGNED16 CANID
  )
{
  return CANSWFILTER_Clear(CANID);
}


#if MGR_MONITOR_ALL_NODES
/**************************************************************************
DOES:    This function implements an additional CAN receive filter
         used by the manager. Messages received using this ID are pulled
         by the manager using function MCOHWMGR_PullMessage
         Filter set receives messages from 0x81 to 0xFF and 0x581 to 0x5FF
RETURNS: TRUE or FALSE, if filter was not set
**************************************************************************/
UNSIGNED8 MCOHWMGR_SetCANFilter(
  void
)
{
  // In this driver no HW filters are used, SW only
  return TRUE;
}
#endif                          // MGR_MONITOR_ALL_NODES


/**************************************************************************
DOES:    Receives a message from the CAN bus - just like a receive
         interrupt. Stores the message in a buffer to mimic a CAN
         controller                                         
RETURNS: nothing                                     
**************************************************************************/
void MCOHW_ReceiveMessage
  (
  CAN_MSG *pMsg   // pointer to message to store
  )
{
  CAN_MSG *pDst;
  UNSIGNED32 canid;
  UNSIGNED8 byte;

  canid = pMsg->ID;
  
#if MGR_MONITOR_ALL_NODES
  if ((MY_NMT_STATE == 5)

#if USE_MLSS_MANAGER || USE_LSS_MANAGER
    || IS_CANID_LSS_RESPONSE(canid)
#endif
    )
  {
#if USE_CiA447
          if (((canid >= 0x081) && (canid <= 0x090)) ||
              ((canid >= 0x600) && (canid <= 0x6FF)) ||
              ((canid >= 0x701) && (canid <= 0x710))
#if USE_MLSS_MANAGER || USE_LSS_MANAGER
              || IS_CANID_LSS_RESPONSE(canid)
#endif
             )
#else
#if USE_SDOMESH
          if (((canid >= 0x081) && (canid <= 0x090)) ||
              ((canid >= 0x100) && (canid <= 0x17F)) ||
              ((canid >= 0x580) && (canid <= 0x5FF)) ||
              ((canid >= 0x701) && (canid <= 0x710))
#if USE_MLSS_MANAGER || USE_LSS_MANAGER
              || IS_CANID_LSS_RESPONSE(canid)
#endif
             )
#else
          if (((canid >= 0x081) && (canid <= 0x0FF)) ||
              ((canid >= 0x581) && (canid <= 0x5FF)) ||
              ((canid >= 0x701) && (canid <= 0x77F))
#if USE_MLSS_MANAGER || USE_LSS_MANAGER
              || IS_CANID_LSS_RESPONSE(canid)
#endif
             )
#endif
#endif
    { // This is a message for the CANopen Manager
      // initialize destination pointer into FIFO
      pDst = CANMGRFIFO_GetInPtr();

      if (pDst != 0) {        // FIFO available
        // copy ID
        pDst->ID = canid;
        // copy DLC
        pDst->LEN = pMsg->LEN;
        // copy data
        for (byte = 0; byte < pMsg->LEN; byte++)
        {
          pDst->BUF[byte] = pMsg->BUF[byte];
        }
        // copying is all done
        CANMGRFIFO_InDone();
      } else {                // overrun, message lost
        gMCOConfig.HWStatus |= HW_RXOR;
      }
    }
  }
#endif                          // MGR_MONITOR_ALL_NODES

  if (CANSWFILTER_Match(canid))
  { // Message needs to be received
    // initialize destination pointer into FIFO
    pDst = CANRXFIFO_GetInPtr();

    if (pDst != 0) {        // FIFO available
      // copy ID
      pDst->ID = canid;
      // copy DLC
      pDst->LEN = pMsg->LEN;
      // copy data
      for (byte = 0; byte < pMsg->LEN; byte++)
      {
        pDst->BUF[byte] = pMsg->BUF[byte];
      }
      // copying is all done
      CANRXFIFO_InDone();
    } else {                // overrun, message lost
      gMCOConfig.HWStatus |= HW_RXOR;
    }
  }

  return;
}


/**************************************************************************
DOES:    This function implements a CAN receive queue. With each
         function call a message is pulled from the queue.
RETURNS: 1 Message was pulled from receive queue
         0 Queue empty, no message received
**************************************************************************/
UNSIGNED8 MCOHW_PullMessage(
  CAN_MSG * pReceiveBuf
)
{
  CAN_MSG *pSrc;

  // Check if message is in Rx FIFO  
  pSrc = CANRXFIFO_GetOutPtr();
  if (pSrc != 0) {
    // copy message
    memcpy(pReceiveBuf, pSrc, sizeof(CAN_MSG));
    // copying complete, update FIFO
    CANRXFIFO_OutDone();
    return TRUE;                // msg received
  }
  return FALSE;                 // no msg rcvd 
}


#if MGR_MONITOR_ALL_NODES
/**************************************************************************
DOES:    This function is used by the manager to poll messages that are
         needed by the manager
RETURNS: TRUE or FALSE, if no message was received
**************************************************************************/
UNSIGNED8 MCOHWMGR_PullMessage(
  CAN_MSG * pReceiveBuf         // buffer to witch a received message is copied
)
{
  CAN_MSG *pSrc;

  // Check if message is in Rx FIFO  
  pSrc = CANMGRFIFO_GetOutPtr();
  if (pSrc != 0) {
    // copy message
    memcpy(pReceiveBuf, pSrc, sizeof(CAN_MSG));
    // copying complete, update FIFO
    CANMGRFIFO_OutDone();
    return TRUE;                // msg received
  }
  return FALSE;                 // no msg rcvd 
}
#endif                          // MGR_MONITOR_ALL_NODES


/**************************************************************************
DOES:    Transmits a CAN message                                  
RETURNS: 0 if the message could not be transmitted, 1 if the      
         message was transmitted                                  
**************************************************************************/
UNSIGNED8 MCOHW_PushMessage
  (
  CAN_MSG *pTransmitBuf  // pointer to buffer containing CAN
                                 // message to transmit
  )
{
  SIMCANMESSAGE simmsg;
  int b;

  // copy message to required format
  simmsg.timestamp = 0;
  simmsg.dlc = pTransmitBuf->LEN;
  simmsg.flags = 0;

  // if ext flag set then 29-bit id
  if ((pTransmitBuf->ID & COBID_EXT) != 0)
  {
    simmsg.flags |= SIM_EXT;
    simmsg.id = pTransmitBuf->ID & 0x1FFFFFFFUL;
  }
  else
  {
    simmsg.id = pTransmitBuf->ID & 0x7FFUL;
  }

  // copy data
  for (b = 0; b < 8; b++)
  {
    simmsg.data[b] = pTransmitBuf->BUF[b];
  }

  // transmit the message
  mpTransmit(&simmsg);

  // message was transmitted
  return 1;
}


#if USE_29BIT_LSSFEEDBACK == 1
/****************************************************************
DOES:    Sends an LSS response feedback msg, this transmits
a 29bit CAN ID message with DLC = 0
RETURNS: -
*****************************************************************/
void MCOHW_Push29Message(
  UNSIGNED32 canid // CAN ID to use
  )
{
  SIMCANMESSAGE simmsg;
  int b;

  simmsg.timestamp = 0;
  simmsg.id = canid;
  simmsg.dlc = 0;
  simmsg.flags = SIM_EXT;
  for (b = 0; b < 8; b++) simmsg.data[0] = 0x00;

  mpTransmit(&simmsg);
}
#endif


/**************************************************************************
DOES:    This function returns the global status variable.
CHANGES: The status can be changed anytime by this module, for example from 
         within an interrupt service routine or by any of the other 
         functions in this module.
BITS:    0: INIT - set to 1 after a completed initialization
                   left 0 if not yet inited or init failed
         1: CERR - set to 1 if a CAN bit or frame error occured
         2: ERPA - set to 1 if a CAN "error passive" occured
         3: RXOR - set to 1 if a receive queue overrun occured
         4: TXOR - set to 1 if a transmit queue overrun occured
         5: Reserved
         6: TXBSY - set to 1 if Transmit queue is not empty
         7: BOFF - set to 1 if a CAN "bus off" error occured
**************************************************************************/
UNSIGNED8 MCOHW_GetStatus (
  void
  )
{
  // not supported in simulation
  return 1;
}


/**************************************************************************
DOES:    Gets the value of the current 1 millisecond system timer 
RETURNS: The current timer tick                                   
**************************************************************************/
UNSIGNED16 MCOHW_GetTime
  (
  void
  )
{
  UNSIGNED16 tmp;

  // get copy of timer tick
  tmp = gTimCnt;

  // return timer tick copy
  return tmp;
}


/**************************************************************************
DOES:    Checks if a moment in time has passed (a timestamp has expired)
RETURNS: 0 if timestamp has not yet expired, 1 if the             
         timestamp has expired                                    
**************************************************************************/
UNSIGNED8 MCOHW_IsTimeExpired
  (
  UNSIGNED16 timestamp  // timestamp to check for expiration
  )
{
  UNSIGNED16 time_now;

  // get a copy of the current time
  time_now = gTimCnt;
  // to ensure the minimum runtime
  timestamp++;
  // if timestamp is less than the current time...
  if (time_now >= timestamp)
  {
    // check if the timestamp has expired
    if ((time_now - timestamp) < 0x8000)
    {
      return 1;
    }
    // timestamp has not expired
    else
    {
      return 0;
    }
  }
  // if timestamp is greater than the current time...
  else
  {
    // check if the timestamp has expired
    if ((timestamp - time_now) > 0x8000)
    {
      return 1;
    }
    // timestamp has not expired
    else
    {
      return 0;
    }
  }
}

#if USE_STORE_PARAMETERS

// Simulated non-volatile memory, here: regular RAM
UNSIGNED8 mNVOL[NVOL_STORE_SIZE];
//static UNSIGNED8 *mNVOL; // DEBUG/TEST: here grabbing some free RAM

/**************************************************************************
DOES:    Initializes access to non-volatile memory.
**************************************************************************/
void NVOL_Init (
  void
  )
{
}


/**************************************************************************
DOES:    Reads a data byte from non-volatile memory
NOTE:    The address is relative, an offset to NVOL_STORE_START
RETURNS: The data read from memory
**************************************************************************/
UNSIGNED8 NVOL_ReadByte (
  UNSIGNED16 address // location of byte in NVOL memory
  )
{
  // Protect from illegal address access
  if (address >= NVOL_STORE_SIZE) return 0;
  return mNVOL[address];
}


/**************************************************************************
DOES:    Writes a data byte to non-volatile memory
NOTE:    The address is relative, an offset to NVOL_STORE_START
RETURNS: nothing
**************************************************************************/
void NVOL_WriteByte (
  UNSIGNED16 address, // location of byte in NVOL memory
  UNSIGNED8 data
  )
{
  // Protect from illegal address access
  if (address >= NVOL_STORE_SIZE) return;
  mNVOL[address] = data;
}


/**************************************************************************
DOES:    Is called when a block of write cycles is complete. The driver
         may buffer the data from calls to NVOL_WriteByte in RAM and then
         write the entire buffer to non-volatile memory upon a call to
         this function.
**************************************************************************/
void NVOL_WriteComplete (
  void
  )
{
}

#endif // USE_STORE_PARAMETERS


/**************************************************************************
END OF FILE
**************************************************************************/
