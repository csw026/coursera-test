/**************************************************************************
MODULE:    MAIN
CONTAINS:  DynPDO Example application using MicroCANopen Plus
           Written for CANopen Magic Ultimate simulation system
           www.canopenmagic.com
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#include "mcop_inc.h"
#include "mcop_xod_inc.h"

#ifdef __SIMULATION__
// header files to create dll
#include <windows.h>
#include "mcohwpcsim.h"
#include "simdriver.h"
#endif



/**************************************************************************
DOES:    The main function
RETURNS: nothing
**************************************************************************/
int main(
  void
  )
{

  // Reset/Initialize CANopen communication
  MCOUSER_ResetCommunication();

  // foreground loop
  while(1)
  {
    // Operate on CANopen protocol stack
    while (MCO_ProcessStack());

	  // Check for CAN Err, auto-recover
    if (MCOHW_GetStatus() & HW_BOFF)
    {
      MCOUSER_FatalError(0xF6F6);
    }

#ifdef __SIMULATION__
    // perform main loop operations needed for simulation
    SimDriver_MainLoop();
#endif

  } // end of while(1)
} // end of main



