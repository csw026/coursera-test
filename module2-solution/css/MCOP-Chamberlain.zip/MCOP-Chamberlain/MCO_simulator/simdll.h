/**************************************************************************
MODULE:    SIMDLL
CONTAINS:  simulation dll header file
**************************************************************************/

#ifndef _TESTSIMDLLH_
#define _TESTSIMDLLH_

#include <windows.h>

#ifdef __cplusplus
  #define C "C"
#else
  #define C
#endif

#ifdef _BUILD_DLL_
  #define DLL_FUNC extern C __declspec(dllexport)
#else
  #define DLL_FUNC extern C __declspec(dllimport)
#endif

// #define kludge. If we are being compiled with MSVC, then just tack on a
// leading underscore because Borland C++ will export Foo and Bar as _Foo
// and _Bar respectively
#ifdef _MSC_VER
#define Sim_InterfaceVersion         _Sim_InterfaceVersion
#define Sim_StackVersion             _Sim_StackVersion
#define Sim_Init2                    _Sim_Init2
#define Sim_Init3                    _Sim_Init3
#define Sim_Init4                    _Sim_Init4
#define Sim_Init5                    _Sim_Init5
#define Sim_Init6                    _Sim_Init6
#define Sim_Receive                  _Sim_Receive
#define Sim_COMReceive               _Sim_COMReceive
#define Sim_Start                    _Sim_Start
#define Sim_Tick                     _Sim_Tick
#define Sim_Setup                    _Sim_Setup
#define Sim_BinaryOD                 _Sim_BinaryOD
#define Sim_GetProcessImage          _Sim_GetProcessImage
#define Sim_GetNVOLMemory            _Sim_GetNVOLMemory
#define Sim_Configure2               _Sim_Configure2
#define Sim_ResetODScan              _Sim_ResetODScan
#define Sim_GetNextODEntry           _Sim_GetNextODEntry
#define Sim_WriteProcessImage        _Sim_WriteProcessImage
#define Sim_LockProcessImage         _Sim_LockProcessImage
#define Sim_UnlockProcessImage       _Sim_UnlockProcessImage
#define Sim_Pause                    _Sim_Pause
#define Sim_UnPause                  _Sim_UnPause
#define Sim_Stop                     _Sim_Stop
#define Sim_GetFunctionality         _Sim_GetFunctionality
#endif

// message id flags
#define SIM_RTR 0x01
#define SIM_EXT 0x02
#define SIM_FD  0x04
#define SIM_BRS 0x08

// error code flags returned by resetfunc
#define SIM_NOERROR   0x00
#define SIM_RXOVERRUN 0x40
#define SIM_BOFF      0x80

// process image lock types
#define SIM_READLOCK  0
#define SIM_WRITELOCK 1

// leds
#define SIM_RUNLED 0
#define SIM_ERRLED 1

// describes a CAN message
typedef struct
{
  unsigned long timestamp;   // in microseconds
  unsigned long id;          // message identifier
  unsigned char dlc;         // data length
  unsigned char flags;       // SIM_RTR, SIM_EXT, SIM_FD, SIM_BRS
  unsigned char data[64];    // data bytes
} SIMCANMESSAGE;

// this structure holds all data for one process data entry in the OD
typedef struct
{
  unsigned char idx_lo;       // index of OD entry
  unsigned char idx_hi;       // index of OD entry
  unsigned char subidx;       // subindex of OD entry
  unsigned char len;          // data length in bytes (1-4), plus bits SIMSUPPORT_ODRD, etc.
  unsigned int  offset;       // offset to process data in process image
} SIM_ODENTRY;

// holds a description of the functionality of the stack
typedef struct
{
  unsigned char xod;          // set to 1 if XOD is enabled
  unsigned char dummy[63];    // reserved, always zero
} SIM_FUNCTIONALITY;

// transmit callback function - called by the CANopen stack when it wants to transmit a message
typedef void (*SIMTRANSMITFUNC)(SIMCANMESSAGE *pmsg);

// COM send callback function - called by the CANopen stack when it wants to send a serial byte
typedef unsigned char (*SIMCOMSENDFUNC)(unsigned char byte);

// reset callback function - called when the stack wants to reset
typedef void (*SIMRESETFUNC)(void);

// status callback function - called by the stack when it wants to report an error code
typedef void (*SIMSTATUSFUNC)(unsigned char *perrorcode);

// LED callback function - called by the stack when it wants to update the run or error LEDs
typedef void (*SIMLEDFUNC)(int led, int state);

// NMT callback function - called by the stack when it changes NMT state - value is per the CANopen standard
typedef void (*SIMNMTFUNC)(unsigned char nmtstate);

// node id callback function - called by the stack when it changes node id (e.g. using LSS)
typedef void (*SIMNEWNODEIDFUNC)(unsigned char newnodeid);

// process image update function - called when an entry in the process image changes
typedef void (*SIMUPDATEPROCESSIMAGE)(int level, unsigned int offset, unsigned int length);

// message callback function - called when the node wants to give a message to the user
typedef void (*SIMMESSAGEFUNC)(char *message);

// reset callback function - called when the od has been switched
typedef void (*SIMODSWITCHEDFUNC)(void);

// gets the version of the interface provided by the simulation DLL
// currently not used by PCANopen Magic ProS Eval
DLL_FUNC void __cdecl Sim_InterfaceVersion(unsigned char *pmajor, unsigned char *pminor);

// gets the version of the CANopen stack
DLL_FUNC void __cdecl Sim_StackVersion(unsigned char *pmajor, unsigned char *pminor);

// initialization function - will be called before any other function. Gives the CANopen stack function
// pointers to call
DLL_FUNC void __cdecl Sim_Init2(SIMTRANSMITFUNC ptransmitfunc, SIMRESETFUNC presetfunc, SIMSTATUSFUNC pstatusfunc, SIMLEDFUNC pledfunc,
  SIMNMTFUNC pnmtfunc, SIMNEWNODEIDFUNC pnewnodeidfunc);

// initialization function - will be called before any other function. Gives the CANopen stack function
// pointers to call
DLL_FUNC void __cdecl Sim_Init3(SIMTRANSMITFUNC ptransmitfunc, SIMRESETFUNC presetfunc, SIMSTATUSFUNC pstatusfunc, SIMLEDFUNC pledfunc,
  SIMNMTFUNC pnmtfunc, SIMNEWNODEIDFUNC pnewnodeidfunc, SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc);

// initialization function - will be called before any other function. Gives the CANopen stack function
// pointers to call
DLL_FUNC void __cdecl Sim_Init4(SIMTRANSMITFUNC ptransmitfunc, SIMRESETFUNC presetfunc, SIMSTATUSFUNC pstatusfunc, SIMLEDFUNC pledfunc,
  SIMNMTFUNC pnmtfunc, SIMNEWNODEIDFUNC pnewnodeidfunc, SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc, SIMMESSAGEFUNC pmessagefunc);

// initialization function - will be called before any other function. Gives the CANopen stack function
// pointers to call
DLL_FUNC void __cdecl Sim_Init5(SIMTRANSMITFUNC ptransmitfunc, SIMRESETFUNC presetfunc, SIMSTATUSFUNC pstatusfunc, SIMLEDFUNC pledfunc,
  SIMNMTFUNC pnmtfunc, SIMNEWNODEIDFUNC pnewnodeidfunc, SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc, SIMMESSAGEFUNC pmessagefunc,
  SIMCOMSENDFUNC pcomsendfunc);

// initialization function - will be called before any other function. Gives the CANopen stack function
// pointers to call
DLL_FUNC void __cdecl Sim_Init6(SIMTRANSMITFUNC ptransmitfunc, SIMRESETFUNC presetfunc, SIMSTATUSFUNC pstatusfunc, SIMLEDFUNC pledfunc,
  SIMNMTFUNC pnmtfunc, SIMNEWNODEIDFUNC pnewnodeidfunc, SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc, SIMMESSAGEFUNC pmessagefunc,
  SIMCOMSENDFUNC pcomsendfunc, SIMODSWITCHEDFUNC podswitchedfunc);

// gives a CAN message to the CANopen stack
DLL_FUNC void __cdecl Sim_Receive(SIMCANMESSAGE *pmsg);

// gives a COM port byte to the CANopen stack
DLL_FUNC void __cdecl Sim_COMReceive(unsigned char byte);

// starts the CANopen stack operation
DLL_FUNC void __cdecl Sim_Start(void);

// stops the CANopen stack operation
DLL_FUNC void __cdecl Sim_Stop(void);

// called every 1ms to provide the stack with a timer tick
DLL_FUNC void __cdecl Sim_Tick(void);

// only used by ESA CANopen stacks for additional configuration information
DLL_FUNC unsigned char __cdecl Sim_Setup(unsigned char *psetupfile);

// only used by ESA CANopen stacks for binary ods
DLL_FUNC unsigned char __cdecl Sim_BinaryOD(unsigned char *pbinaryod, unsigned long size);

// gets a pointer to a block of memory used by the CANopen stack to hold real-time data
DLL_FUNC void __cdecl Sim_GetProcessImage(unsigned char **pstart, unsigned int *psize);

// gets a pointer to a block of memory used by the CANopen stack to hold non-volatile data (typically simulated)
DLL_FUNC void __cdecl Sim_GetNVOLMemory(unsigned char **pstart, unsigned int *psize);

// configures the CANopen stack with the node ID, whether to use LSS or NVOL memory and the serial number
DLL_FUNC void __cdecl Sim_Configure2(unsigned char nodeid, int uselss, int ignorenvol, unsigned long serialnumber);

// resets the object dictionary enumeration
DLL_FUNC void __cdecl Sim_ResetODScan(void);

// enumerates the object dictionary - keep calling until null pointer returned
DLL_FUNC SIM_ODENTRY * __cdecl Sim_GetNextODEntry(void);

// updates an entry in the stack process image
DLL_FUNC void __cdecl Sim_WriteProcessImage(unsigned int offset, unsigned char *pdata, unsigned int length);

// locks the process image in the stack so it can be updated
DLL_FUNC void __cdecl Sim_LockProcessImage(int locktype);

// unlocks the process image in the stack so the stack can resume using it
DLL_FUNC void __cdecl Sim_UnlockProcessImage(int locktype);

// pause execution of the CANopen stack
DLL_FUNC void __cdecl Sim_Pause(void);

// unpause execution of the CANopen stack
DLL_FUNC void __cdecl Sim_UnPause(void);

// gets functionality supported by CANopen stack
DLL_FUNC void __cdecl Sim_GetFunctionality(SIM_FUNCTIONALITY *pfunctionality);

#endif
