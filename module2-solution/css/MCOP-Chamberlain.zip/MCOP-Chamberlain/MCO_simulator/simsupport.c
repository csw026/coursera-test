// canopen stack simulation support interface

#ifdef __SIMULATION__
// Only use this module when simulation is active

#include "mco.h"
#include "simsupport.h"
#include "simdriver.h"
#include <string.h>

#if USE_XOD_ACCESS == 1
#include "xod.h"
#endif

#if USE_GENOD_PTR == 1
  // if you get this you need to define USE_GENOD_PTR to zero and eliminate use of ODGENTRYC by making
  // CONSTs into RO in CANopen Architect
  #error Generic OD pointers cannot be used together with the simulation system
#endif

// od scan states
#define ODSCAN_ODPROCTABLE    0
#define ODSCAN_ODGENERICTABLE 1

// Local buffer for one OD record
static SIMSUPPORT_ODENTRY mOD;

// current scan state
static int mODScanState;

// Pointer to OD records
OD_PROCESS_DATA_ENTRY MEM_CONST *mpOD;
OD_GENERIC_DATA_ENTRY MEM_CONST *mgOD;

// Process image
extern UNSIGNED8 MEM_PROC gProcImg[];
// non-volatile memory
#if USE_STORE_PARAMETERS
extern UNSIGNED8 mNVOL[];
#endif

// table with Object Dictionary entries to process Data
extern OD_PROCESS_DATA_ENTRY MEM_CONST gODProcTable[];
extern OD_GENERIC_DATA_ENTRY MEM_CONST gODGenericTable[];


/*****************************************************************
DOES:    Obtains the current size of the process image
RETURNS: The process image size. If no process image in use then
         returns zero.
*****************************************************************/
UNSIGNED32 SimSupport_GetProcessImageSize (
  void
  )
{
  return PROCIMG_SIZE;
}


/*****************************************************************
DOES:    Obtains a pointer to the start of the process image
RETURNS: A pointer to the start of the process image. If no
         process image then returns a null pointer.
*****************************************************************/
UNSIGNED8 *SimSupport_GetProcessImagePtr (
  void
  )
{
  return &(gProcImg[0]);
}


/*****************************************************************
DOES: Writes to the process image. If the data changed is an input
      and the input is mapped to a COS TPDO, then the TPDO must
      be transmitted
*****************************************************************/
void SimSupport_WriteProcessImage (
  UNSIGNED16 offset,   // offset in process image to start writing
  UNSIGNED8 *pdata,    // pointer to data to write
  UNSIGNED16 length    // number of bytes to write
  )
{
  if (offset < PROCIMG_SIZE)
  {
    while ((offset + length) > PROCIMG_SIZE)
    {
      length--;
    }
    memcpy(&gProcImg[offset],pdata,length);
  }
}
  

/*****************************************************************
DOES:    Obtains the current size of the nvol memory
RETURNS: The nvol memory size. If no nvol memory in use then
         returns zero.
*****************************************************************/
UNSIGNED32 SimSupport_GetNVOLSize (
  void
  )
{
#if USE_STORE_PARAMETERS
  return NVOL_STORE_SIZE;
#else
  return 0;
#endif
}


/*****************************************************************
DOES:    Obtains a pointer to the start of the nvol memory
RETURNS: A pointer to the start of the nvol memory. If no
         nvol memory then returns a null pointer.
*****************************************************************/
UNSIGNED8 *SimSupport_GetNVOLPtr (
  void
  )
{
#if USE_STORE_PARAMETERS
  return &(mNVOL[0]);
#else
  return 0;
#endif
}


/*****************************************************************
DOES: Initializes an enumeration of the object dictionary entries
      that contain process data. Must be called before
      SimSupport_GetNextODEntry is called for the first time.
*****************************************************************/
void SimSupport_ResetODScan (
  void
  )
{
  mODScanState = ODSCAN_ODPROCTABLE;

#if USE_XOD_ACCESS == 1
  mpOD = OD_ProcTablePtr(0);
#else
  // initialize pointer
  mpOD = &(gODProcTable[0]);
#endif
}


/*****************************************************************
DOES:    Gets the next object dictionary entry containing process
         data defined in the stack. SimSupport_ResetODScan must
         be called before calling this function for the first
         time.
RETURNS: Pointer to description of object dictionary entry or
         a null pointer if there are no more entries
*****************************************************************/
SIMSUPPORT_ODENTRY *SimSupport_GetNextODEntry (
  void
  )
{
  if (mODScanState == ODSCAN_ODPROCTABLE)
  {
    // Read current record
    mOD.idx_lo = mpOD->idx_lo;
    mOD.idx_hi = mpOD->idx_hi;
    mOD.subidx = mpOD->subidx;
    mOD.len    = mpOD->len & 0x07;
    mOD.offset = ((UNSIGNED16)mpOD->off_hi << 8) | mpOD->off_lo;

    // Increment pointer to handle next record
    mpOD++;

    // Was this the last record?
    if ( (mOD.idx_lo == 0xFF) &&
         (mOD.idx_hi == 0xFF) &&
         (mOD.subidx == 0xFF)
       )
    {
#if USE_EXTENDED_SDO
      mODScanState = ODSCAN_ODGENERICTABLE;

#if USE_XOD_ACCESS == 1
      mgOD = OD_GenericTablePtr(0);
#else
      mgOD = &(gODGenericTable[0]);
#endif

#else
      return 0;
#endif
    }
    else
    {
      return &mOD;
    }
  }
  
  if (mODScanState == ODSCAN_ODGENERICTABLE)
  {
    // keep searching until end of table
    while ((mgOD->idx_lo != 0xFF) && (mgOD->idx_hi != 0xFF) && (mgOD->subidx != 0xFF))
    {
      // get offset into process image
      mOD.offset = ((UNSIGNED16)(mgOD->off_hi) << 8) | mgOD->off_lo;
      // if this data is inside the process image
      if (mOD.offset <= PIMGEND)
      {
        // read next record
        mOD.idx_lo = mgOD->idx_lo;
        mOD.idx_hi = mgOD->idx_hi;
        mOD.subidx = mgOD->subidx;
        //mOD.len    = (UNSIGNED8)(mgOD->length & 0xFF);
        mOD.len = mgOD->len_lo;

        mgOD++;

        return &mOD;
      }
      // data is outside of the process image, e.g. ODGENTRYC with a constant string
      else
      {
        // skip this record
        mgOD++;
      }
    }

    // reached end of table
    return 0;
  }

  return 0;
}

#endif // __SIMULATION__
