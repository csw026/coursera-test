// canopen stack simulation support interface

#ifndef _SIMSUPPORTH_
#define _SIMSUPPORTH_

#ifdef __cplusplus
extern "C" {
#endif

// Defines for access type in OD entries
#define SIMSUPPORT_ODRD 0x10
#define SIMSUPPORT_ODWR 0x20
#define SIMSUPPORT_RMAP 0x40
#define SIMSUPPORT_WMAP 0x80

// this structure holds all data for one process data entry in the OD
typedef struct
{
  UNSIGNED8  idx_lo;       // index of OD entry
  UNSIGNED8  idx_hi;       // index of OD entry
  UNSIGNED8  subidx;       // subindex of OD entry
  UNSIGNED8  len;          // data length in bytes (1-4), plus bits SIMSUPPORT_ODRD, etc.
  UNSIGNED16 offset;       // offset to process data in process image
} SIMSUPPORT_ODENTRY;


/*****************************************************************
DOES:    Obtains the current size of the process image
RETURNS: The process image size. If no process image in use then
         returns zero.
*****************************************************************/
UNSIGNED32 SimSupport_GetProcessImageSize
  (
  void
  );


/*****************************************************************
DOES:    Obtains a pointer to the start of the process image
RETURNS: A pointer to the start of the process image. If no
         process image then returns a null pointer.
*****************************************************************/
UNSIGNED8 *SimSupport_GetProcessImagePtr
  (
  void
  );


/*****************************************************************
DOES: Writes to the process image. If the data changed is an input
      and the input is mapped to a COS TPDO, then the TPDO must
      be transmitted
*****************************************************************/
void SimSupport_WriteProcessImage
  (
  UNSIGNED16 offset,   // offset in process image to start writing
  UNSIGNED8 *pdata,    // pointer to data to write
  UNSIGNED16 length    // number of bytes to write
  );


/*****************************************************************
DOES:    Obtains the current size of the nvol memory
RETURNS: The nvol memory size. If no nvol memory in use then
         returns zero.
*****************************************************************/
UNSIGNED32 SimSupport_GetNVOLSize
  (
  void
  );


/*****************************************************************
DOES:    Obtains a pointer to the start of the nvol memory
RETURNS: A pointer to the start of the nvol memory. If no
         nvol memory then returns a null pointer.
*****************************************************************/
UNSIGNED8 *SimSupport_GetNVOLPtr
  (
  void
  );

  
/*****************************************************************
DOES: Initializes an enumeration of the object dictionary entries
      that contain process data. Must be called before
      SimSupport_GetNextODEntry is called for the first time.
*****************************************************************/
void SimSupport_ResetODScan
  (
  void
  );


/*****************************************************************
DOES:    Gets the next object dictionary entry containing process
         data defined in the stack. SimSupport_ResetODScan must
         be called before calling this function for the first
         time.
RETURNS: Pointer to description of object dictionary entry or
         a null pointer if there are no more entries
*****************************************************************/
SIMSUPPORT_ODENTRY *SimSupport_GetNextODEntry
  (
  void
  );

#ifdef __cplusplus
}
#endif

#endif  // _SIMSUPPORTH_


