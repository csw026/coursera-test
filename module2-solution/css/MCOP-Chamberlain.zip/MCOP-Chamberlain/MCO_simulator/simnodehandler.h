/**************************************************************************
MODULE:    SIMNODEHANDLER
CONTAINS:  simulation dll interface to simnodehandler
**************************************************************************/


#ifndef _SIMNODEHANDLER_H
#define _SIMNODEHANDLER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "simdll.h"

// define to 1 if process image used in stack
#define USE_PROC_IMG 1

// configuration type
typedef struct
{
  unsigned char nodeid;        // the node id to use
  int uselss;                  // set to use lss
  int ignorenvol;              // set to ignore nvol memory
  unsigned long serialnumber;  // the serial number to use
} NODECONFIG;

// pointers to callback functions
extern SIMTRANSMITFUNC       mpTransmit;
extern SIMCOMSENDFUNC        mpCOMSend;
extern SIMRESETFUNC          mpReset;
extern SIMSTATUSFUNC         mpStatus;
extern SIMLEDFUNC            mpLED;
extern SIMNMTFUNC            mpNMT;
extern SIMNEWNODEIDFUNC      mpNewNodeID;
extern SIMUPDATEPROCESSIMAGE mpUpdateProcessImage;
extern SIMMESSAGEFUNC        mpMessage;
extern SIMODSWITCHEDFUNC     mpODSwitched;

extern NODECONFIG gNodeConfig;

#ifdef __cplusplus
}
#endif

#endif // _SIMNODEHANDLER_H

