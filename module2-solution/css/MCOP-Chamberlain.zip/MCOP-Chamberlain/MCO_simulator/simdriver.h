// simulation driver interface

#ifndef _SIMDRIVERH_
#define _SIMDRIVERH_

#ifdef __cplusplus
extern "C" {
#endif

#include "nodecfg.h"

// leds
#define SIMDRV_RUNLED 0
#define SIMDRV_ERRLED 1

// maximum length of a message that can be passed to SimDriver_printf
#define MAX_MESSAGE_LENGTH 500

// if using XOD then simulation system defines binary od
#if USE_XOD_ACCESS
extern UNSIGNED8 *gBinaryConfiguration;
#endif

// configuration
typedef struct _simconfiguration
{
  UNSIGNED8 ignorenvol;                     // 1 = ignore nvol support, 0 = use nvol
  UNSIGNED8 uselss;                         // 1 = enable LSS, 0 = disable LSS
  UNSIGNED8 nodeid;                         // node id to use, 0 = no node id specified
  UNSIGNED32 serialnumber;                  // serial number to use, 0 = no serial number specified
} SIMCONFIGURATION;

/*****************************************************************
DOES:    Gets the simulation configuration for the stack
*****************************************************************/
void SimDriver_GetConfiguration
  (
  SIMCONFIGURATION *psimconfiguration       // location to store configuration
  );


/*****************************************************************
DOES:    Sets a pointer to the binary od
RETURNS: 1 for success, 0 for failure
*****************************************************************/
int SimDriver_SetBinaryOD
  (
  unsigned char *pbinaryod,   // block of binary data
  unsigned long size          // size of block
  );


/*****************************************************************
DOES:    Sends a character to the terminal interface provided by
         the simulation, for example UART output.
RETURNS: the character written or EOF if there was an error
*****************************************************************/
int SimDriver_putchar
  (
  char c     // character to pass to output
  );


/*****************************************************************
DOES:    Receives the next character from the terminal interface
         provided by the simulation, for example UART input.
RETURNS: character received or EOF if end of file or error.
*****************************************************************/
int SimDriver_getchar
  (
  void
  );


/*****************************************************************
DOES: Displays text in a pop up window. Execution is halted
      until the user clicks on the OK button.
*****************************************************************/
void SimDriver_DisplayMessage
  (
  char *ptext            // pointer to buffer containing text to display
  );


/*****************************************************************
DOES: Sends a message to the user interface. Has the same
      prototype as standard C printf
RETURNS: number of characters output or negative number for error
*****************************************************************/
int SimDriver_printf
  (
  char *format,
  ...
  );


/*****************************************************************
DOES: Start logging to a file. Current contents of the file
      will be lost.
*****************************************************************/
void SimDriver_StartLogging
  (
  char *logfilename      // filename of log file
  );


/*****************************************************************
DOES: Stops logging to a file and closes the file
*****************************************************************/
void SimDriver_EndLogging
  (
  void
  );


/*****************************************************************
DOES: Writes a string to the log. Has the same arguments as printf
*****************************************************************/
void SimDriver_Logprintf
  (
  char *format,          // format string
  ...
  );


/*****************************************************************
DOES: Supplies the current NMT state to the simulation system as
      needed. Initially the simulation system will report "unknown"
      until this function is called.
*****************************************************************/
void SimDriver_UpdateNMTState
  (
  UNSIGNED8 newnmtstate  // new nmt state of the stack, using values defined in
                         // DS301
  );


/*****************************************************************
DOES: Supplies the current node ID to the simulation system as
      needed. Useful when node implements LSS
*****************************************************************/
void SimDriver_UpdateNodeID
  (
  UNSIGNED8 newnodeid    // new node ID
  );


/*****************************************************************
DOES: Supplies the current RUN and ERR led states to the
      simulation system.
*****************************************************************/
void SimDriver_UpdateLEDState
  (
  int led,               // SIMDRV_RUNLED or SIMDRV_ERRLED
  int state              // 0 = off, 1 = on
  );


/*****************************************************************
DOES: Tells the simulation system that an entry in the process
      image has changed
*****************************************************************/
void SimDriver_UpdateProcessImage
  (
  int level,             // 1 = app, 2 = pdo, 3 = sdo
  unsigned int offset,   // offset into process image
  unsigned int len       // length of data written to process image in bytes
  );


/*****************************************************************
DOES: Tells the simulation system that the object dictionary has
      been switched
*****************************************************************/
void SimDriver_ODSwitched
  (
  void
  );


/*****************************************************************
DOES: Pauses the main() function. Returns one the main() function
      is actually paused
*****************************************************************/
void SimDriver_Pause
  (
  void
  );


/*****************************************************************
DOES: Unpauses the main() function
*****************************************************************/
void SimDriver_UnPause
  (
  void
  );


/*****************************************************************
DOES: Causes the main() function to stop executing
*****************************************************************/
void SimDriver_Stop
  (
  void
  );


/*****************************************************************
DOES: Must be called for each pass of the infinite loop in main()
      Performs any necessary tasks to ensure the simulation
      DLL works properly
RETURNS: 1 to keep stack executing, 0 to terminate it
*****************************************************************/
int SimDriver_MainLoop
  (
  void
  );

#ifdef __cplusplus
}
#endif

#endif  // _SIMDRIVERH_
