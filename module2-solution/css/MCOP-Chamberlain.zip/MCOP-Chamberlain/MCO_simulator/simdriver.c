// simulation driver interface

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include "mco.h"
#include "mcop.h"
#include "simdriver.h"
#include "simnodehandler.h"
#include "mcohw.h"

// flag to request pausing of the main() function
int mPauseRequest = 0;
// paused state of the main() function
int mPaused = 0;
// flag to request stopping the main() function
int mStopRequest = 0;
// handle to log file
static FILE *mlogfile = 0;

// if using XOD then simulation system defines binary od
#if USE_XOD_ACCESS
UNSIGNED8 *gBinaryConfiguration = NULL;
#endif

/*****************************************************************
DOES:    Gets the simulation configuration for the stack
*****************************************************************/
void SimDriver_GetConfiguration
  (
  SIMCONFIGURATION *psimconfiguration       // location to store configuration
  )
{
  psimconfiguration->ignorenvol   = gNodeConfig.ignorenvol;
  psimconfiguration->uselss       = gNodeConfig.uselss;
  psimconfiguration->nodeid       = gNodeConfig.nodeid;
  psimconfiguration->serialnumber = gNodeConfig.serialnumber;
}


/*****************************************************************
DOES:    Sets a pointer to the binary od
RETURNS: 1 for success, 0 for failure
*****************************************************************/
int SimDriver_SetBinaryOD
  (
  unsigned char *pbinaryod,   // block of binary data
  unsigned long size          // size of block
  )
{
#if USE_XOD_ACCESS == 1
  SimDriver_printf("\nMicro CANopen loading Object Dictionary: received binary %d bytes in size\n", size);

  gBinaryConfiguration = (UNSIGNED8 *)malloc(size);
  if (gBinaryConfiguration == NULL) return 0;

  memcpy(gBinaryConfiguration, pbinaryod, size);

  return 1;
#else
  return 0;
#endif
}


/*****************************************************************
DOES:    Sends a character to the terminal interface provided by
         the simulation, for example UART output.
RETURNS: the character written or EOF if there was an error
*****************************************************************/
int SimDriver_putchar
  (
  char c     // character to pass to output
  )
{
  return c;
}


/*****************************************************************
DOES:    Receives the next character from the terminal interface
         provided by the simulation, for example UART input.
RETURNS: character received or EOF if end of file or error.
*****************************************************************/
int SimDriver_getchar
  (
  void
  )
{
  return 0;
}


/*****************************************************************
DOES: Displays text in a pop up window. Execution is halted
      until the user clicks on the OK button.
*****************************************************************/
void SimDriver_DisplayMessage
  (
  char *ptext            // pointer to buffer containing text to display
  )
{
  MessageBox(NULL, ptext, "CANopen Stack", MB_OK | MB_ICONINFORMATION);
}

/*****************************************************************
DOES: Sends a message to the user interface. Has the same
      prototype as standard C printf
RETURNS: number of characters output or negative number for error
*****************************************************************/
int SimDriver_printf
  (
  char *format,
  ...
  )
{
  va_list args;
  char message[MAX_MESSAGE_LENGTH];

  if (!mpMessage) return -1;

  va_start(args, format);
  vsprintf_s(message, MAX_MESSAGE_LENGTH, format, args);

  mpMessage(message);

  va_end(args);

  return strlen(message);
}


/*****************************************************************
DOES: Start logging to a file. Current contents of the file
      will be lost.
*****************************************************************/
void SimDriver_StartLogging
  (
  char *logfilename      // filename of log file
  )
{
  fopen_s(&mlogfile, logfilename, "w");
}


/*****************************************************************
DOES: Stops logging to a file and closes the file
*****************************************************************/
void SimDriver_EndLogging
  (
  void
  )
{
  if (mlogfile) fclose(mlogfile);
}


/*****************************************************************
DOES: Writes a string to the log. Has the same arguments as printf
*****************************************************************/
void SimDriver_Logprintf
  (
  char *format,          // format string
  ...
  )
{
  va_list args;

  if (!mlogfile) return;

  // output to debug file
  va_start(args, format);
  vfprintf(mlogfile, format, args);
  fflush(mlogfile);
}


/*****************************************************************
DOES: Supplies the current NMT state to the simulation system as
      needed. Initially the simulation system will report "unknown"
      until this function is called.
*****************************************************************/
void SimDriver_UpdateNMTState
  (
  UNSIGNED8 newnmtstate  // new nmt state of the stack, using values defined in
                         // DS301
  )
{
  // no callback function? then do nothing
  if (!mpNMT) return;

  // pass nmt state to simnodehandler
  mpNMT(newnmtstate);
}


/*****************************************************************
DOES: Supplies the current node ID to the simulation system as
      needed. Useful when node implements LSS
*****************************************************************/
void SimDriver_UpdateNodeID
  (
  UNSIGNED8 newnodeid    // new node ID
  )
{
  // no callback function? then do nothing
  if (!mpNewNodeID) return;

  // pass node ID to simnodehandler
  mpNewNodeID(newnodeid);
}


/*****************************************************************
DOES: Supplies the current RUN and ERR led states to the
      simulation system.
*****************************************************************/
void SimDriver_UpdateLEDState
  (
  int led,               // SIMDRV_RUNLED or SIMDRV_ERRLED
  int state              // 0 = off, 1 = on
  )
{
  // no callback function? then do nothing
  if (!mpLED) return;

  // call callback function
  if (led == SIMDRV_RUNLED)
  {
    mpLED(SIM_RUNLED, state);
  }
  else if (led == SIMDRV_ERRLED)
  {
    mpLED(SIM_ERRLED, state);
  }
}


/*****************************************************************
DOES: Tells the simulation system that an entry in the process
      image has changed
*****************************************************************/
void SimDriver_UpdateProcessImage
  (
  int level,             // 1 = app, 2 = pdo, 3 = sdo
  unsigned int offset,   // offset into process image
  unsigned int len       // length of data written to process image in bytes
  )
{
  // no callback function? then do nothing
  if (!mpUpdateProcessImage) return;

  mpUpdateProcessImage(level, offset, len);
}


/*****************************************************************
DOES: Tells the simulation system that the object dictionary has
      been switched
*****************************************************************/
void SimDriver_ODSwitched
  (
  void
  )
{
  // no callback function? then do nothing
  if (!mpODSwitched) return;

  mpODSwitched();
}


/*****************************************************************
DOES: Pauses the main() function. Returns one the main() function
      is actually paused
*****************************************************************/
void SimDriver_Pause
  (
  void
  )
{
  // set pause request flag
  mPauseRequest = 1;
  // wait for sim dll main() to actually be paused
  while (!mPaused)
  {
    // allow sim dll to execute
    Sleep(2);
  }
}


/*****************************************************************
DOES: Causes the main() function to stop executing
*****************************************************************/
void SimDriver_Stop
  (
  void
  )
{
  // set stop request flag
  mStopRequest = 1;
}

/*****************************************************************
DOES: Unpauses the main() function
*****************************************************************/
void SimDriver_UnPause
  (
  void
  )
{
  // clear pause
  mPaused = 0;
}


/*****************************************************************
DOES: Must be called for each pass of the infinite loop in main()
      Performs any necessary tasks to ensure the simulation
      DLL works properly
RETURNS: 1 to keep stack executing, 0 to terminate it
*****************************************************************/
int SimDriver_MainLoop
  (
  void
  )
{
  // if requested, stop executing
  if (mStopRequest) return 0;

  // allow other threads to run
  Sleep(2);

  // if a pause has been requested...
  if (mPauseRequest)
  {
    // now paused
    mPaused = 1;
    // clear request flag
    mPauseRequest = 0;
  }

  // if paused then do nothing
  while (mPaused)
  {
    Sleep(2);
  }

  // keep going
  return 1;
}
