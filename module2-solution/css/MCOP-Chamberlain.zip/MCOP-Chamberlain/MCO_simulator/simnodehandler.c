/**************************************************************************
MODULE:    SIMNODEHANDLER
CONTAINS:  simulation dll interface to simnodehandler
**************************************************************************/

// header file defining dll interface
#include <windows.h>
#include <stdio.h>
#define _BUILD_DLL_
#include "simdll.h"
#include "mco.h"
#include "mcop.h"
#include "nodecfg.h"
#include "procimg.h"
#include "simnodehandler.h"
#include "simsupport.h"
#include "simdriver.h"
#include "mcohwpcsim.h"

// pointers to callback functions
SIMTRANSMITFUNC mpTransmit = 0;
SIMCOMSENDFUNC mpCOMSend = 0;
SIMRESETFUNC mpReset = 0;
SIMSTATUSFUNC mpStatus = 0;
SIMLEDFUNC mpLED = 0;
SIMNMTFUNC mpNMT = 0;
SIMNEWNODEIDFUNC mpNewNodeID = 0;
SIMUPDATEPROCESSIMAGE mpUpdateProcessImage = 0;
SIMMESSAGEFUNC mpMessage = 0;
SIMODSWITCHEDFUNC mpODSwitched = 0;

// stores node configuration
NODECONFIG gNodeConfig = {0x40, 0, 0, 0x00000000};

// stores the current od entry being read
SIM_ODENTRY mODEntry;

extern void main(void);
#if USE_REMOTE_ACCESS == 1
extern void MCOHW_COMReceive(UNSIGNED8 byte);
#endif

/**************************************************************************
DOES:  Called when DLL loaded and started. See win32 api for a description
***************************************************************************/
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
  return 1;
}


/**************************************************************************
DOES:  Returns the version number of the simulation dll interface
       Assumes version string has the format "version x.xx"
***************************************************************************/
void Sim_InterfaceVersion
  (
  unsigned char *pmajor,   // pointer to location to store major version num
  unsigned char *pminor    // pointer to location to store minor version num
  )
{
  *pmajor = 2;
  *pminor = 1;
}


/**************************************************************************
DOES:  Returns the version of the stack
***************************************************************************/
void Sim_StackVersion
  (
  unsigned char *pmajor,   // pointer to location to store major version num
  unsigned char *pminor    // pointer to location to store minor version num
  )
{
  char mVersion[] = "version 2.51";
  char *pmajorstart;
  char *pminorstart;
  int major;
  int minor;

  pmajorstart = strchr(mVersion, ' ') + 1;
  pminorstart = strchr(mVersion, '.') + 1;
  *(pminorstart - 1) = '\0';

  major = (int)strtol(pmajorstart, (char **)NULL, 10);
  minor = (int)strtol(pminorstart, (char **)NULL, 10);

  *pmajor = major;
  *pminor = minor;
}


/**************************************************************************
DOES:  Called by simnodehandler to perform initialization
***************************************************************************/
void Sim_Init2
  (
  SIMTRANSMITFUNC ptransmitfunc,                    // pointer to transmit func in simnodehandler
  SIMRESETFUNC presetfunc,                          // pointer to reset func in simnodehandler
  SIMSTATUSFUNC pstatusfunc,                        // pointer to status func in simnodehandler
  SIMLEDFUNC pledfunc,                              // pointer to led func in simnodehandler
  SIMNMTFUNC pnmtfunc,                              // pointer to nmt func in simnodehandler
  SIMNEWNODEIDFUNC pnewnodeidfunc                   // pointer to new node ID func in simnodehandler
  )
{
  mpTransmit           = ptransmitfunc;
  mpReset              = presetfunc;
  mpStatus             = pstatusfunc;
  mpLED                = pledfunc;
  mpNMT                = pnmtfunc;
  mpNewNodeID          = pnewnodeidfunc;
}


/**************************************************************************
DOES:  Called by simnodehandler to perform initialization
***************************************************************************/
void Sim_Init3
  (
  SIMTRANSMITFUNC ptransmitfunc,                    // pointer to transmit func in simnodehandler
  SIMRESETFUNC presetfunc,                          // pointer to reset func in simnodehandler
  SIMSTATUSFUNC pstatusfunc,                        // pointer to status func in simnodehandler
  SIMLEDFUNC pledfunc,                              // pointer to led func in simnodehandler
  SIMNMTFUNC pnmtfunc,                              // pointer to nmt func in simnodehandler
  SIMNEWNODEIDFUNC pnewnodeidfunc,                  // pointer to new node ID func in simnodehandler
  SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc     // pointer to update process image func in simnodehandler
  )
{
  mpTransmit           = ptransmitfunc;
  mpReset              = presetfunc;
  mpStatus             = pstatusfunc;
  mpLED                = pledfunc;
  mpNMT                = pnmtfunc;
  mpNewNodeID          = pnewnodeidfunc;
  mpUpdateProcessImage = pupdateprocessimagefunc;
}


/**************************************************************************
DOES:  Called by simnodehandler to perform initialization
***************************************************************************/
void Sim_Init4
  (
  SIMTRANSMITFUNC ptransmitfunc,                    // pointer to transmit func in simnodehandler
  SIMRESETFUNC presetfunc,                          // pointer to reset func in simnodehandler
  SIMSTATUSFUNC pstatusfunc,                        // pointer to status func in simnodehandler
  SIMLEDFUNC pledfunc,                              // pointer to led func in simnodehandler
  SIMNMTFUNC pnmtfunc,                              // pointer to nmt func in simnodehandler
  SIMNEWNODEIDFUNC pnewnodeidfunc,                  // pointer to new node ID func in simnodehandler
  SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc,    // pointer to update process image func in simnodehandler
  SIMMESSAGEFUNC pmessagefunc                       // pointer to message func in simnodehandler
  )
{
  mpTransmit           = ptransmitfunc;
  mpReset              = presetfunc;
  mpStatus             = pstatusfunc;
  mpLED                = pledfunc;
  mpNMT                = pnmtfunc;
  mpNewNodeID          = pnewnodeidfunc;
  mpUpdateProcessImage = pupdateprocessimagefunc;
  mpMessage            = pmessagefunc;
}


/**************************************************************************
DOES:  Called by simnodehandler to perform initialization
***************************************************************************/
void Sim_Init5
  (
  SIMTRANSMITFUNC ptransmitfunc,                    // pointer to transmit func in simnodehandler
  SIMRESETFUNC presetfunc,                          // pointer to reset func in simnodehandler
  SIMSTATUSFUNC pstatusfunc,                        // pointer to status func in simnodehandler
  SIMLEDFUNC pledfunc,                              // pointer to led func in simnodehandler
  SIMNMTFUNC pnmtfunc,                              // pointer to nmt func in simnodehandler
  SIMNEWNODEIDFUNC pnewnodeidfunc,                  // pointer to new node ID func in simnodehandler
  SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc,    // pointer to update process image func in simnodehandler
  SIMMESSAGEFUNC pmessagefunc,                      // pointer to message func in simnodehandler
  SIMCOMSENDFUNC pcomsendfunc                       // pounter to COM send func in simnodehandler
  )
{
  mpTransmit           = ptransmitfunc;
  mpReset              = presetfunc;
  mpStatus             = pstatusfunc;
  mpLED                = pledfunc;
  mpNMT                = pnmtfunc;
  mpNewNodeID          = pnewnodeidfunc;
  mpUpdateProcessImage = pupdateprocessimagefunc;
  mpMessage            = pmessagefunc;
  mpCOMSend            = pcomsendfunc;
}


/**************************************************************************
DOES:  Called by simnodehandler to perform initialization
***************************************************************************/
void Sim_Init6
  (
  SIMTRANSMITFUNC ptransmitfunc,                    // pointer to transmit func in simnodehandler
  SIMRESETFUNC presetfunc,                          // pointer to reset func in simnodehandler
  SIMSTATUSFUNC pstatusfunc,                        // pointer to status func in simnodehandler
  SIMLEDFUNC pledfunc,                              // pointer to led func in simnodehandler
  SIMNMTFUNC pnmtfunc,                              // pointer to nmt func in simnodehandler
  SIMNEWNODEIDFUNC pnewnodeidfunc,                  // pointer to new node ID func in simnodehandler
  SIMUPDATEPROCESSIMAGE pupdateprocessimagefunc,    // pointer to update process image func in simnodehandler
  SIMMESSAGEFUNC pmessagefunc,                      // pointer to message func in simnodehandler
  SIMCOMSENDFUNC pcomsendfunc,                      // pointer to COM send func in simnodehandler
  SIMODSWITCHEDFUNC podswitchedfunc                 // pointer to OD switched func in simnodehandler
  )
{
  mpTransmit           = ptransmitfunc;
  mpReset              = presetfunc;
  mpStatus             = pstatusfunc;
  mpLED                = pledfunc;
  mpNMT                = pnmtfunc;
  mpNewNodeID          = pnewnodeidfunc;
  mpUpdateProcessImage = pupdateprocessimagefunc;
  mpMessage            = pmessagefunc;
  mpCOMSend            = pcomsendfunc;
  mpODSwitched         = podswitchedfunc;
}


/**************************************************************************
DOES:  Called by simnodehandler when a can message received
       This function must execute as quickly as possible
***************************************************************************/
void Sim_Receive
  (
  SIMCANMESSAGE *pmsg    // pointer to description of message received
  )
{
  CAN_MSG canmsg;
  int b;

  // copy message to CAN_MSG format
  if (pmsg->flags & SIM_EXT)
  {
    canmsg.ID = (COBID_TYPE)(pmsg->id & ~COBID_MASK);
    canmsg.ID |= COBID_EXT;
  }
  else
  {
    canmsg.ID = pmsg->id & 0x7FF;
  }

  // currently don't support fd
  // to do - support fd here
  if (pmsg->flags & SIM_FD)
  {
    // ignore the message
    return;
  }

  canmsg.LEN = pmsg->dlc;
  for (b = 0; b < pmsg->dlc; b++)
  {
    canmsg.BUF[b] = pmsg->data[b];
  }

  // pass to hardware interface
  MCOHW_ReceiveMessage(&canmsg);
}


/**************************************************************************
DOES:  Called by simnodehandler when a byte received from COM port
       This function must execute as quickly as possible
***************************************************************************/
void Sim_COMReceive
  (
  UNSIGNED8 byte         // byte to receive
  )
{
#if USE_REMOTE_ACCESS == 1
  // back to COM driver
  MCOHW_COMReceive(byte);
#endif
}


/**************************************************************************
DOES:  Called by simnodehandler to start execution of the stack
***************************************************************************/
void Sim_Start
  (
  void
  )
{
  main();
}


/**************************************************************************
DOES:  Called by simnodehandler to stop execution of the stack
***************************************************************************/
void Sim_Stop
  (
  void
  )
{
  SimDriver_Stop();
}

/**************************************************************************
DOES:  Called every 1ms by simnodehandler to update the timer tick
***************************************************************************/
void Sim_Tick
  (
  void
  )
{
  // pass to hardware interface
  MCOHW_TimerISR();
}


/**************************************************************************
DOES:    Called by simnodehandler to load a setup file to configure the
         stack with. only called if Sim_SetupSupported returns 1
RETURNS: Returns 1 if setup file valid and used
         Returns 0 for invalid setup file or setup file not used
***************************************************************************/
unsigned char Sim_Setup
  (
  unsigned char *psetupfile   // path to setup file
  )
{
  // not supported in MicroCANopen Plus
  return 0;
}


/**************************************************************************
DOES:    Called by simnodehandler to provide a binary object dictionary
         Sim DLL must make it's own copy of the data
RETURNS: 1 for success, 0 for error
***************************************************************************/
unsigned char Sim_BinaryOD
  (
  unsigned char *pbinaryod,   // block of binary data
  unsigned long size          // size of block
  )
{
  // pass to sim driver so sim dll can use it
  return SimDriver_SetBinaryOD(pbinaryod, size);
}


/**************************************************************************
DOES:    Called by simnodehandler to obtain a pointer to the process image
         and the size of the process image
RETURNS: nothing
***************************************************************************/
void Sim_GetProcessImage
  (
  unsigned char **pstart,  // set to point to process image, or null if none
  unsigned int *psize      // filled in with process image size
  )
{
#if (USE_PROC_IMG == 1)
  *pstart = SimSupport_GetProcessImagePtr();
  *psize = SimSupport_GetProcessImageSize();
#else
  *pstart = 0;
  *psize = 0;
#endif
}


/**************************************************************************
DOES:    Called by simnodehandler to obtain a pointer to the nvol memory
         and the size of the nvol memory
RETURNS: nothing
***************************************************************************/
void Sim_GetNVOLMemory
  (
  unsigned char **pstart,  // set to point to nvol memory, or null if none
  unsigned int *psize      // filled in with nvol memory size
  )
{
  *pstart = SimSupport_GetNVOLPtr();
  *psize = SimSupport_GetNVOLSize();
}


/**************************************************************************
DOES:    Receives the configuration for the CANopen stack, which the stack
         obtains when needed by calling SimSupport_GetConfiguration
RETURNS: nothing
***************************************************************************/
void Sim_Configure2
  (
  unsigned char nodeid,         // node id to use
  int uselss,                   // set to use lss
  int ignorenvol,               // set to ignore nvol memory
  unsigned long serialnumber    // serial number to use
  )
{
  // store settings
  gNodeConfig.nodeid       = nodeid;
  gNodeConfig.uselss       = uselss;
  gNodeConfig.ignorenvol   = ignorenvol;
  gNodeConfig.serialnumber = serialnumber;
}

/**************************************************************************
DOES:    Performs initialization before starting the read of the sim
         dll's object dictionary. Must be called before Sim_GetNextODEntry
RETURNS: nothing
***************************************************************************/
void Sim_ResetODScan
  (
  void
  )
{
  SimSupport_ResetODScan();
}

/**************************************************************************
DOES:    Gets the next object dictionary defined in the simulation dll or
         indicates no more entries
RETURNS: pointer to description of od entry or null pointer if no more
         entries
***************************************************************************/
SIM_ODENTRY *Sim_GetNextODEntry
  (
  void
  )
{
  SIMSUPPORT_ODENTRY *pssodentry;

  // get next entry
  pssodentry = SimSupport_GetNextODEntry();
  // if null then return null pointer
  if (pssodentry == 0) return 0;

  // copy to output structure
  mODEntry.idx_lo = pssodentry->idx_lo;
  mODEntry.idx_hi = pssodentry->idx_hi;
  mODEntry.subidx = pssodentry->subidx;
  mODEntry.len    = pssodentry->len;
  mODEntry.offset = pssodentry->offset;

  // return pointer to output structure
  return &mODEntry;
}

/**************************************************************************
DOES:    Writes data into the process image
RETURNS: nothing
***************************************************************************/
void Sim_WriteProcessImage
  (
  unsigned int offset,        // offset in process image to start writing
  unsigned char *pdata,       // pointer to data to write
  unsigned int length         // number of bytes to write
  )
{
  SimSupport_WriteProcessImage(offset, pdata, length);
}

/**************************************************************************
DOES:    Locks the process image from reads or writes
RETURNS: nothing
***************************************************************************/
void Sim_LockProcessImage
  (
  int locktype            // set to SIM_READLOCK or SIM_WRITELOCK
  )
{
  if (locktype == SIM_READLOCK)
  {
    LOCK_PI_READ;
  }
  else if (locktype == SIM_WRITELOCK)
  {
    LOCK_PI_WRITE;
  }
}

/**************************************************************************
DOES:    Unlocks the process image to allow reads or writes
RETURNS: nothing
***************************************************************************/
void Sim_UnlockProcessImage
  (
  int locktype            // set to SIM_READLOCK or SIM_WRITELOCK
  )
{
  if (locktype == SIM_READLOCK)
  {
    UNLOCK_PI_READ;
  }
  else if (locktype == SIM_WRITELOCK)
  {
    UNLOCK_PI_WRITE;
  }
}


/**************************************************************************
DOES:    Pauses the main() function. Returns when paused.
RETURNS: nothing
***************************************************************************/
void Sim_Pause
  (
  void
  )
{
  SimDriver_Pause();
}


/**************************************************************************
DOES:    Unpauses the main() function.
RETURNS: nothing
***************************************************************************/
void Sim_UnPause
  (
  void
  )
{
  SimDriver_UnPause();
}

/**************************************************************************
DOES:    Gets the functionality of the stack configuration
RETURNS: nothing
***************************************************************************/
void Sim_GetFunctionality
  (
  SIM_FUNCTIONALITY *pfunctionality
  )
{
  // set everything to zero
  memset((unsigned char *)pfunctionality, 0, sizeof(SIM_FUNCTIONALITY));

#if (USE_XOD_ACCESS == 1)
  pfunctionality->xod = 1;
#endif
}
