/**************************************************************************
MODULE:    MAIN
CONTAINS:  DS401 Example application using MicroCANopen Plus
           Written for PCANopen Magic ProDS simulation system
           www.canopenmagic.com
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#ifdef __SIMULATION__
// header files to create dll
#include <windows.h>
#include "mcohwpcsim.h"
#include "simdriver.h"
#endif

#include "mcop_inc.h"


// VS debug support (not express versions)
#if defined(__SIMULATION__) && defined(_DEBUG) 
extern unsigned char launchDebugger();
#endif

/**************************************************************************
DOES:    The main function
RETURNS: nothing
**************************************************************************/
int main(
  void
  )
 {
UNSIGNED32 pot1 = 0;  // Analog value / counter
UNSIGNED32 pot2 = 0;  // Analog value / counter
UNSIGNED32 pot3 = 0;  // Analog value / counter
UNSIGNED32 pot4 = 0;  // Analog value / counter
UNSIGNED8 buf[8];    // buffer to process image
UNSIGNED16 timeout;  // timeout for delays

#if defined(__SIMULATION__) && defined(_DEBUG) 
  if (launchDebugger())
  {
    // Stop execution so the debugger can take over
    DebugBreak();
  }
#endif

  // Reset/Initialize CANopen communication
  MCOUSER_ResetCommunication();

  timeout = MCOHW_GetTime();
  
#ifdef __SIMULATION__
  SimDriver_printf("Entering main loop...\n");
#endif

  // foreground loop
  while(1)
  {
    // Operate on CANopen protocol stack
    while (MCO_ProcessStack());

    // Update process data
    // Echo digital data
    MCO_ReadProcessData(buf,1,P620001_DIGOUTPUT8_1);
	  MCO_WriteProcessData(P600001_DIGINPUT8_1,1,buf);

    // analog inputs are timer
    if (MCOHW_IsTimeExpired(timeout))
    {
		  timeout = MCOHW_GetTime() + 50;
		
		  pot1++;

		  if (pot1 & 1)
		  {
			  pot2++;
			  if (pot2 & 1)
			  {
				  pot3++;
				  if (pot3 & 1)
				  {
					  pot4++;
				  }
			  }
		  }
	  }

    buf[0] = pot1 & 0x000000FF; // lo byte
    buf[1] = (pot1 >> 8) & 0x000000FF; // hi byte
    MCO_WriteProcessData(P640101_ANALOGINPUT16_1,2,buf);

    buf[0] = pot2 & 0x000000FF; // lo byte
    buf[1] = (pot2 >> 8) & 0x000000FF; // hi byte
    MCO_WriteProcessData(P640102_ANALOGINPUT16_2,2,buf);

	  // Check for CAN Err, auto-recover
    if (MCOHW_GetStatus() & HW_BOFF)
    {
      MCOUSER_FatalError(0xF6F6);
    }

#ifdef __SIMULATION__
    // perform main loop operations needed for simulation
    SimDriver_MainLoop();
#endif

  } // end of while(1)
} // end of main



