/**************************************************************************
MODULE:    MCOHW_CFG.H
CONTAINS:  MicroCANopen hardware configuration
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-08-18 11:41:44 -0500 (Sat, 18 Aug 2018) $
           $LastChangedRevision: 4336 $
***************************************************************************/ 

#ifndef _MCOHW_CFG_H
#define _MCOHW_CFG_H


// CANopen Data Types
#include "mco_types.h"


/**************************************************************************
MACROS: Memory copy and compare to use
**************************************************************************/
#include "string.h"

#define MEM_CPY_FAR(d,s,l) memcpy((void *)d,(void *)s,l)
#define MEM_CPY memcpy
#define MEM_CMP memcmp


/**************************************************************************
MACROS: RTOS SLEEP FUNCTION
**************************************************************************/

// If used in RTOS, allow other tasks to run in blocking function calls
// Only define RTOS_SLEEP when an RTOS is used!
// #define RTOS_SLEEP Sleep(3);
#define RTOS_SLEEP
#define RTOS_LOCK_PI(access,area)
#define RTOS_UNLOCK_PI(access,area)


/**************************************************************************
DEFINES: BASIC CAN COMMUNICATION
Modify these for your application
**************************************************************************/

// Default CAN bitrate
#define CAN_BITRATE 125

// Use CAN SW Filtering
#define USE_CANSWFILTER 1

// use 29-bit CAN message for LSS feedback
#define USE_29BIT_LSSFEEDBACK 0


/**************************************************************************
DEFINES: CAN HARDWARE DRIVER DEFINITIONS
**************************************************************************/

// if defined a SW FIFO for CAN receive and transmit is used
#define USE_CANFIFO 1

// Tx FIFO depth (must be 0, 4, 8, 16 or 32)
#define TXFIFOSIZE 8

// Rx FIFO depth (must be 0, 4, 8, 16 or 32)
#define RXFIFOSIZE 8

// Manager Rx FIFO depth (must be 0, 4, 8, 16 or 32)
#define MGRFIFOSIZE 0


/**************************************************************************
DEFINES: BOOTLOADER SUPPORT
**************************************************************************/
// If enabled, supports the ESAcademy CANopen bootloader, copy values
// from bootloader configuration
#ifndef __SIMULATION__
// #define REBOOT_FLAG_ADR     0xFFFFFFFFUL
// #define REBOOT_FLAG         *(volatile UNSIGNED32 *)REBOOT_FLAG_ADR
// #define REBOOT_BOOTLOAD_VAL 0x21654387
#endif // ifndef __SIMULATION__

#endif // _MCOHW_CFG_H

/*----------------------- END OF FILE ----------------------------------*/
