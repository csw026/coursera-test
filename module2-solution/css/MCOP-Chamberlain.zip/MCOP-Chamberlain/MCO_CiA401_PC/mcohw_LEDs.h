/**************************************************************************
MODULE:    MCOHW_LED
CONTAINS:  Macro definition for LED switching
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   This file may be freely distributed.
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#ifndef _LED_H
#define _LED_H

#if USE_LEDS

#ifdef __SIMULATION__

#include "simdriver.h"

#define LED_RUN_ON  SimDriver_UpdateLEDState(SIMDRV_RUNLED, 1) 
#define LED_RUN_OFF SimDriver_UpdateLEDState(SIMDRV_RUNLED, 0)
#define LED_ERR_ON  SimDriver_UpdateLEDState(SIMDRV_ERRLED, 1) 
#define LED_ERR_OFF SimDriver_UpdateLEDState(SIMDRV_ERRLED, 0) 

#else
// LPC200 version
#define LED_RUN_ON  {}
#define LED_RUN_OFF {}
#define LED_ERR_ON  {}
#define LED_ERR_OFF {} 

#endif // __SIMULATION__

#endif // USE_LEDS

#endif
