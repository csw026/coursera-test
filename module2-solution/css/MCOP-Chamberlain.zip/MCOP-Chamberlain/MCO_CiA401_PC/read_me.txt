MicroCANopen Plus CiA 401 Example Implementation
================================================

CONTAINS:  Example application using MicroCANopen
           Tested with CANopen Magic Ultimate Simulation System
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION "MicroCANopen Plus"
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17


HOW TO BUILD THIS PROJECT
=========================

1. Install the free Borland C++ Compiler

   http://www.borland.com/bcppbuilder/freecompiler

2. Edit 'makefile' to ensure the paths match the location where you installed the compiler
   and CANopen Architect EDS (if available).

3. Make the DLL by entering at a command prompt:

   make clean
   make

   If the Borland make tool is not in your search path or you use a different make version,
   you must call Borland make with it's full path.


Implementation Description
==========================

(assumed node id of 0x07)

Messages generated:
0x707 - Heartbeat
  Disabled
0x187 - TPDO1 - Four bytes of digital inputs.
				Transmit Trigger: 100ms event time
0x287 - TPDO2 - Two 16-bit analog inputs.
				Transmit Trigger: 250ms event time and 20ms inhibit time

Messages received:
0x000 - NMT Master command message
0x207 - RPDO1 - Four bytes of digital outputs. 
                Copied to TPDO1.
0x307 - RPDO2 - Two 16-bit analog outputs.
                Copied to TPDO2.
0x7xx - HBCon - Depending on heartbeat consumer configuration.


Note on CANopen Conformance
The provided example program passes the CANopen conformance test with 
some limitations:

a) The available version of the conformance test (2.0.02) can not 
correctly deal with nodes that only support heartbeat and have no 
node guarding.

b) The conformance test offers limited flexibility in regards to
pre-configured nodes. In order for an EDS to pass the check, many
defaults are expected to be zero. However, pre-configured nodes
typically do not use zeros for event and other timers.


