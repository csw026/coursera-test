/**************************************************************************
MODULE:    USER
CONTAINS:  MicroCANopen Object Dictionary and Process Image implementation
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#include "mcop_inc.h"

#include "stackinit.h"

#ifdef __SIMULATION__
// header files to create dll
#include <windows.h>
#include "mcohwpcsim.h"
#include "simnodehandler.h"
#include "simdriver.h"
#endif


/**************************************************************************
DOES:    Call-back function for occurance of a fatal error. 
         Stops operation and displays blnking error pattern on LED
**************************************************************************/
void MCOUSER_FatalError (UNSIGNED16 ErrCode)
{
  // Remember last error for stack
  gMCOConfig.last_fatal = ErrCode;

#if USE_LEDS
  LED_ERR_ON;
  gMCOConfig.LEDErr = LED_ON;
#endif

#if USE_EMCY
  MCOP_PushEMCY(0x6100,(UNSIGNED8)(ErrCode >> 8),(UNSIGNED8)ErrCode,0,0,0);
#endif // USE_EMCY

#ifdef __SIMULATION__
  SimDriver_printf("Fatal error 0x%4.4X\n", ErrCode);
#endif

  // Wait 10ms
  Sleep(10);

  if (ErrCode >= ERR_FATAL)
  { // Fatal error, should abort/reset
    MCOUSER_ResetApplication();
  }

  // Warning only, simply timeout, then continue
}

/**************************************************************************
DOES:    Call-back function for reset application.
         Starts the watchdog and waits until watchdog causes a reset.
RETURNS: nothing
**************************************************************************/
void MCOUSER_ResetApplication (
  void
  )
{
#ifdef __SIMULATION__
  SimDriver_printf("Resetting...\n");
#endif

  // if reset callback function has been passed from the simnodehandler
  // then call it
  // reset function does not return
  if (mpReset != 0) 
  {
    mpReset();  
  }
}

/**************************************************************************
DOES:    Call-back function for reset communication.
         Re-initializes the process image and the entire MicroCANopen
         communication.
**************************************************************************/
void MCOUSER_ResetCommunication (void)
{
UNSIGNED16 can_bps;
UNSIGNED8 node_id;
#ifdef __SIMULATION__
SIMCONFIGURATION simconfiguration;

  // Get Node ID from simulation driver
  SimDriver_GetConfiguration(&simconfiguration);
#endif

#if USE_LSS_SLAVE

  LSS_LoadConfiguration(&can_bps,&node_id);
  if (node_id == 0) // unconfigured? start LSS use immediately
  {
    LSS_Init(node_id);
  }

#else

#ifdef __SIMULATION__
  node_id = simconfiguration.nodeid;
#else
  node_id = NODEID_DCF;
#endif
  can_bps = CAN_BITRATE_DCF;

#endif

  if (MCO_Init(can_bps,node_id,DEFAULT_HEARTBEAT)) 
  {

#if USE_LSS_SLAVE == 0
    //Initialization of PDOs comes from EDS
    INITPDOS_CALLS

  #if USE_STORE_PARAMETERS
    MCOSP_GetStoredParameters();
  #endif
#endif

#ifdef __SIMULATION__
    SimDriver_printf("Node 0x%2.2X started using %d kbps\n", node_id, can_bps);
#endif
  }
}


#if USECB_NMTCHANGE
/**************************************************************************
DOES:    Called when the NMT state of the stack changes
RETURNS: nothing
**************************************************************************/
void MCOUSER_NMTChange
  (
  UNSIGNED8 nmtstate    // new nmt state of stack
  )
{
#ifdef __SIMULATION__
SIMCONFIGURATION simconfiguration;

  // Get access to Node ID from simulation driver
  SimDriver_GetConfiguration(&simconfiguration);

  SimDriver_printf("NMT state has changed to ");
  switch (nmtstate)
  {
    case NMTSTATE_BOOT:  SimDriver_printf("bootup\n");         break;
    case NMTSTATE_STOP:  SimDriver_printf("stopped\n");        break;
    case NMTSTATE_OP:    SimDriver_printf("operational\n");    break;
    case NMTSTATE_PREOP: SimDriver_printf("preoperational\n"); break;
    default:             SimDriver_printf("UNKNOWN\n");        break;
  }

  SimDriver_UpdateNMTState(nmtstate);

  if (nmtstate == NMTSTATE_BOOT)
  {
    SimDriver_UpdateNodeID(gMCOConfig.Node_ID);
  }
#endif

#if USE_LSS_SLAVE

  if (nmtstate == NMTSTATE_STOP)
  {
    LSS_Init(MY_NODE_ID);
  }

  if (nmtstate == NMTSTATE_BOOT)
  {
    //Initialization of PDOs comes from EDS
    INITPDOS_CALLS

 #if USE_STORE_PARAMETERS
    MCOSP_GetStoredParameters();
 #endif
  }
#endif

}
#endif


#if USECB_ODSERIAL
/**************************************************************************
DOES:    This function is called upon read requests to Object Dictionary
         entry [1018h,4] - serial number
RETURNS: The 32bit serial number
**************************************************************************/
UNSIGNED32 MCOUSER_GetSerial (
  void
  )
{
#ifdef __SIMULATION__
SIMCONFIGURATION simconfiguration;
#endif

#ifdef __SIMULATION__
  // Get serial number from simulation driver
  SimDriver_GetConfiguration(&simconfiguration);
  return simconfiguration.serialnumber;
#else
  // replace with code to read serial number, for example from 
  // non-volatile memory
  return 0x12345678;
#endif
}
#endif // USECB_ODSERIAL


/**************************************************************************
DOES:    Call-back function, heartbeat lost, timeout occured.
         Gets called when a heartbeat timeout occured for a node.
RETURNS: Nothing
**************************************************************************/
void MCOUSER_HeartbeatLost (
  UNSIGNED8 node_id
  )
{
  // Add code to react on the loss of heartbeat,
  // if node is essential, switch to pre-operational mode
  MCO_HandleNMTRequest(NMTMSG_PREOP);
}


#if USECB_TIMEOFDAY
/**************************************************************************
DOES:    This function is called if the message with the time object has
         been received. This example implementtion calculates the current
         time in hours, minutes, seconds.
RETURNS: nothing
**************************************************************************/
// Global variables holding clock info
UNSIGNED32 hours;
UNSIGNED32 minutes;
UNSIGNED32 seconds;

void MCOUSER_TimeOfDay (
  UNSIGNED32 millis, // Milliseconds since midnight
  UNSIGNED16 days  // Number of days since January 1st, 1984
  )
{
  if (millis < (1000UL * 60 * 60 * 24))
  { // less Milliseconds as one day has
    // calculate hours, minutes & seconds since midnight
    hours = millis / (1000UL * 60 * 60);
    minutes = (millis - (hours * 1000UL * 60 * 60)) / (1000UL * 60);
    seconds = (millis - (hours * 1000UL * 60 * 60) - (minutes * 1000UL * 60)) / 1000;
  }
}
#endif // USECB_TIMEOFDAY


/**************************************************************************
END-OF-FILE 
***************************************************************************/ 
