/**************************************************************************
MODULE:    MAIN
CONTAINS:  DS401 Example application using MicroCANopen Plus
           Written for PCANopen Magic ProDS simulation system
           www.canopenmagic.com
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 01:57:32 -0500 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#ifdef __SIMULATION__
// header files to create dll
#include <windows.h>
#endif
#include "mcop_mgr_inc.h"

// VS debug support (not express versions)
#if defined(__SIMULATION__) && defined(_DEBUG) 
extern unsigned char launchDebugger();
#endif

/**************************************************************************
DOES:    Working on the application
RETURNS: nothing
**************************************************************************/
void USER_ProcessApp(
  void
  )
{
  UNSIGNED8 buf[4];    // buffer to process image
  static UNSIGNED16 pot;  // Analog value / counter
  static UNSIGNED16 last;  // Analog value / counter
  UNSIGNED16 now;

#ifdef P620001_DIGOUTPUT8_1
  // Update process data
  // Echo Digital Output
  MCO_ReadProcessData(buf,1,P620001_DIGOUTPUT8_1);
  MCO_WriteProcessData(P600001_DIGINPUT8_1,1,buf);
#endif

  // Every 10000 cycles, timer to process data
  pot++;
  if (pot > 10000)
  {
    now = MCOHW_GetTime();
    buf[0] = now & 0x00FF; // lo byte
    buf[1] = (now >> 8) & 0x00FF; // hi byte
    buf[2] = (now-last) & 0x00FF;
    buf[3] = ((now-last) >> 8) & 0x00FF;
    last = now;
    // Write analog data to process image
#ifdef P640101_ANALOGINPUT16_1
    MCO_WriteProcessData(P640101_ANALOGINPUT16_1,4,buf);
#endif
    pot = 0;
  }
}

/**************************************************************************
DOES:    The main function
RETURNS: nothing
**************************************************************************/
int main(
  void
  )
{
  UNSIGNED16 op_delay; // delay before swithcing into operational

#if defined(__SIMULATION__) && defined(_DEBUG) 
  if (launchDebugger())
  {
    // Stop execution so the debugger can take over
    DebugBreak();
  }
#endif

  // Reset/Initialize CANopen communication
  MCOUSER_ResetCommunication();

  op_delay = MCOHW_GetTime() + 500;

  // foreground loop
  while(1)
  {
    // Operate on CANopen protocol stack, slave
    MCO_ProcessStack();
    // Operate on application
    USER_ProcessApp();

    if (MY_NMT_STATE == NMTSTATE_OP)
    { // Only work on manager when we are operational
      // Operate on CANopen protocol stack, manager
      MGR_ProcessMgr();
      // Operate on custom CANopen manager application
      USER_ProcessMgr();
      // reset boot_delay
      op_delay = MCOHW_GetTime() + 500;
    }
    else
    {
      if (MCOHW_IsTimeExpired(op_delay))
      { // after delay, set yourself into operational
        MY_NMT_STATE = NMTSTATE_OP;
        // restart all nodes
        MGR_TransmitNMT(NMTMSG_RESETAPP,0);
      }
    }

#ifdef __SIMULATION__
    // perform main loop operations needed for simulation
    SimDriver_MainLoop();
#endif
  } // end of while(1)
} // end of main
