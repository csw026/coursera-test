// header file for hardware specific items

#ifndef _MCOHWPCSIM_
#define _MCOHWPCSIM_

#include "nodecfg.h"
#include "mco.h"

/**************************************************************************
GLOBAL INTERRUPT DEFINITIONS
**************************************************************************/

// flags for "interrupts"
extern UNSIGNED8 EA;
extern UNSIGNED8 ECAN;
extern UNSIGNED8 ETIM;

#define DIS_INT EA = 0
#define EN_INT  EA = 1

#define DIS_CAN ECAN = 0
#define EN_CAN  ECAN = 1

#define DIS_TIM ETIM = 0
#define EN_TIM  ETIM = 1

// Locks for process image
#define LOCK_PI_WRITE    DIS_TIM
#define UNLOCK_PI_WRITE  EN_TIM
#define LOCK_PI_READ     DIS_CAN
#define UNLOCK_PI_READ   EN_CAN


/**************************************************************************
DOES:    Receives a message from the CAN bus - just like a receive
         interrupt. Stores the message in a buffer to mimic a CAN
         controller                                         
RETURNS: nothing                                     
**************************************************************************/
extern void MCOHW_ReceiveMessage
  (
  CAN_MSG *pMsg   // pointer to message to store
  );

/**************************************************************************
DOES:    Timer interrupt service routine                          
         Increments the global millisecond counter tick           
         This function needs to be called once every millisecond  
RETURNS: nothing                                                     
**************************************************************************/
extern void MCOHW_TimerISR
  (
  void
  );

#if MGR_MONITOR_ALL_NODES
/**************************************************************************
DOES:    This function implements an additional CAN receive filter
         used by the manager. Messages received using this ID are pulled
         by the manager using function MCOHWMGR_PullMessage
         Filter set receives messages from 0x81 to 0xFF and 0x581 to 0x5FF
RETURNS: TRUE or FALSE, if filter was not set
**************************************************************************/
extern UNSIGNED8 MCOHWMGR_SetCANFilter(
  void
);
#endif                          // MGR_MONITOR_ALL_NODES

#endif  // _MCOHWPCSIM_
