/**************************************************************************
MODULE:    COMGR
CONTAINS:  MicroCANopen Plus implementation, CANopen Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-08-19 04:07:10 -0500 (Sun, 19 Aug 2018) $
           $LastChangedRevision: 4338 $
***************************************************************************/ 

#include "mcop_mgr_inc.h"


/**************************************************************************
GLOBAL VARIABLES
**************************************************************************/ 
// data status records for each node
MEM_FAR NODELIST gNodeList[MAX_NR_OF_NODES];


/**************************************************************************
INTERNAL MODUL VARIABLES
**************************************************************************/ 
// module loops through node list for HB check
static MEM_FAR UNSIGNED8 mHBnode;
// module loops through node list for scanning
static MEM_FAR UNSIGNED8 mIDnode;


/**************************************************************************
INTERNAL FUNCTIONS USED FROM MODULE SDOCLNT
**************************************************************************/ 
void MGR_HandleSDOClientResponse (SDOCLIENT MEM_FAR *p_client, UNSIGNED8 MEM_FAR *pDat );
UNSIGNED8 MGR_SDOHandleClient (void);


/*******************************************************************************
PUBLIC FUNCTIONS
*******************************************************************************/

/**************************************************************************
Description in comgr.h
***************************************************************************/ 
void MGR_ResetNodeList (
  void
  )
{
  for (mHBnode = 0; mHBnode < MAX_NR_OF_NODES; mHBnode++)
  {
    gNodeList[mHBnode].last_emcy[0]             = 0xFF;
    gNodeList[mHBnode].last_emcy[1]             = 0xFF;
    gNodeList[mHBnode].hb_nmtstate              = 0xFF;
    gNodeList[mHBnode].hb_consstat              = HBCONS_OFF;
    gNodeList[mHBnode].id_scanstat              = SCAN_NONE;
  }

#if (INDEX_FOR_DIAGNOSTICS != 0)
  gMCODiag.MgrTickCnt = 0;
  gMCODiag.MgrRxCnt = 0;
  gMCODiag.MgrNextSecond = MCOHW_GetTime() + 1000;
  gMCODiag.MgrBurstCnt = 0;
#endif

}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
void MGRSCAN_Init (
  UNSIGNED8 sdo_clnt,   // SDO client number from 1 to NR_OF_SDO_CLIENTS
  UNSIGNED8 node_id,    // Node ID of node to read data from
  MEM_FAR UNSIGNED8 *pScanList, // Pointer to list with OD entries to be read
  MEM_FAR UNSIGNED8 *pScanData, // Pointer to array, must be as long as number
                        // of entries times four (to read/write up to four bytes)
                        // in list above
  UNSIGNED16 Delay
  )
{
  node_id--;

  if ((node_id < MAX_NR_OF_NODES) && 
      ((gNodeList[node_id].id_scanstat == SCAN_NONE) || (gNodeList[node_id].id_scanstat >= SCAN_ABORT))
     )
  { // channel is unused
    gNodeList[node_id].scanclnt = sdo_clnt;
    gNodeList[node_id].id_scanstat = SCAN_DELAY;
    gNodeList[node_id].p_scanlist = pScanList;
    gNodeList[node_id].p_scandata = pScanData;
    gNodeList[node_id].scandelay = Delay;
    gNodeList[node_id].delaytimer = MCOHW_GetTime() + Delay;
    
    // Inform host of start of a new scan
    // Permanently removed from here as this causes recursions
    // MGRCB_NodeStatusChanged(node_id+1,NODESTATUS_SCANSTARTED, FALSE);
  }

}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 MGRSCAN_GetStatus (
  UNSIGNED8 node_id     // Node ID of node where auto scan is running
  )
{
UNSIGNED8 ret_val = TRUE;

  node_id--;

  if (node_id < MAX_NR_OF_NODES)
  {
    if ((gNodeList[node_id].id_scanstat == SCAN_NONE) || (gNodeList[node_id].id_scanstat == SCAN_OVER))
    {
      ret_val = FALSE;
    }
  }

  return ret_val;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 MGR_TransmitNMT ( 
  UNSIGNED8 nmt_cmd, // NMT command
  UNSIGNED8 node_id  // Node ID, or zero for all nodes
  )
{
CAN_MSG TxNMT;
UNSIGNED8 retval = FALSE;

  // check ranges
  if ( (node_id > 127) ||
       ( (nmt_cmd != NMTMSG_OP) &&
         (nmt_cmd != NMTMSG_STOP) &&
         (nmt_cmd != NMTMSG_PREOP) &&
         (nmt_cmd != NMTMSG_RESETCOM) &&
         (nmt_cmd != NMTMSG_RESETAPP)
       )
     )
  {
    MCOUSER_FatalError(0x0701);
  }
  else
  {
    TxNMT.ID = 0;
    TxNMT.LEN = 2;
    TxNMT.BUF[0] = nmt_cmd;
    TxNMT.BUF[1] = node_id;
    if ((node_id == 0) || (node_id == gMCOConfig.Node_ID))
    { // Also change NMT state of local node
      if ((nmt_cmd != NMTMSG_RESETCOM) && (nmt_cmd != NMTMSG_RESETAPP))
      { // do not reset yourself but handle other switches
        MCO_HandleNMTRequest(nmt_cmd);
      }
    }
    // handle HB consumer
    if ((nmt_cmd == NMTMSG_RESETCOM) || (nmt_cmd == NMTMSG_RESETAPP))
    { // reset command
      if (node_id == 0)
      { // disable HB consumer for all nodes
        while (node_id < MAX_NR_OF_NODES)
        {
          gNodeList[node_id].hb_consstat = HBCONS_OFF;
          node_id++;
        }
      }
      else if (node_id <= MAX_NR_OF_NODES) 
      { // disable HB consumer for this node
        gNodeList[node_id-1].hb_consstat = HBCONS_OFF;
      }
    }
    retval = MCOHW_PushMessage(&TxNMT);
  }
  return retval;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
void MGR_InitHBConsumer (
  UNSIGNED8 node_id, // Node ID to monitor
  UNSIGNED16 hb_time // Timeout to use (in ms)
  )
{
#if CHECK_PARAMETERS
  // check ranges
  if (((node_id < 1) || (node_id > MAX_NR_OF_NODES)))
  {
    MCOUSER_FatalError(0x9901);
  }
#endif

  node_id--; // adapt to range 0 to 126

  gNodeList[node_id].hb_time = hb_time;
  gNodeList[node_id].hb_consstat = HBCONS_INIT;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 MGR_ConsumeHB (
   CAN_MSG MEM_FAR *pRxCAN // CAN message received
  )
{
UNSIGNED16 sub;
UNSIGNED16 lp;

  // Calculate subindex for node list
  sub = (pRxCAN->ID - 0x700);
  if ((sub > MAX_NR_OF_NODES) || (sub == MY_NODE_ID))
  { // not a heartbeat message
    return FALSE;
  }
  sub--;

  // If bootup, then inform application
  if (pRxCAN->BUF[0] == 0)
  {
    MGRCB_NodeStatusChanged(sub+1, NODESTATUS_BOOT, FALSE);
  }
  else if (gNodeList[sub].hb_nmtstate != pRxCAN->BUF[0])
  { // state changed from last
    MGRCB_NodeStatusChanged(sub+1, pRxCAN->BUF[0], FALSE);
  }

  if (gNodeList[sub].hb_consstat == HBCONS_LOST)
  { // node was previously lost
    // Now check if there are still other lost nodes
    for(lp=0;lp<MAX_NR_OF_NODES;lp++)
    {
      if ((gNodeList[lp].hb_consstat == HBCONS_LOST) && (lp != sub))
      { // another node is still lost
        break;
      }
    }
    if (lp >= MAX_NR_OF_NODES)
    { // no more lost nodes
#if USE_EMCY
      MCOP_PushEMCY(0,sub+1,0,0,0,0);
#endif // USE_EMCY
#if USE_LEDS
      gMCOConfig.LEDErr = LED_OFF;
#endif
    }
  }

  // Process heartbeat
  if ((gNodeList[sub].hb_consstat != HBCONS_OFF) && (pRxCAN->BUF[0] != 0))
  { // consumer is not disabled AND this is not the bootup message
    if (gNodeList[sub].hb_consstat != HBCONS_ACTIVE)
    { // no HB consumption is newly activated
      MGRCB_NodeStatusChanged(sub+1, NODESTATUS_HBACTIVE, FALSE);
    }
    gNodeList[sub].hb_consstat = HBCONS_ACTIVE; // hb consumption active
  }

#if USE_EVENT_TIME
#if NR_OF_TPDOS > 0
  if ((gNodeList[sub].hb_nmtstate != NMTSTATE_OP) && (pRxCAN->BUF[0] == NMTSTATE_OP))
  { // Just switched to running, re-trigger all TPDOs that are COS
    lp = 0;
    while (lp < gMCOConfig.nrTPDOs)
    {
      // Mark for ASAP transmission 
      if (gTPDOConfig[lp].inhibit_status == INHITIM_EXPIRED)
      { // inhibit timer is currently NOT running
        gTPDOConfig[lp].inhibit_timestamp = MCOHW_GetTime() - 1;
      }
      gTPDOConfig[lp].inhibit_status = INHITIM_RUNNING_TRIGGERED;
      // now it is marked for transmission, and timer is corrected
      lp++;
    }
  }
#endif
#endif // USE_EVENT_TIME

  // Save message contents
  gNodeList[sub].hb_nmtstate = pRxCAN->BUF[0];
  // Calculate new time stamp
  gNodeList[sub].hb_timestamp = MCOHW_GetTime() + gNodeList[sub].hb_time;

  return TRUE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
HBCONS_STATE MGR_ProcessHBCheck (
  UNSIGNED8 node_id
  )
{
#if CHECK_PARAMETERS
  // check ranges
  if ((node_id == 0) || (node_id > MAX_NR_OF_NODES))
  {
    MCOUSER_FatalError(0x9903);
  }
#endif

  node_id--; // adapt to range 0 to 126

  if (gNodeList[node_id].hb_consstat == HBCONS_ACTIVE)
  { // Heartbeat consumer is active
    if (MCOHW_IsTimeExpired(gNodeList[node_id].hb_timestamp))
    { // active and expired
      gNodeList[node_id].hb_consstat = HBCONS_LOST;
#if USE_EMCY
      MCOP_PushEMCY(0x8130,node_id+1,0,0,0,0);
#endif // USE_EMCY
#if USE_LEDS
      gMCOConfig.LEDErr = LED_FLASH2;
#endif
    }
  }

  return gNodeList[node_id].hb_consstat;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
 NODELIST *MGR_GetNodeInfoPtr (
  UNSIGNED8 node_id
  )
{
  if (node_id > MAX_NR_OF_NODES)
  {
    return 0;
  }
  node_id--;
  return (NODELIST *) &(gNodeList[node_id]);
}


/**************************************************************************
DOES:    Works on Manager functionality. 
         HERE: Subprocess working on a message received
***************************************************************************/ 
UNSIGNED8 MGR_ProcessMgrRx (
  void
  )
{
  MEM_FAR CAN_MSG MgrMsg;
  UNSIGNED8 channel;

  // Check if a CAN message was received for the Manager
  if (MCOHWMGR_PullMessage(&MgrMsg))
  { // A message arrived for the manager
#if (INDEX_FOR_DIAGNOSTICS != 0)
    gMCODiag.MgrRxCnt++;
#endif

#ifdef __SIMULATION__
    //SimDriver_printf("Pulled %3.3X\n", MgrMsg.ID);
#endif
    if ( (MgrMsg.ID == 0x700 + MY_NODE_ID) ||
       (MgrMsg.ID == 0x80 + MY_NODE_ID)
     )
    { // Ignore possibly self-received heartbeats, emergencies: continue
      return TRUE;
    }

    if ((MgrMsg.ID >= 0x081) && (MgrMsg.ID <= (0x080+MAX_NR_OF_NODES)))
    { // This is an emergency message, call back application
      // Copy EMCY msg to node list
      MEM_CPY_FAR(&(gNodeList[MgrMsg.ID-0x081].last_emcy[0]),&(MgrMsg.BUF[0]),8);
      // call-back to application
      if (MgrMsg.BUF[1] == 0)
      {
        MGRCB_NodeStatusChanged(MgrMsg.ID-0x80, NODESTATUS_EMCY_OVER, FALSE);
      }
      else
      {
        MGRCB_NodeStatusChanged(MgrMsg.ID-0x80, NODESTATUS_EMCY_NEW, FALSE);
      }
      return TRUE;
    }

    if ((MgrMsg.ID >= 0x701) && (MgrMsg.ID <= (0x700 + MAX_NR_OF_NODES)))
    { // This is a bootup / heartbeat message
      MGR_ConsumeHB(&MgrMsg);
      return TRUE;
    }

#if (NR_OF_SDO_CLIENTS > 0)
    if (IS_CAN_ID_SDORESPONSE(MgrMsg.ID)) 
    { // This is an SDO response
      // Find the matching channel
      for (channel = 0; channel < NR_OF_SDO_CLIENTS; channel++)
      {
        if (MgrMsg.ID == (gSDOClientList[channel].canid_response & 0x000007FF))
        {
          MGR_HandleSDOClientResponse(&(gSDOClientList[channel]),&(MgrMsg.BUF[0]));
          break;
        }
      }
      return TRUE;
    }
#endif // (NR_OF_SDO_CLIENTS > 0)

#if ((USE_LSS_MANAGER == 1) || (USE_MLSS_MANAGER == 1))
    if (MgrMsg.ID == LSS_SLAVE_ID)
    { // This is a LSS Identify response
      MGRCB_LSSIdentified(MgrMsg.BUF);
      return TRUE;
    }
#endif // USE_MLSS_MANAGER

  }

  return FALSE;
}


/**************************************************************************
DOES:    Works on Manager functionality. 
         HERE: Subprocess checking on timeouts or status changes
***************************************************************************/ 
UNSIGNED8 MGR_ProcessMgrTick (
  void
  )
{
UNSIGNED8 channel;
MEM_FAR SDOCLIENT *pSCL_ID;
UNSIGNED8 ret_val = NOT_SET;

  // Only proceed if we are initalized and not stopped
  if ( (MY_NODE_ID == 0) || (MY_NODE_ID > 127) || 
       (MY_NMT_STATE == NMTSTATE_STOP) || (MY_NMT_STATE == NMTSTATE_BOOT)
     )
  { // Master has not yet a node ID or is not operational
    ret_val = FALSE;
  }

#if (NR_OF_SDO_CLIENTS > 0)
  // Check if an SDO client had a timeout
  if ((ret_val == NOT_SET) && (MGR_SDOHandleClient()))
  {
    ret_val = TRUE;
  }
#endif // (NR_OF_SDO_CLIENTS > 0)

  if (ret_val == NOT_SET)
  {
    // Heartbeat Consumer Handling
    for (channel = 0; channel < NR_OF_HBCHECKS_PERCYCLE; channel++)
    {
      mHBnode++;
      if (mHBnode > MAX_NR_OF_NODES)
      {
        mHBnode = 1;
      }
      if (MGR_ProcessHBCheck(mHBnode) == HBCONS_LOST)
      { // Heartbeat lost!
        MGRCB_NodeStatusChanged(mHBnode, NODESTATUS_HBLOST, FALSE);
        // Reset HB Consumer to re-start
        gNodeList[mHBnode-1].hb_consstat = HBCONS_INIT;
        ret_val = TRUE;
      }
    }
  }

  if (ret_val == NOT_SET)
  {
    // walk through all nodes to check scan check, only one per call
    mIDnode++;
    if (mIDnode > (MAX_NR_OF_NODES-1))
    {
      mIDnode = 0;
    }
  
    // check if there is some scanning to handle
    if (gNodeList[mIDnode].id_scanstat == SCAN_DELAY)
    {
      if (MCOHW_IsTimeExpired(gNodeList[mIDnode].delaytimer))
      {
        gNodeList[mIDnode].id_scanstat = SCAN_RUN;
      }
    }
  
    // process next scan
    else if (gNodeList[mIDnode].id_scanstat == SCAN_RUN)
    { // current node has some scanning to do
      // verify that channel is not in use
      if ((gSDOClientList[gNodeList[mIDnode].scanclnt-1].status & SDOCL_WAIT_RES) == 0)
      { // channel free
        if ( (gNodeList[mIDnode].p_scanlist[0] == 0xFF) && (gNodeList[mIDnode].p_scanlist[1] == 0xFF) )
        { // no list or end of list
          gNodeList[mIDnode].id_scanstat = SCAN_DONE;
        }
        else
        { // this is not the end, scan next
          if (!(TXFIFO_HALFFULL))
          { // only do this, if CAN Tx FIFO is half empty
            // use channel dedicated to node ID
            pSCL_ID = SDOCLNT_Init(
                      gNodeList[mIDnode].scanclnt,
                      CAN_ID_SDOREQUEST(MY_NODE_ID, mIDnode+1),
                      CAN_ID_SDORESPONSE(MY_NODE_ID, mIDnode+1),
                      gNodeList[mIDnode].p_scandata,
                      gNodeList[mIDnode].p_scanlist[3] & SL_LENGTH_MASK);
            if (pSCL_ID != 0)
            {
              if ((gNodeList[mIDnode].p_scanlist[3] & SL_WRITE) != 0)
              {
                if (SDOCLNT_Write(pSCL_ID,
                                  ((UNSIGNED16)(gNodeList[mIDnode].p_scanlist[1])<<8)+gNodeList[mIDnode].p_scanlist[0],
                                  gNodeList[mIDnode].p_scanlist[2]
                                )
                   )
                {
                  gNodeList[mIDnode].id_scanstat = SCAN_WAITREPLY;
                }
                else
                { // Message did not go out
                  gNodeList[mIDnode].id_scanstat = SCAN_ABORT;
                }
              }
              else
              {
                if (SDOCLNT_Read(pSCL_ID,
                                  ((UNSIGNED16)(gNodeList[mIDnode].p_scanlist[1])<<8)+gNodeList[mIDnode].p_scanlist[0],
                                  gNodeList[mIDnode].p_scanlist[2]
                                )
                   )
                {
                  gNodeList[mIDnode].id_scanstat = SCAN_WAITREPLY;
                }
                else
                { // Message did not go out
                  gNodeList[mIDnode].id_scanstat = SCAN_ABORT;
                }
              }
            }
            else
            { // Init of SDO client failed
              gNodeList[mIDnode].id_scanstat = SCAN_ABORT;
            }
          }
          ret_val = TRUE;
        }
      }
    }

    // next scan: wait for reply
    else if (gNodeList[mIDnode].id_scanstat == SCAN_WAITREPLY)
    {
      if ((gSDOClientList[gNodeList[mIDnode].scanclnt-1].status & SDOCL_WAIT_RES) == 0)
      { // channel free again, start over, start with delay state
        gNodeList[mIDnode].id_scanstat = SCAN_DELAY;
        gNodeList[mIDnode].delaytimer = MCOHW_GetTime() + gNodeList[mIDnode].scandelay;
        // increment pointers handling the list
        gNodeList[mIDnode].p_scanlist += SL_ENTRY_SIZE;
        gNodeList[mIDnode].p_scandata += SD_ENTRY_SIZE;
        ret_val = TRUE;
      }
    }
  }

  // check if an abort occured
  if ( (ret_val == NOT_SET) && (gNodeList[mIDnode].id_scanstat == SCAN_WAITREPLY) &&
      ((gSDOClientList[gNodeList[mIDnode].scanclnt-1].last_abort > 0) && (gSDOClientList[gNodeList[mIDnode].scanclnt-1].last_abort < 0xFFFFFFFF))
     )
  { // last SDO transfer aborted
    gNodeList[mIDnode].id_scanstat = SCAN_ABORT;
    // Inform application
    MGRCB_NodeStatusChanged(mIDnode+1,NODESTATUS_SCANABORTED, FALSE);
    ret_val = TRUE;
  }
  // scan complete?
  else if ( (ret_val == NOT_SET) && (gNodeList[mIDnode].id_scanstat == SCAN_DONE) &&
       ((gSDOClientList[gNodeList[mIDnode].scanclnt-1].status & SDOCL_WAIT_RES) == 0)
     )
  {
    gNodeList[mIDnode].id_scanstat = SCAN_OVER;
    // Inform application
    MGRCB_NodeStatusChanged(mIDnode+1,NODESTATUS_SCANCOMPLETE, FALSE);
    ret_val = TRUE;
  }

  if (ret_val == NOT_SET)
  {
    ret_val = FALSE;
  }

#if (INDEX_FOR_DIAGNOSTICS != 0)
  // diagnostics: how often does this get executed per second
  gMCODiag.MgrTickCnt++;
  if(MCOHW_IsTimeExpired(gMCODiag.MgrNextSecond))
  { // once per second
    // current value
    gMCODiag.ProcMgrTickPerSecCur = gMCODiag.MgrTickCnt;
    // check min, max of ProcessTick
    if (gMCODiag.ProcMgrTickPerSecCur < gMCODiag.ProcMgrTickPerSecMin)
    {
      gMCODiag.ProcMgrTickPerSecMin = gMCODiag.ProcMgrTickPerSecCur;
    }
    if (gMCODiag.ProcMgrTickPerSecCur > gMCODiag.ProcMgrTickPerSecMax)
    {
      gMCODiag.ProcMgrTickPerSecMax = gMCODiag.ProcMgrTickPerSecCur;
    }

    gMCODiag.ProcMgrRxPerSecCur = gMCODiag.MgrRxCnt;
    // check min, max of ProcessRx
    if (gMCODiag.ProcMgrRxPerSecCur < gMCODiag.ProcMgrRxPerSecMin)
    {
      gMCODiag.ProcMgrRxPerSecMin = gMCODiag.ProcMgrRxPerSecCur;
    }
    if (gMCODiag.ProcMgrRxPerSecCur > gMCODiag.ProcMgrRxPerSecMax)
    {
      gMCODiag.ProcMgrRxPerSecMax = gMCODiag.ProcMgrRxPerSecCur;
    }

    // Reset all counter
    gMCODiag.MgrTickCnt = 0;
    gMCODiag.MgrRxCnt = 0;
    gMCODiag.MgrNextSecond = MCOHW_GetTime() + 1000;
  }

  // diagnostics: what is the longest burst of back to back calls executing something
  if (ret_val == TRUE)
  {
    gMCODiag.MgrBurstCnt++;
  }
  else
  {
    if (gMCODiag.MgrBurstCnt > gMCODiag.ProcMgrTickBurstMax)
    {
      gMCODiag.ProcMgrTickBurstMax = gMCODiag.MgrBurstCnt;
    }
    gMCODiag.MgrBurstCnt = 0;
  }
#endif

  return ret_val;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 MGR_ProcessMgr (
  void
  )
{
UNSIGNED8 ret_val;

  ret_val = MGR_ProcessMgrRx();

  if (ret_val == 0)
  { // No message was received for the manager
    ret_val = MGR_ProcessMgrTick();
  }

  return ret_val;
}


/*******************************************************************************
END OF FILE
*******************************************************************************/
