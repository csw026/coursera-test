/**************************************************************************
MODULE:    ConciseDCF
CONTAINS:  MicroCANopen Plus, concise DCF handling
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#ifndef _CONCISEDCF_H
#define _CONCISEDCF_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mco.h"
#include "mcohw.h"
#include "comgr.h"

#if USE_CONCISEDCF

#define CDCF_INPROGRESS   0x01
#define CDCF_WAITRESPONSE 0x02
#define CDCF_COMPLETE     0x10
#define CDCF_ERROR        0x80


/**************************************************************************
CONCISE DCF FORMAT as specified by CANopen

UNSIGNED32 Number of entries in File

For each entry:

UNSIGNED16  Index
UNSIGNED8   Subindex
UNSIGNED32  Size of data in Bytes
DOMAIN      data

**************************************************************************/



/**************************************************************************
DOES:    Initiates all the SDO write accesses specified in a concise DCF 
         file, first 4 bytes is number of entires. In application, call
         CDCF_ProcessCDCF until transfer completed.
RETURNS: Pointer to status variable. If bit CDCF_COMPLETE is set in this 
         status variable, then the transfer completed. If bit CDCF_ERROR
         is set the transfer was aborted
**************************************************************************/
MEM_FAR UNSIGNED8 *CDCF_Write (
  UNSIGNED8 SDOchannel,
  UNSIGNED8 NodeID,
  MEM_FAR UNSIGNED8 *pCDCF,
  UNSIGNED16 Timeout
  );


/**************************************************************************
DOES:    Processes the next step of the DCF write sequence
RETURNS: nothing
**************************************************************************/
void CDCF_Process (
  void
  );

#endif // USE_CONCISEDCF

#ifdef __cplusplus
}
#endif

#endif // _CONCISEDCF_H
/**************************************************************************
END OF FILE
**************************************************************************/
