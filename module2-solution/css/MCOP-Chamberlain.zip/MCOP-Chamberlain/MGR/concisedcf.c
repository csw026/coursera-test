/**************************************************************************
MODULE:    ConciseDNF
CONTAINS:  MicroCANopen Plus, concise DCF handling
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#include "mco.h"
#include "mcohw.h"
#include "comgr.h"
#include "concisedcf.h"
#include "sdoclnt.h"

#if USE_CONCISEDCF

/**************************************************************************
GLOBAL VARIABLES
**************************************************************************/


/**************************************************************************
INTERNAL MODUL VARIABLES
**************************************************************************/
// module variable with status of transfer
struct {
  MEM_FAR SDOCLIENT *pSDO; // SDO channel used
  MEM_FAR UNSIGNED8 *pNow; // running pointer in concise DCF data
  UNSIGNED32 todo;         // number of entries in CDCF still to process
  UNSIGNED16 timeout;      // SDO client timeout
  UNSIGNED8 chn;           // SDO channel number
  UNSIGNED8 NID;           // Node ID number
  UNSIGNED8 state;         // current state
} MEM_FAR mCDCF = {0,0,0,0,0,0,0};


/**************************************************************************
LOCAL FUNCTIONS
**************************************************************************/

/**************************************************************************
DOES:    Retrieves a 32bit value from non-aligned memory location
RETURNS: The 32 bit value
**************************************************************************/
static UNSIGNED32 CDCF_Get32 (
  MEM_FAR UNSIGNED8 *pVal
  )
{
UNSIGNED32 value;

  // start from back, most significant byte first
  pVal += 3;
  // byte 3
  value = *pVal;
  pVal--;
  value <<= 8;
  // byte 2
  value += *pVal;
  pVal--;
  value <<= 8;
  // byte 1
  value += *pVal;
  pVal--;
  value <<= 8;
  // byte 0
  value += *pVal;
  return value;
}


/**************************************************************************
GLOBAL FUNCTIONS
**************************************************************************/

/**************************************************************************
DOES:    Initiates all the SDO write accesses specified in a concise DCF 
         file, first 4 bytes is number of entires. In application, call
         CDCF_ProcessCDCF until transfer completed.
RETURNS: Pointer to status variable. If bit CDCF_COMPLETE is set in this 
         status variable, then the transfer completed. If bit CDCF_ERROR
         is set the transfer was aborted
**************************************************************************/
MEM_FAR UNSIGNED8 *CDCF_Write (
  UNSIGNED8 SDOchannel,
  UNSIGNED8 NodeID,
  MEM_FAR UNSIGNED8 *pCDCF,
  UNSIGNED16 Timeout
  )
{
  mCDCF.pNow = pCDCF;
  mCDCF.pNow += 4; // point to first record
  mCDCF.todo = CDCF_Get32(pCDCF);
  mCDCF.chn = SDOchannel;
  mCDCF.NID = NodeID;
  mCDCF.timeout = Timeout;
  mCDCF.pSDO = SDOCLNT_Init(mCDCF.chn,mCDCF.NID+0x600,mCDCF.NID+0x580,mCDCF.pNow,4);
  if (mCDCF.pSDO != 0)
  {
    mCDCF.state = CDCF_INPROGRESS;
  }
  else
  {
    mCDCF.state = CDCF_COMPLETE;
  }
  return &(mCDCF.state);
}


/**************************************************************************
DOES:    Processes the DCF write sequence
RETURNS: nothing
**************************************************************************/
void CDCF_Process (
  void
  )
{
UNSIGNED16 idx;
UNSIGNED8 sub;
UNSIGNED32 len;
MEM_FAR UNSIGNED8 *pDat;

  if ((mCDCF.state & CDCF_INPROGRESS) != CDCF_INPROGRESS)
  { // nothing to do
    return;
  }

  if ((mCDCF.state & CDCF_WAITRESPONSE) != CDCF_WAITRESPONSE)
  { // need to initiate next transfer

    if (mCDCF.todo == 0)
    { // end of concise DCF reached
      mCDCF.state = CDCF_COMPLETE;
      return;
    }

    // now get data for next transfer
    // Index
    idx = *mCDCF.pNow;
    mCDCF.pNow++;
    idx += ((UNSIGNED16) *mCDCF.pNow) << 8;
    mCDCF.pNow++;
    // Subindex
    sub = *mCDCF.pNow;
    mCDCF.pNow++;
    // length
    len = CDCF_Get32(mCDCF.pNow);
    mCDCF.pNow += 4;
    // data
    pDat = mCDCF.pNow;

    // Initiate next SDO transfer
    if (!(SDOCLNT_WriteXtd(mCDCF.pSDO,idx,sub,pDat,len,mCDCF.timeout)))
    { // error
      mCDCF.state = CDCF_COMPLETE | CDCF_ERROR;
      return;
    }

    mCDCF.state |= CDCF_WAITRESPONSE;

    // now adjust pointer for next entry
    mCDCF.pNow += len;
    mCDCF.todo--;

  }
  else
  { // Waiting for last transfer to complete

    if(mCDCF.pSDO->status == SDOCL_READY)
    { // channel is free again
      mCDCF.state &= ~CDCF_WAITRESPONSE;
      return;
    }
  }

}

/*----------------------- END OF FILE ----------------------------------*/
#endif // USE_CONCISEDCF
