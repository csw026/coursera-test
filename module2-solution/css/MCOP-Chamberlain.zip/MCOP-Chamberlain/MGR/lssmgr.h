/**************************************************************************
MODULE:    LSSMGR
CONTAINS:  MicroCANopen Plus implementation, LSS Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#ifndef _LSSMGR_H
#define _LSSMGR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mco.h"


#if USE_LSS_MANAGER

#define LSSM_OP  0
#define LSSM_CFG 1


/**************************************************************************
DOES:    Initializes the LSS Master/Manager, init of CAN interface
         and CAN receive filter for LSS response
RETURNS: TRUE, if initalization sucess
***************************************************************************/ 
UNSIGNED8 LSSM_Init (
  UNSIGNED16 bps // CAN bit rate
  );


/**************************************************************************
DOES:    Implements the LSS Switch Global command 
RETURNS: TRUE, if switch message transmitted OK
***************************************************************************/ 
UNSIGNED8 LSSM_SwitchGlobal (
  UNSIGNED8 mode, // LSSM_OP for operation mode, LSSM_CFG for configuration mode
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Switch Selective command 
RETURNS: TRUE, if switch message transmitted OK
***************************************************************************/ 
UNSIGNED8 LSSM_SwitchSelective (
  UNSIGNED32 lssid[4], // 128bit LSS ID
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Configure Node ID command 
RETURNS: TRUE, if slave node confirmed the command
***************************************************************************/ 
UNSIGNED8 LSSM_ConfigureNodeID (
  UNSIGNED8 nodeid, // 1-127
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Configure Bit Timing command 
RETURNS: TRUE, if slave node confirmed the command
***************************************************************************/ 
UNSIGNED8 LSSM_ConfigureBitTiming (
  UNSIGNED8 bittime, 
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Activate Bit Timing command 
RETURNS: TRUE, if slave node confirmed the command
***************************************************************************/ 
UNSIGNED8 LSSM_ActivateBitTiming (
  UNSIGNED16 delay,
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Store Configuration command 
RETURNS: TRUE, if slave node confirmed the command
***************************************************************************/ 
UNSIGNED8 LSSM_StoreConfiguration (
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Inquire ID command 
RETURNS: TRUE, if slave node confirmed the command
***************************************************************************/ 
UNSIGNED8 LSSM_InquireID (
  UNSIGNED32 *plssid,
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Identify Non Config command 
RETURNS: TRUE, if slave node confirmed the command
***************************************************************************/ 
UNSIGNED8 LSSM_IdentifyNonConfig (
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Implements the LSS Identity check command, used to check if a node
         with matching ranges is available on the network
RETURNS: TRUE, if at least one slave node confirmed an identity match
***************************************************************************/ 
UNSIGNED8 LSSM_Identify (
  UNSIGNED32 vendor, // Vendor ID
  UNSIGNED32 product,// Product ID
  UNSIGNED32 rev_lo, // low value for revision
  UNSIGNED32 rev_hi, // high value for revision
  UNSIGNED32 ser_lo, // low value for serial
  UNSIGNED32 ser_hi, // high value for serial
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Scans the network for unconfigured nodes. Scans revision and
         serial ranges between a low and a hi value. When calling, set
		   lss_id_lo[0] to vendor ID
		   lss_id_lo[1] to product ID
		   lss_id_lo[2] to low value for revision
		   lss_id_lo[3] to low value for serial
RETURNS: TRUE, if a node in the specified range was found.
         The node's 128bit ID is returned in lss_id_lo
***************************************************************************/ 
UNSIGNED8 LSSM_SearchDevice (
  UNSIGNED32 lss_id_lo[4], // lss_id with lo values for revision and serial
  UNSIGNED32 rev_hi, // high value for revision
  UNSIGNED32 ser_hi, // high value for serial
  UNSIGNED16 timeout // timeout in milliseconds
  );


/**************************************************************************
DOES:    Call-back to application, response to a IdentifyNonConfig received
RETURNS: nothing
***************************************************************************/ 
void MGRCB_LSSIdentified (
  MEM_FAR UNSIGNED8 *pDat // Pointer to 8 data bytes received
  );

#endif // USE_LSS_MANAGER


#ifdef __cplusplus
}
#endif

#endif // _LSSMGR_H
/**************************************************************************
END OF FILE
**************************************************************************/
