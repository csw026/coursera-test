/**************************************************************************
MODULE:    COMGR
CONTAINS:  MicroCANopen Plus implementation, CANopen Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-27 08:40:18 -0500 (Fri, 27 Oct 2017) $
           $LastChangedRevision: 4055 $
***************************************************************************/ 

#ifndef _MGR_H
#define _MGR_H

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************
AUTOMATIC INCLUDES
**************************************************************************/

#include "mco.h"

/**************************************************************************
SELECT DEFAULTS FOR DEFINES, IF NOT YET SET
**************************************************************************/ 
#ifndef MGR_MONITOR_ALL_NODES
 // Enables main Manager functionailty: monitoring bootup, heartbeats and 
 // emergencies of all nodes
 #define MGR_MONITOR_ALL_NODES 1
#endif
#ifndef USE_LSS_MANAGER
 // Enables LSS Manager, when set to 1
 #define USE_LSS_MANAGER 0
#endif
#ifndef USE_MLSS_MANAGER
 // Enables Micro LSS manager functionality, when set to 1
 #define USE_MLSS_MANAGER 0
#endif


/**************************************************************************
Further "#define" controls used in comgr.c

__SIMULATION__
Must be defined, if code is compiled for CANopen Magic Ultimate simulation

CHECK_PARAMETERS
Additional parameter check, if parameters passed are in legal range

NR_OF_TPDOS
Number of TPDOs used

USE_EVENT_TIME
Do TPDOs use event time

USE_EMCY
Does node produce emergency messages

USE_LEDS
Are CANopen LEDs used

NR_OF_SDO_CLIENTS
Number of SDO clients provided
**************************************************************************/


/**************************************************************************
GLOBAL DEFINITIONS
**************************************************************************/

// Defines for NMT States Monitored
/* already defined in mco.h
NMTSTATE_BOOT    0x00 // Boot-up
NMTSTATE_STOP    0x04 // Stopped
NMTSTATE_OP      0x05 // Operational
NMTSTATE_PREOP   0x7F // Pre-operational
*/

// Additional internal states for heartbeat consumption
#define NMTSTATE_WAIT   0xF0 // Heartbeat consumption timeout
#define NMTSTATE_LOST   0xFF // Heartbeat consumption timeout
#define NMTSTATE_KEEPOP 0xE7 // Node dropped out of operational

// Return values for MGRCB_NodeStatusChanged
#define NODESTATUS_BOOT         0x00
#define NODESTATUS_STOPPED      0x04
#define NODESTATUS_OPERATIONAL  0x05
#define NODESTATUS_PREOP        0x7F
#define NODESTATUS_EMCY_NEW     0x80
#define NODESTATUS_EMCY_OVER    0x81
#define NODESTATUS_HBACTIVE     0x90
#define NODESTATUS_HBLOST       0x91
#define NODESTATUS_SCANSTARTED  0x9F
#define NODESTATUS_SCANCOMPLETE 0xA0
#define NODESTATUS_SCANABORTED  0xA8
#define NODESTATUS_RESETAPP     0xB0
#define NODESTATUS_RESETCOM     0xB1
#define NODESTATUS_SLEEP        0xF0
#define NODESTATUS_BOOTLOADER   0xF1

// Definitions for auto-scan read/write list
#define SL_READ        0x10  // if set, the entry in the scanlist is read
#define SL_WRITE       0x20  // if set, the entry in the scanlist is written
#define SL_LENGTH_MASK 0x07  // length is in lowest three bits
#define SL_ENTRY_SIZE 4      // size in bytes of a single scanlist entry
#define SL_ENTRY(index,subindex,flags_length) (UNSIGNED8)((index) & 0x00FF),(UNSIGNED8)((index) >> 8),(UNSIGNED8)(subindex),(UNSIGNED8)(flags_length)
#define SL_END SL_ENTRY(0xFFFF,0xFF,0xFF)
#define SD_ENTRY_SIZE 4      // size in bytes of a single scan data entry


/**************************************************************************
GLOBAL TYPES AND STRUCTURES
**************************************************************************/

// This structure holds all node specific configuration
typedef struct
{
  UNSIGNED8 last_emcy[8];         // Last emergency msg received
  MEM_FAR UNSIGNED8 *p_scanlist;  // Pointer to autoscan list (what to read)
  MEM_FAR UNSIGNED8 *p_scandata;  // Pointer to autoscan data (data read)
  UNSIGNED16 scandelay;           // Delay in ms between read requests
  UNSIGNED16 delaytimer;          // Timer value used to implement
  UNSIGNED16 hb_time;             // Heartbeat Consumer time in ms
  UNSIGNED16 hb_timestamp;        // Expiration time stamp
  UNSIGNED8  hb_nmtstate;         // Last HB NMT State received
  HBCONS_STATE hb_consstat;       // Consumer status: off, init, active, lost
  UNSIGNED8  scanclnt;            // SDO client to use for scan
  UNSIGNED8  id_scanstat;         // set to IDSCAN_DONE when autoscan is completed
} NODELIST;


/**************************************************************************
PUBLIC VARIABLES
**************************************************************************/
#if MAX_NR_OF_NODES > 0
extern MEM_FAR NODELIST gNodeList[MAX_NR_OF_NODES];
#endif


/**************************************************************************
PUBLIC FUNCTIONS
**************************************************************************/


/**************************************************************************
DOES:    This function transmits the NMT Master Message.
         Commands: NMTMSG_OP, NMTMSG_STOP, NMTMSG_PREOP,
                   NMTMSG_RNODE, NMTMSG_RAPP
RETURNS: TRUE, if message was queued
         FALSE, if message could not be queued (transmit queue full)
**************************************************************************/
UNSIGNED8 MGR_TransmitNMT (
  UNSIGNED8  nmt_cmd, // NMT Command to be send
  UNSIGNED8  node_id  // Node addressed with the command or zero for all nodes
  );


/**************************************************************************
DOES:    Initializes Heartbeat Consumer
**************************************************************************/
void MGR_InitHBConsumer (
  UNSIGNED8 node_id, // Node ID to monitor
  UNSIGNED16 hb_time // Timeout ot use (in ms)
  );


/**************************************************************************
DOES:    Checks if a heartbeat consumer timeout occured
RETURNS: HB consumer status, see mco.h
**************************************************************************/
HBCONS_STATE MGR_ProcessHBCheck (
  UNSIGNED8 node_id
  );


/**************************************************************************
DOES:    This function (re-)initializes the node list maintained by the
         Manager
RETURNS: nothing
**************************************************************************/
void MGR_ResetNodeList (
  void
  );


/**************************************************************************
DOES:    Retrieves a pointer to an element in the master's node list
RETURNS: Pointer to a record in the the node list, or zero if an invalid
         node ID was used.
         Values of all bits set indicate that data was not yet retrieved
**************************************************************************/
NODELIST *MGR_GetNodeInfoPtr (
  UNSIGNED8 node_id
  );


/**************************************************************************
DOES:    Call-back function, status change of a node on the network
         NODESTATUS_BOOT          node booted
         NODESTATUS_STOPPED       node changed into operational mode
         NODESTATUS_OPERATIONAL   node changed into operational mode
         NODESTATUS_PREOP         node changed into pre-operational mode
         NODESTATUS_EMCY_OVER     Emergency clear
         NODESTATUS_EMCY_NEW      New emergency occured
         NODESTATUS_HBACTIVE      HB monitoring is now active
         NODESTATUS_HBLOST        HB was lost
         NODESTATUS_SCANSTARTED   An automated scan cycle started
         NODESTATUS_SCANCOMPLETE  Last auto-scan of node completed
         NODESTATUS_SCANABORTED   Last auto-scan of node aborted
RETURNS: Nothing
**************************************************************************/
void MGRCB_NodeStatusChanged (
  UNSIGNED8 node_id,     // Node ID of the node transmitting the emergency
  UNSIGNED8 status,      // NODESTATUS_xxx
  UNSIGNED8 wait         // if TRUE blocks until node status has been fully processed
  );


/**************************************************************************
DOES:    Works on Manager functionality. 
         Checks if a message arrived and processes it as required.
         Checks if timeouts or states changed and require action
RETURNS: TRUE, if this process had something to do, either received a CAN
         message or produced one or issued a call-back.
         FALSE, if this process had nothing to do
***************************************************************************/ 
UNSIGNED8 MGR_ProcessMgr (
  void
  );
// The process are divided into:
UNSIGNED8 MGR_ProcessMgrRx (void);
UNSIGNED8 MGR_ProcessMgrTick (void);


/**************************************************************************
DOES:    This USER function works on the application specific
         manager implementation
RETURNS: nothing
**************************************************************************/
void USER_ProcessMgr (
  void
  );

#ifdef __cplusplus
}
#endif

#endif // _MGR_H
/**************************************************************************
END OF FILE
**************************************************************************/

