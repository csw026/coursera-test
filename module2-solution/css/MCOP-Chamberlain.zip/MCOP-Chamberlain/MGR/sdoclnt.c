/**************************************************************************
MODULE:    COMGR
CONTAINS:  MicroCANopen Plus implementation, CANopen Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-07-06 08:04:34 -0500 (Fri, 06 Jul 2018) $
           $LastChangedRevision: 4319 $
***************************************************************************/ 

#include "mcop_mgr_inc.h"
#if (USE_REMOTE_ACCESS == 1)
#include "mcop_xod_inc.h"
#endif

#if (NR_OF_SDO_CLIENTS > 0)

/**************************************************************************
GLOBAL VARIABLES
**************************************************************************/ 
// data records for each client
MEM_FAR SDOCLIENT gSDOClientList[NR_OF_SDO_CLIENTS];


/**************************************************************************
INTERNAL MODUL VARIABLES
**************************************************************************/ 
// module loops through clients
static MEM_FAR UNSIGNED8 mCurrentChannel;


/**************************************************************************
Manager functionality specific SDO Abort Messages
**************************************************************************/ 
#define SDO_ABORT_TOGGLE           0x05030000UL
#define SDO_ABORT_TIMEOUT          0x05040000UL
#define SDO_ABORT_NOTRANSFER       0x08040020UL
#define SDO_ABORT_NOMEM            0x05040005UL


/*******************************************************************************
PRIVATE FUNCTIONS
*******************************************************************************/

/**************************************************************************
DOES:    Generates an SDO abort message for a specific SDO channel
GLOBALS: Assumes that the sdomsg is already initalized properly from last
         request.
**************************************************************************/
static UNSIGNED8 SDOCLNT_SendSDOAbort (
  MEM_FAR SDOCLIENT *p_client, // Pointer to initialized SDO client structure
  UNSIGNED32 ErrorCode // 4 byte SDO abort error code
  )
{
MEM_FAR UNSIGNED8 *pDest;
UNSIGNED8 i;
UNSIGNED8 retval = FALSE;;

  if (p_client != 0)
  {

    // Prepare SDO abort message
    pDest = &(p_client->sdomsg.BUF[0]);
    *pDest = 0x80; // BUF[0], Command Specifier for Abort
    pDest += 4;
    for (i=0;i<4;i++)
    {
      *pDest = (UNSIGNED8) ErrorCode;
      ErrorCode >>= 8;
      pDest++;
    }

    // Transmit SDO Abort message
    retval = MCOHW_PushMessage(&(p_client->sdomsg));
  }

  return retval;
}


/*******************************************************************************
PUBLIC FUNCTIONS
*******************************************************************************/

/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
void SDOCLNT_ResetChannels (
  void
  )
{
  for (mCurrentChannel = 0; mCurrentChannel < NR_OF_SDO_CLIENTS; mCurrentChannel++)
  {
    gSDOClientList[mCurrentChannel].status = SDOCL_FREE;
    gSDOClientList[mCurrentChannel].channel = mCurrentChannel+1;
    gSDOClientList[mCurrentChannel].last_abort = 0;
  }
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
void SDOCLNT_SDOComplete (
  UNSIGNED8 channel, // SDO channel number in range of 1 to NR_OF_SDO_CLIENTS
  UNSIGNED32 abort_code // SDOERR_xxx codes or SDO abort code
  )
{
  // Execute call-back
  if (gSDOClientList[channel-1].last_abort != 0x510B5D0Cul) // STOP SDO C allback
  {
#if (USE_REMOTE_ACCESS == 1)
    MCORACB_SDOComplete(channel,abort_code);
#endif
    SDOCLNTCB_SDOComplete(channel,abort_code);
  }
  else
  { // erase this one time use marker code
    gSDOClientList[channel-1].last_abort = 0;
  }

  if (abort_code == SDOERR_OK)
  {
    gSDOClientList[channel-1].last_abort = 0;
  }
  else
  {
    gSDOClientList[channel-1].last_abort = abort_code;
  }
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
MEM_FAR SDOCLIENT *SDOCLNT_Init (
  UNSIGNED8 channel, // SDO channel number in range of 1 to NR_OF_SDO_CLIENTS
  UNSIGNED32 canid_request, // CAN message ID used for the SDO request
  UNSIGNED32 canid_response, // CAN message ID used for the SDO response
  MEM_FAR UNSIGNED8 *p_buf, // data buffer pointer for data exchanged
  UNSIGNED32 buf_size // max length of data buffer
  )
{
MEM_FAR SDOCLIENT *pClient = 0;

  channel--;
  if (channel < NR_OF_SDO_CLIENTS)
  { 
    // Init pointer to this client's structure
    pClient = &(gSDOClientList[channel]);

    // Copy configuration into structure
    pClient->canid_request = canid_request;
    pClient->canid_response = canid_response;
    pClient->bufmax = buf_size;
    pClient->buflen = buf_size;
    pClient->curlen = 0;
    pClient->pBuf = p_buf;
    pClient->channel = channel+1;
    pClient->status = SDOCL_READY;
    pClient->last_abort = 0xFFFFFFFF;
    pClient->timeout_reload = SDO_REQUEST_TIMEOUT;

  }

  return pClient;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_Write (
  MEM_FAR SDOCLIENT *p_client, // Pointer to initialized SDO client structure
  UNSIGNED16 index, // Object Dictionary Index to write
  UNSIGNED8 subindex // Object Dictionary Subindex to write
  )
{
MEM_FAR UNSIGNED8 *pDest; // Destination Pointer
MEM_FAR UNSIGNED8 *pSrc; // Source Pointer
UNSIGNED16 loop; // Loop counter
  
  if ( (p_client == 0) ||
       ((p_client->status & SDOCL_READY) != SDOCL_READY)
     )
  {
    return FALSE;
  }

  // Erase last abort
  p_client->last_abort = 0xFFFFFFFF;

#if SDOCLNTCB_APPSDO_WRITE
  {
    UNSIGNED8 large_write;
    UNSIGNED8 result;
    UNSIGNED32 MEM_FAR size;
    UNSIGNED32 MEM_FAR totalsize;
    
    large_write = FALSE;
    size = p_client->buflen;
    totalsize = 0;
    result = SDOCLNTCB_SDOWriteInit (
      p_client,
      index,
      subindex,
      &size,
      &totalsize,
      p_client->pBuf
    );
    if ((result > 0) && (size <= p_client->buflen) && (totalsize > size))
    {
      p_client->buflen = size;
      p_client->bufmax = totalsize;
      large_write = TRUE;
    }
  }
#endif

  // Prepare SDO request message
  p_client->sdomsg.ID = p_client->canid_request;
  p_client->sdomsg.LEN = 8;
  // copy multiplexor
  pDest = &(p_client->sdomsg.BUF[1]);
  *pDest = (UNSIGNED8) index; // BUF[1], Lo-Byte Index
  pDest++;
  *pDest = (UNSIGNED8) (index >> 8); // BUF[2], Hi-Byte Index
  pDest++;
  *pDest = subindex; // BUF[3], Subindex
  // Save index and subindex
  p_client->index = index;
  p_client->subindex = subindex;

  pDest = &(p_client->sdomsg.BUF[0]);
  if (p_client->buflen <= 4)
  { // this can be done with one expedited transfer
    // BUF[0], Command Specifier for Write
    *pDest = 0x23 + ((4-p_client->buflen) << 2); 

    pDest = &(p_client->sdomsg.BUF[4]);
    pSrc = p_client->pBuf;
    for (loop = 0; loop < 4; loop++)
    {
      if (loop < p_client->buflen)
      {
        *pDest = *pSrc; 
      }
      else
      {
        *pDest = 0; // fill unused bytes with zero
      }
      pDest++;
      pSrc++;
    }
    p_client->status = SDOCL_READY;
  }
#if USE_BLOCKED_SDO_CLIENT
  else if ((p_client->buflen > 28))
  { // block transfer only makes sense when at least 4 segments are used
    *pDest = (6 << 5) | 0x02; // BUF[0], Command Specifier for Write Block
    pDest++;
    *pDest = (UNSIGNED8) index; // BUF[1], Lo-Byte Index
    pDest++;
    *pDest = (UNSIGNED8) (index >> 8); // BUF[2], Hi-Byte Index
    pDest++;
    *pDest = subindex; // BUF[3], Subindex
    pDest++;
#if SDOCLNTCB_APPSDO_WRITE
    if (large_write)
    {
      *pDest = p_client->bufmax;
      pDest++;
      *pDest = (p_client->bufmax >> 8);
      pDest++;
      *pDest = (p_client->bufmax >> 16);
      pDest++;
      *pDest = (p_client->bufmax >> 24);
    }
    else
#endif
    {
      *pDest = p_client->buflen;
      pDest++;
      *pDest = (p_client->buflen >> 8);
      pDest++;
      *pDest = (p_client->buflen >> 16);
      pDest++;
      *pDest = (p_client->buflen >> 24);
    }
    
    p_client->curlen = 0;
    p_client->toggle = 0;
    p_client->status = SDOCL_BLOCK_INITWR;

    if (MCOHW_PushMessage(&(p_client->sdomsg)))
    { // Transmission initiated
      // set timeout for SDO request
      p_client->timeout = MCOHW_GetTime() + p_client->timeout_reload;
      p_client->status = p_client->status + SDOCL_WAIT_RES;
      return TRUE;
    }
  }
#endif
  else
  { // more than 4 bytes, segmented transfer
    *pDest = 0x21; // BUF[0], Command Specifier for Write

    pDest = &(p_client->sdomsg.BUF[4]);
#if SDOCLNTCB_APPSDO_WRITE
    if (large_write)
    {
      *pDest = (UNSIGNED8) p_client->bufmax;
      pDest++;
      *pDest = (UNSIGNED8) (p_client->bufmax >> 8);
      pDest++;
      *pDest = (UNSIGNED8) (p_client->bufmax >> 16);
      pDest++;
      *pDest = (UNSIGNED8) (p_client->bufmax >> 24);
    }
    else
#endif
    {
      *pDest = (UNSIGNED8) p_client->buflen;
      pDest++;
      *pDest = (UNSIGNED8) (p_client->buflen >> 8);
      pDest++;
      *pDest = (UNSIGNED8) (p_client->buflen >> 16);
      pDest++;
      *pDest = (UNSIGNED8) (p_client->buflen >> 24);
    }
    p_client->curlen = 0;
    p_client->toggle = 0;
    p_client->status = SDOCL_READY + SDOCL_SEGMENTED;
  }

  if (MCOHW_PushMessage(&(p_client->sdomsg)))
  { // Transmission initiated
    // set timeout for SDO request
    p_client->timeout = MCOHW_GetTime() + p_client->timeout_reload;
    p_client->status = p_client->status + SDOCL_WAIT_RES; 
    return TRUE;
  }

  p_client->status = SDOCL_READY;
  return FALSE;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_Read (
  MEM_FAR SDOCLIENT *p_client, // Pointer to initialized SDO client structure
  UNSIGNED16 index, // Object Dictionary Index to read
  UNSIGNED8 subindex // Object Dictionary Subindex to read
  )
{
MEM_FAR UNSIGNED8 *pDest;

  if ( (p_client == 0) ||
       ((p_client->status & SDOCL_READY) != SDOCL_READY)
     )
  {
    return FALSE;
  }

  // Erase last abort
  p_client->last_abort = 0xFFFFFFFF;
  // Save index and subindex
  p_client->index = index;
  p_client->subindex = subindex;
  // Prepare SDO request message
  p_client->sdomsg.ID = p_client->canid_request;
  p_client->sdomsg.LEN = 8;
  pDest = ( UNSIGNED8 *) &(p_client->sdomsg.BUF[0]);
#if USE_BLOCKED_SDO_CLIENT
  if (p_client->bufmax > 28)
  {
    pDest[0] = (5 << 5); // BUF[0], Command Specifier for Read Block
    pDest[4] = SDO_BLK_MAX_SIZE; // BUF[4], max blocks
    pDest[5] = 1; // BUF[5], allow fall-back
  }
  else
#endif
  {
    pDest[0] = 0x40; // BUF[0], Command Specifier for Read
    pDest[4] = 0;
    pDest[5] = 0;
  }
  pDest[1] = (UNSIGNED8) index; // BUF[1], Lo-Byte Index
  pDest[2] = (UNSIGNED8) (index >> 8); // BUF[2], Hi-Byte Index
  pDest[3] = subindex; // BUF[3], Subindex
  pDest[6] = 0;
  pDest[7] = 0;

  if (MCOHW_PushMessage(&(p_client->sdomsg)))
  { // Transmission initiated
    // set timeout for SDO request
    p_client->timeout = MCOHW_GetTime() + p_client->timeout_reload;
    p_client->toggle = 0;
#if USE_BLOCKED_SDO_CLIENT
    p_client->status = SDOCL_BLOCK_INITRD + SDOCL_WAIT_RES;
#else
    p_client->status = SDOCL_READY + SDOCL_WAIT_RES;
#endif
    p_client->curlen = 0;
    return TRUE;
  }
  p_client->status = SDOCL_READY;
  return FALSE;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_WriteXtd (
  MEM_FAR SDOCLIENT *p_client, // Pointer to initialized SDO client structure
  UNSIGNED16 index, // Object Dictionary Index to write
  UNSIGNED8 subindex, // Object Dictionary Subindex to write
  MEM_FAR UNSIGNED8 *pSrc, // Pointer to data source
  UNSIGNED32 len, // Maximum length of data destination
  UNSIGNED16 timeout // Timeout for this transfer in milliseconds
  )
{
UNSIGNED8 ret_val = 0;

  if ( (p_client != 0) && ((p_client->status & SDOCL_READY) == SDOCL_READY) )
  {
    // change buffer data
    p_client->bufmax = len;
    p_client->buflen = len;
    p_client->curlen = 0;
    p_client->pBuf = pSrc;
    if (timeout == 0)
    { // use default
      p_client->timeout_reload = SDO_REQUEST_TIMEOUT;
    }
    else
    { // adjust timeout for this transfer
      p_client->timeout_reload = timeout;
    }

    ret_val = SDOCLNT_Write(p_client,index,subindex);
 
  }
  
  return ret_val;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_ReadXtd (
  MEM_FAR SDOCLIENT *p_client, // Pointer to initialized SDO client structure
  UNSIGNED16 index, // Object Dictionary Index to read
  UNSIGNED8 subindex, // Object Dictionary Subindex to read
  MEM_FAR UNSIGNED8 *pDest, // Pointer to data destination
  UNSIGNED32 len, // Maximum length of data destination
  UNSIGNED16 timeout // Timeout for this transfer in milliseconds
  )
{
UNSIGNED8 ret_val = 0;

  if ( (p_client != 0) && ((p_client->status & SDOCL_READY) == SDOCL_READY) )
  {
    // change buffer data
    p_client->bufmax = len;
    p_client->buflen = len;
    p_client->curlen = 0;
    p_client->pBuf = pDest;
    if (timeout == 0)
    { // use default
      p_client->timeout_reload = SDO_REQUEST_TIMEOUT;
    }
    else
    { // adjust timeout for this transfer
      p_client->timeout_reload = timeout;
    }

    ret_val = SDOCLNT_Read(p_client,index,subindex);
 
  }
  
  return ret_val;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED32 SDOCLNT_ReadCycle (
  UNSIGNED8 channel, // SDO channel number in range of 1 to NR_OF_SDO_CLIENTS
  UNSIGNED8 node_id, // CANopen node ID
  UNSIGNED16 index, // Object Dictionary Index to read
  UNSIGNED8 subindex, // Object Dictionary Subindex to read
  MEM_FAR UNSIGNED8 *p_buf, // data buffer pointer for data received
  UNSIGNED32 buf_size, // max length of data buffer
  UNSIGNED16 timeout
  )
{
 MEM_FAR SDOCLIENT *pSDOcl;
 UNSIGNED32 ret_val = 0;

  // Init SDO channel
  pSDOcl = SDOCLNT_Init(channel,
      CAN_ID_SDOREQUEST(MY_NODE_ID, node_id),
      CAN_ID_SDORESPONSE(MY_NODE_ID, node_id),
      p_buf, buf_size);

  if ((pSDOcl != 0) && SDOCLNT_Read (pSDOcl,index,subindex))
  { // read request was sent
    // set custom timeout, if defined
    if (timeout != 0)
    {
      pSDOcl->timeout = MCOHW_GetTime() + timeout;
    }
    // Wait until cycle complete
    SDOCLNT_BlockUntilCompleted(pSDOcl);

    if (pSDOcl->last_abort == 0)
    { // Success
      ret_val = pSDOcl->curlen;
    }
  }
  return ret_val;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_WriteCycle (
  UNSIGNED8 channel, // SDO channel number in range of 1 to NR_OF_SDO_CLIENTS
  UNSIGNED8 node_id, // CANopen node ID
  UNSIGNED16 index, // Object Dictionary Index to read
  UNSIGNED8 subindex, // Object Dictionary Subindex to read
  MEM_FAR UNSIGNED8 *p_buf, // data buffer pointer for data transmitted
  UNSIGNED32 buf_size, // length of data transmitted
  UNSIGNED16 timeout
  )
{
 MEM_FAR SDOCLIENT *pSDOcl;
 UNSIGNED8 ret_val = 0;

  // Init SDO channel
  pSDOcl = SDOCLNT_Init(channel,
      CAN_ID_SDOREQUEST(MY_NODE_ID, node_id),
      CAN_ID_SDORESPONSE(MY_NODE_ID, node_id),
      p_buf,buf_size);

  if ((pSDOcl != 0) && SDOCLNT_Write(pSDOcl,index,subindex))
  { // read request was sent
    // set custom timeout, if defined
    if (timeout != 0)
    {
      pSDOcl->timeout = MCOHW_GetTime() + timeout;
    }
    // Wait until cycle complete
    SDOCLNT_BlockUntilCompleted(pSDOcl);

    if (pSDOcl->last_abort == 0)
    { // Success
      ret_val = 1;
    }
  }
  return ret_val;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
void SDOCLNT_AbortTransfer (
  MEM_FAR SDOCLIENT *p_client, // Pointer to initialized SDO client structure
  UNSIGNED32 abort_code // Abort code to transmit
  )
{
  if ((p_client != 0) && (p_client->status != SDOCL_READY) && (p_client->status != SDOCL_FREE))
  { // client pointer not null and cleint currently in use
    p_client->last_abort = abort_code;
    p_client->curlen = 0;
    p_client->status = SDOCL_READY;
    SDOCLNT_SendSDOAbort(p_client,abort_code);
    SDOCLNT_SDOComplete(p_client->channel,abort_code);
  }
}


/**************************************************************************
DOES:    Checks if an SDO client is busy or not
RETURNS: TRUE if busy
**************************************************************************/ 
UNSIGNED8 SDOCLNT_IsBusy (
  MEM_FAR SDOCLIENT *p_client // Pointer to initialized SDO client structure
  )
{
  if ((p_client != 0) && ((p_client->status & 0x1F) != SDOCL_READY)) return TRUE;

  return FALSE;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_GetStatus (
  MEM_FAR SDOCLIENT *p_client // Pointer to initialized SDO client structure
  )
{
UNSIGNED8 ret_val = SDOERR_FATAL;

  if (p_client != 0)
  {
    if (p_client->last_abort < 0xFFFFFFFFUL)
    { // client not in use, check if there was an abort
      if (p_client->last_abort == 0)
      {
        ret_val = SDOERR_OK;
      }
      else if (p_client->last_abort == SDO_ABORT_TIMEOUT)
      {
        ret_val = SDOERR_TIMEOUT;
      }
      else if (p_client->last_abort == SDO_ABORT_NOTRANSFER)
      {
        ret_val = SDOERR_UNKNOWN;
      }
      else if (p_client->last_abort == SDO_ABORT_TOGGLE)
      {
        ret_val = SDOERR_TOGGLE;
      }
      else if (p_client->last_abort == SDO_ABORT_NOMEM)
      {
        ret_val = SDOERR_BUFSIZE;
      }
      else
      {
        ret_val = SDOERR_ABORT;
      }
    }
    else
    { // client in use
      ret_val = SDOERR_RUNNING;
    }
  }
  return ret_val;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED8 SDOCLNT_BlockUntilCompleted (
  MEM_FAR SDOCLIENT *p_client // Pointer to initialized SDO client structure
  )
{
UNSIGNED8 ret_val;

  ret_val = SDOERR_RUNNING;

  while(ret_val == SDOERR_RUNNING)
  {

#ifndef RTOS_SLEEP
    // No RTOS used, operate on CANopen device
    MCO_ProcessStack();
 #if MGR_MONITOR_ALL_NODES
    // Operate on Manager functionality
    MGR_ProcessMgr();
 #endif
#else
    // If used in RTOS, allow other tasks to run, define this Macro
    RTOS_SLEEP;
#endif

#ifdef __SIMULATION__
    // perform main loop operations needed for simulation
    SimDriver_MainLoop();
#endif
    // check status of client again
    ret_val = SDOCLNT_GetStatus(p_client); 
  }
  return ret_val;
}


/**************************************************************************
Description in sdoclnt.h
***************************************************************************/ 
UNSIGNED32 SDOCLNT_GetLastAbort (
  MEM_FAR SDOCLIENT *p_client // Pointer to initialized SDO client structure
  )
{
UNSIGNED32 ret_val = 0xFFFFFFFFUL;

  if (p_client != 0)
  {
    ret_val = p_client->last_abort;
  }
  return ret_val;
}



/**************************************************************************
DOES:    Gets executed if a CAN message was received that is the response
         to a SDO request
RETURNS: Nothing
***************************************************************************/ 
void MGR_HandleSDOClientResponse (
  MEM_FAR SDOCLIENT *p_client, // Pointer to SDO client structure for this response
  MEM_FAR UNSIGNED8 *pDat // Pointer to 8 bytes of SDO data received
  )
{
MEM_FAR UNSIGNED8 *pDest; // Destination pointer
UNSIGNED16 loop; // Loop counter
UNSIGNED32 len;
UNSIGNED8 lastseg;

  // Response received, so any existing timeout can be canceled / extended
  p_client->timeout = MCOHW_GetTime() + p_client->timeout_reload;
  p_client->b2btimeout = MCOHW_GetTime() + SDO_BACK2BACK_TIMEOUT;
  
#if USE_BLOCKED_SDO_CLIENT
  // are we receiving an SDO read block?
  if (p_client->status == SDOCL_BLOCK_READ + SDOCL_WAIT_RES)
  { // we are now receiving a read block
    p_client->toggle++; // count segments received
    if (p_client->toggle == (*pDat & 0x7F))
    { // only continue if sequence counter matches
      // is this last of block
      if ((p_client->toggle == SDO_BLK_MAX_SIZE) || (*pDat & 0x80))
      {
        p_client->status = SDOCL_BLOCK_RDCONF;
      }
      // retrieve data
      loop = 1;
      while ((p_client->curlen < p_client->buflen) && (loop <= 7))
      { // copy data received
        p_client->pBuf[p_client->curlen] = pDat[loop];
        p_client->curlen++;
        loop++;
      }
      // calculate number of bytes not used in segment
      p_client->n = 8 - loop;
    }
    else
    { // sequence error
      p_client->toggle--; // last segment not processed
    }
  }

  // are we receiving the SDO read block initialization confirmation?
  else if ((*pDat & 0xF9) == (6 << 5))
  { // SDO Block Upload (Read) init response confirmation
    // Blocked transfer in process
    p_client->status = SDOCL_BLOCK_READ;
    // size buflen
    len = pDat[7];
    len <<= 8;
    len += pDat[6];
    len <<= 8;
    len += pDat[5];
    len <<= 8;
    len += pDat[4];
    // check with max buffer size available
    if (p_client->bufmax >= len)
    { // if available buffer is big enough, correct data size
      p_client->buflen = len;
    }
    else
    { // buffer is not big enough
      p_client->status = SDOCL_READY;
      // Generate Abort
      SDOCLNT_SendSDOAbort(p_client,SDO_ABORT_NOMEM);
      // Inform application of abort
      SDOCLNT_SDOComplete(p_client->channel,SDOERR_ABORT);
    }
  }

  // do we receive the confirmation for our block confirmation sent?
  else if ((*pDat & 0xE3) == ((6 << 5) + 0x01))
  { // SDO Block Upload (Read) block confirmation
    // Blocked transfer in process
    p_client->status = SDOCL_BLOCK_RDFINA;
  }

  // is this the response to an SDO block write init request?
  else if (*pDat == 0xA0)
  { // SDO Block Download (Write) response confimration
    // Now switch to blocked transfer in process
    p_client->status = SDOCL_BLOCK_WRITE;
    // Maximum blksize
    p_client->blksize = pDat[4];
  }

  // is this the response to a block write completed confirmation?
  else if (*pDat == ((5 << 5) + 0x02))
  { // SDO Block Download (Write) block completed confirmation
    if (p_client->buflen == p_client->curlen)
    { // Blocked transfer completed, all transmitted
      p_client->status = SDOCL_BLOCK_WRCONF;
    }
    else
    {
      // Continue writing
      p_client->status = SDOCL_BLOCK_WRITE;
      // Maximum blksize for next block
      p_client->blksize = pDat[2];
      // restart counter
      p_client->toggle = 0;
    }
    // check number of confirmed blocks
    //if (pDat[4] < p_client->toggle)
  }

  // is this the final response to a block write?
  else if (*pDat == ((5 << 5) + 0x01))
  { // SDO Block Download (Write) final confirmation
    // free channel for new transfer
    p_client->status = SDOCL_BLOCK_WRFINA;
  }
  else
#endif // USE_BLOCKED_SDO_CLIENT
  if (*pDat == 0x80)
  { // SDO Abort received
    p_client->status = SDOCL_READY;
    SDOCLNT_SDOComplete(p_client->channel,SDOERR_ABORT);
  }
  // check if index and subindex information is in response
  else if ( ( (*pDat == 0x60) || ((*pDat & 0xF0) == 0x40) ) && 
       ( (pDat[1] != (UNSIGNED8)(p_client->index & 0x00FF)) || 
         (pDat[2] != (UNSIGNED8)((p_client->index & 0xFF00) >> 8)) || 
         (pDat[3] != p_client->subindex)
       )
     )
  { // response has index and subindex and they do not match
    p_client->status = SDOCL_READY;
    // Generate Abort
    SDOCLNT_SendSDOAbort(p_client,SDO_ABORT_PARAMETER);
    // Call-back application
    SDOCLNT_SDOComplete(p_client->channel,SDOERR_PARAM);
  }
  else if ((*pDat == 0x60) || (*pDat == 0x20) || (*pDat == 0x30))
  { // SDO Download (Write) response confimration
    // or next download segment confirmation
    p_client->status &= ~SDOCL_WAIT_RES;
    if ((p_client->status & SDOCL_SEGMENTED) == 0)
    { // only call the call-back if this is an expedited transfer
      SDOCLNT_SDOComplete(p_client->channel,SDOERR_OK);
    }
    // Verify toggle bit
    else if ((*pDat & 0x10) != p_client->toggle)
    {
      p_client->status = SDOCL_READY + SDOCL_SEGMENTED;
      // Generate Abort
      SDOCLNT_SendSDOAbort(p_client,SDO_ABORT_TOGGLE);
      // Inform application of abort
      SDOCLNT_SDOComplete(p_client->channel,SDOERR_TOGGLE);
    }
    else
    {
      // Check if this was the last segment
      if ((p_client->status & SDOCL_LAST_SEG) == SDOCL_LAST_SEG)
      {
        p_client->status = SDOCL_READY + SDOCL_SEGMENTED;
        // Call back application that transfer is completed
        SDOCLNT_SDOComplete(p_client->channel,SDOERR_OK);
      }
      else
      {
        p_client->status |= SDOCL_NEXT_DWN;

        // Set pointer to first data byte of next segment
        pDest = &(p_client->sdomsg.BUF[0]);

        // update toggle value for next usage
        if (p_client->curlen > 0)
        { // only start toggling after first segment was transferred
          if (p_client->toggle == 0)
          {
            p_client->toggle = 0x10;
          }
          else
          {
            p_client->toggle = 0x00;
          }
        }
        // Set command specifier for next request
        *pDest = p_client->toggle;

        // Copy next data segment
        if ((p_client->buflen > 7) && ((p_client->buflen-7) > p_client->curlen))
        { // more than 7 bytes remain for transfer
          lastseg = FALSE;  // This is not the last segment
          MEM_CPY_FAR(&(pDest[1]),&(p_client->pBuf[p_client->curlen]),7);
          p_client->curlen += 7;
        }
        else
        { // This is perhaps the last segment
#if SDOCLNTCB_APPSDO_WRITE
          UNSIGNED8 result;
          UNSIGNED32 MEM_FAR size;

          lastseg = TRUE;
          if (p_client->bufmax > p_client->curlen)
          {
            size = p_client->curlen;
          }
          else
          {
            size = p_client->bufmax;
          }
          // copy the remaining bytes, if any, to the beginning of the buffer
          MEM_CPY_FAR(&(p_client->pBuf[0]),&(p_client->pBuf[p_client->curlen]),p_client->buflen-p_client->curlen);
          // check for more data from the application
          result = SDOCLNTCB_SDOWriteComplete (
            p_client,
            p_client->index,
            p_client->subindex,
            &size,
            p_client->bufmax-size,
            &(p_client->pBuf[p_client->buflen-p_client->curlen])
          );
          // Is there more data from the application?
          if ((result > 0) && (size > 0))
          {
            // Keep track of total size
            p_client->bufmax -= p_client->curlen;
            // Adjust buffer length if application returns less than max.
            p_client->buflen = p_client->buflen - p_client->curlen + size;
            // Continue at beginning of buffer
            p_client->curlen = 0;
            // Copy next data segment
            if ((p_client->buflen > 7) && ((p_client->buflen-7) > p_client->curlen))
            { // more than 7 bytes remain for transfer
              MEM_CPY_FAR(&(pDest[1]),&(p_client->pBuf[p_client->curlen]),7);
              p_client->curlen += 7;
              lastseg = FALSE;  // This is not really the last segment
            }
          }
#else
          lastseg = TRUE;
#endif
          if (lastseg)
          {
            MEM_CPY_FAR(&(pDest[1]),&(p_client->pBuf[p_client->curlen]),p_client->buflen-p_client->curlen);
            // update command specifier: set bit for last segment
            *pDest |= 0x01;
            // and number of bytes that do not contain data
            len = p_client->buflen - p_client->curlen;
            *pDest += (7 - (UNSIGNED8) (len)) << 1;
            // update curlen counter
            p_client->curlen = p_client->buflen;
            // indicate last segment to SDO_HandleClient
            p_client->status |= SDOCL_LAST_SEG;
          }
        }
      }
    }
  }
  else if ((*pDat & 0xF3) == 0x43)
  { // SDO Upload (Read) Response Confirmation
    // Copy received data to destination
    len = 4 - ((*pDat >> 2) & 0x03);
    p_client->sdomsg.LEN = (UNSIGNED8) len;
    pDat += 4;
    pDest = p_client->pBuf;
    for (loop = 1; loop <= len; loop++)
    {
      *pDest = *pDat; 
      pDest++;
      pDat++;
    }
    p_client->curlen = len;
    p_client->status &= ~SDOCL_WAIT_RES;
    SDOCLNT_SDOComplete(p_client->channel,SDOERR_OK);
  } 
  else if ((*pDat == 0x41) || (*pDat == 0x40))
  { // Init segmented upload transfer,
    // data size indicated or not indicated
    p_client->status &= ~SDOCL_WAIT_RES;
    p_client->status |= SDOCL_NEXT_UPL;
    //gSDOClientList[channel].sdomsg.LEN = 8;
    p_client->sdomsg.BUF[0] = 0x60; 
    pDest = &(p_client->sdomsg.BUF[1]);
    for (loop = 1; loop <= 7; loop++)
    {
      *pDest = 0;
      pDest++;
    }
  }
  else if ((*pDat & 0xE0) == 0)
  { // SDO segment, upload (read)
    if ((*pDat & 0x10) != p_client->toggle)
    { // toggle error
      p_client->status = SDOCL_READY + SDOCL_SEGMENTED;
      // Generate Abort
      SDOCLNT_SendSDOAbort(p_client,SDO_ABORT_TOGGLE);
      // Call-back application
      SDOCLNT_SDOComplete(p_client->channel,SDOERR_TOGGLE);
    }
    else
    {
      len = 7 - ((*pDat & 0x0E) >> 1);
      if ((p_client->curlen + len) > p_client->buflen)
      { // destination buffer not big enough
        // Reset status info
        p_client->status = SDOCL_READY + SDOCL_SEGMENTED;
        // Generate Abort
        SDOCLNT_SendSDOAbort(p_client,SDO_ABORT_NOMEM);
        // Call-back application
        SDOCLNT_SDOComplete(p_client->channel,SDOERR_BUFSIZE);
      }
      else
      {
        MEM_CPY_FAR(&(p_client->pBuf[p_client->curlen]),&(pDat[1]),len);
        p_client->curlen += len;
        if ((*pDat & 0x01) == 1)
        { // This was the last segment, transfer completed
          // Reset status info
          p_client->status = SDOCL_READY + SDOCL_SEGMENTED;
          // Call-back application
          SDOCLNT_SDOComplete(p_client->channel,SDOERR_OK);
        }
        else
        { // more segments to come
          p_client->status = SDOCL_NEXT_UPL;
          if (p_client->toggle == 0)
          {
            p_client->toggle = 0x10;
            p_client->sdomsg.BUF[0] |= 0x10;
          }
          else
          {
            p_client->toggle = 0x00;
            p_client->sdomsg.BUF[0] &= 0xEF;
          }
        }
      }
    }
  }
  else
  { // Unknown SDO response received
    p_client->status = SDOCL_READY;
    // Generate Abort
    SDOCLNT_SendSDOAbort(p_client,SDO_ABORT_NOTRANSFER);
    // Call-back application
    SDOCLNT_SDOComplete(p_client->channel,SDOERR_UNKNOWN);
  }
}


/**************************************************************************
DOES:
RETURNS:  
***************************************************************************/ 
UNSIGNED8 MGR_SDOHandleClient (
  void
  )
{
#if USE_BLOCKED_SDO_CLIENT
UNSIGNED8 loop;
UNSIGNED8 lastseg;
#endif

  mCurrentChannel++; // working on next channel
  if (mCurrentChannel >= NR_OF_SDO_CLIENTS)
  { // ensure values are in allowed range
    mCurrentChannel = 0;
  }
  if ((gSDOClientList[mCurrentChannel].status & SDOCL_WAIT_RES) == SDOCL_WAIT_RES)
  { // currently waiting for a response
    if (MCOHW_IsTimeExpired(gSDOClientList[mCurrentChannel].timeout))
    { // abort transfer
      SDOCLNT_SendSDOAbort(&(gSDOClientList[mCurrentChannel]),SDO_ABORT_TIMEOUT);
      SDOCLNT_SDOComplete(mCurrentChannel+1,SDOERR_TIMEOUT);
      gSDOClientList[mCurrentChannel].status = SDOCL_READY;
      return TRUE;
    }
  }
  else if (((gSDOClientList[mCurrentChannel].status & SDOCL_NEXT_UPL) == SDOCL_NEXT_UPL) ||
           ((gSDOClientList[mCurrentChannel].status & SDOCL_NEXT_DWN) == SDOCL_NEXT_DWN)
          )
  { // ready to transmit next request
    if (MCOHW_IsTimeExpired(gSDOClientList[mCurrentChannel].b2btimeout))
    { // wait for timeout to avoid back-to-back traffic
      if (!MCOHW_PushMessage(&(gSDOClientList[mCurrentChannel].sdomsg)))
      { // Error: transmit queue overrun
        MCOUSER_FatalError(0x0333);
      }
      else
      { // message transmitted, set new timeout for response
        gSDOClientList[mCurrentChannel].timeout = MCOHW_GetTime() + gSDOClientList[mCurrentChannel].timeout_reload;
        // now wait for response
        gSDOClientList[mCurrentChannel].status |= SDOCL_WAIT_RES;
        return TRUE;
      }
    }
  }

#if USE_BLOCKED_SDO_CLIENT
  // are we in the middle of a write block?
  else if (gSDOClientList[mCurrentChannel].status == SDOCL_BLOCK_WRITE)
  { // ready to transmit next block part
    if (!MCOHW_IsTimeExpired(gSDOClientList[mCurrentChannel].b2btimeout))
    { // wait for timeout to avoid back-to-back traffic
      return FALSE;
    }
    if (gSDOClientList[mCurrentChannel].curlen < gSDOClientList[mCurrentChannel].buflen)
    { // Buffer not yet empty, more to transmit
      gSDOClientList[mCurrentChannel].toggle++;  
      gSDOClientList[mCurrentChannel].sdomsg.BUF[0] = gSDOClientList[mCurrentChannel].toggle;
      loop = 1;

      while ((gSDOClientList[mCurrentChannel].curlen < gSDOClientList[mCurrentChannel].buflen) && (loop <= 7))
      { // copy data
        gSDOClientList[mCurrentChannel].sdomsg.BUF[loop] = gSDOClientList[mCurrentChannel].pBuf[gSDOClientList[mCurrentChannel].curlen];
        loop++;
        gSDOClientList[mCurrentChannel].curlen++;
      }

#if SDOCLNTCB_APPSDO_WRITE
      // get more data to write from application
      {
        UNSIGNED8 result;
        UNSIGNED32 MEM_FAR size;

        if ((gSDOClientList[mCurrentChannel].curlen == gSDOClientList[mCurrentChannel].buflen) || (loop <= 7))
        { // segment not completely full, or complete buffer transmitted with last segment in sdomsg.BUF
          // copy the remaining bytes, if any, to the beginning of the buffer
          MEM_CPY_FAR(&(gSDOClientList[mCurrentChannel].pBuf[0]),&(gSDOClientList[mCurrentChannel].pBuf[gSDOClientList[mCurrentChannel].curlen]),gSDOClientList[mCurrentChannel].buflen-gSDOClientList[mCurrentChannel].curlen);

          if (gSDOClientList[mCurrentChannel].bufmax > gSDOClientList[mCurrentChannel].curlen)
          {
            size = gSDOClientList[mCurrentChannel].curlen;
          }
          else
          {
            size = gSDOClientList[mCurrentChannel].bufmax;
          }
          // check for more data from the application
          result = SDOCLNTCB_SDOWriteComplete (
            &gSDOClientList[mCurrentChannel],
            gSDOClientList[mCurrentChannel].index,
            gSDOClientList[mCurrentChannel].subindex,
            &size,
            gSDOClientList[mCurrentChannel].bufmax-size,
            &(gSDOClientList[mCurrentChannel].pBuf[gSDOClientList[mCurrentChannel].buflen-gSDOClientList[mCurrentChannel].curlen])
          );
          // Is there more data from the application?
          if ((result > 0) && (size > 0))
          {
            // Keep track of total size
            gSDOClientList[mCurrentChannel].bufmax -= gSDOClientList[mCurrentChannel].curlen;
            // Adjust buffer length if application returns less than max.
            gSDOClientList[mCurrentChannel].buflen = gSDOClientList[mCurrentChannel].buflen - gSDOClientList[mCurrentChannel].curlen + size;
            // Continue at beginning of buffer
            gSDOClientList[mCurrentChannel].curlen = 0;
            // Copy more data until segment full
            while ((gSDOClientList[mCurrentChannel].curlen < gSDOClientList[mCurrentChannel].buflen) && (loop <= 7))
            { // copy data
              gSDOClientList[mCurrentChannel].sdomsg.BUF[loop] = gSDOClientList[mCurrentChannel].pBuf[gSDOClientList[mCurrentChannel].curlen];
              loop++;
              gSDOClientList[mCurrentChannel].curlen++;
            }
          }
        }
      }
#endif

      
      gSDOClientList[mCurrentChannel].blksize--;  
      gSDOClientList[mCurrentChannel].n = 8 - loop; // number of unused bytes
      if ((gSDOClientList[mCurrentChannel].curlen == gSDOClientList[mCurrentChannel].buflen) || (gSDOClientList[mCurrentChannel].blksize == 0))
      { // end of block reached
        if (gSDOClientList[mCurrentChannel].curlen == gSDOClientList[mCurrentChannel].buflen)
        { // This is the very last message
          gSDOClientList[mCurrentChannel].sdomsg.BUF[0] |= 0x80; // last segment bit indication
        }
        gSDOClientList[mCurrentChannel].status = SDOCL_BLOCK_WRCONF + SDOCL_WAIT_RES;
      }
      if (!MCOHW_PushMessage(&(gSDOClientList[mCurrentChannel].sdomsg)))
      { // Error: transmit queue overrun
        MCOUSER_FatalError(0x0702);
      }
      // message transmitted, set new timeouts
      gSDOClientList[mCurrentChannel].b2btimeout = MCOHW_GetTime() + SDO_BACK2BACK_TIMEOUT;
      gSDOClientList[mCurrentChannel].timeout = MCOHW_GetTime() + gSDOClientList[mCurrentChannel].timeout_reload;
      return TRUE;
    }
  }

  // was a write block completed and needs to be confirmed?
  else if (gSDOClientList[mCurrentChannel].status == SDOCL_BLOCK_WRCONF)
  { // ready to send final block confirmation
    // set new state
    gSDOClientList[mCurrentChannel].status = SDOCL_BLOCK_WRFINA + SDOCL_WAIT_RES;
    // prepare confirmation message
    gSDOClientList[mCurrentChannel].sdomsg.BUF[0] = (6 << 5) + (gSDOClientList[mCurrentChannel].n << 2) + 0x01;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[1] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[2] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[3] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[4] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[5] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[6] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[7] = 0;
    if (!MCOHW_PushMessage(&(gSDOClientList[mCurrentChannel].sdomsg)))
    { // Error: transmit queue overrun
      MCOUSER_FatalError(0x0702);
    }
    // message transmitted, set new timeout for response
    gSDOClientList[mCurrentChannel].timeout = MCOHW_GetTime() + gSDOClientList[mCurrentChannel].timeout_reload;
    return TRUE;
  }

  // was a write block final confirmation sent?
  else if (gSDOClientList[mCurrentChannel].status == SDOCL_BLOCK_WRFINA)
  { // all completed, call back application 
    gSDOClientList[mCurrentChannel].status = SDOCL_READY; // available for next transfer
    SDOCLNT_SDOComplete(mCurrentChannel+1,SDOERR_OK);
    return TRUE;
  }

  // are we at end of a block read init transfer?
  else if (gSDOClientList[mCurrentChannel].status == SDOCL_BLOCK_READ)
  { // transmit one more request
    gSDOClientList[mCurrentChannel].sdomsg.BUF[0] = (5 << 5) + 0x03; // Command 5, subcommand 3
    gSDOClientList[mCurrentChannel].sdomsg.BUF[1] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[2] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[3] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[4] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[5] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[6] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[7] = 0;
    // Set flag: we wait for a response
    gSDOClientList[mCurrentChannel].status |= SDOCL_WAIT_RES;
    gSDOClientList[mCurrentChannel].timeout = MCOHW_GetTime() + gSDOClientList[mCurrentChannel].timeout_reload;
    if (!MCOHW_PushMessage(&(gSDOClientList[mCurrentChannel].sdomsg)))
    { // Error: transmit queue overrun
      MCOUSER_FatalError(0x0702);
    }
    return TRUE;
  }
  
  // in middle of receiving a read block
  else if (gSDOClientList[mCurrentChannel].status == SDOCL_BLOCK_RDCONF)
  {
    gSDOClientList[mCurrentChannel].sdomsg.BUF[0] = (5 << 5) + 0x02; // Command 5, subcommand 2
    gSDOClientList[mCurrentChannel].sdomsg.BUF[1] = gSDOClientList[mCurrentChannel].toggle; // confirm the number of segments received
    gSDOClientList[mCurrentChannel].sdomsg.BUF[2] = SDO_BLK_MAX_SIZE; // blksize
    gSDOClientList[mCurrentChannel].sdomsg.BUF[3] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[4] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[5] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[6] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[7] = 0;
    if (gSDOClientList[mCurrentChannel].buflen != gSDOClientList[mCurrentChannel].curlen)
    { // More blocks to come
      gSDOClientList[mCurrentChannel].status = SDOCL_BLOCK_READ + SDOCL_WAIT_RES;
      gSDOClientList[mCurrentChannel].toggle = 0; // start new block counter
    }
    else
    { // last block
      // Set flag: we wait for a response
      gSDOClientList[mCurrentChannel].status |= SDOCL_WAIT_RES;
    }
    gSDOClientList[mCurrentChannel].timeout = MCOHW_GetTime() + gSDOClientList[mCurrentChannel].timeout_reload;
    if (!MCOHW_PushMessage(&(gSDOClientList[mCurrentChannel].sdomsg)))
    { // Error: transmit queue overrun
      MCOUSER_FatalError(0x0702);
    }
    return TRUE;
  }

  // final confirmation of a read block
  else if (gSDOClientList[mCurrentChannel].status == SDOCL_BLOCK_RDFINA)
  { // final confirmation
    gSDOClientList[mCurrentChannel].sdomsg.BUF[0] = (5 << 5) + 0x01; // Command 5, subcommand 1
    gSDOClientList[mCurrentChannel].sdomsg.BUF[1] = 0;
    gSDOClientList[mCurrentChannel].sdomsg.BUF[2] = 0;
    gSDOClientList[mCurrentChannel].status = SDOCL_READY; // available for next transfer
    if (!MCOHW_PushMessage(&(gSDOClientList[mCurrentChannel].sdomsg)))
    { // Error: transmit queue overrun
      MCOUSER_FatalError(0x0702);
    }
    SDOCLNT_SDOComplete(mCurrentChannel+1,SDOERR_OK);
    return TRUE;
  }
#endif // USE_BLOCKED_SDO_CLIENT

  return FALSE;
}

#endif // NR_OF_SDO_CLIENTS > 0

/*******************************************************************************
END OF FILE
*******************************************************************************/
