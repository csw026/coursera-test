/**************************************************************************
MODULE:    MCOP_MGR_INC.h
CONTAINS:  MicroCANopen Plus Manager, all includes
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#ifndef _MCOP_MGR_H
#define _MCOP_MGR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mcop_inc.h"

#include "comgr.h"
#include "sdoclnt.h"
#include "concisedcf.h"

#if (USE_LSS_MANAGER == 1)
#include "lssmgr.h"
#endif
#if (USE_MLSS_MANAGER == 1)
#include "mlssmgr.h"
#endif
  
#ifdef __cplusplus
}
#endif

#endif // _MCOP_MGR_H
/**************************************************************************
END OF FILE
**************************************************************************/
