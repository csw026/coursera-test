/**************************************************************************
MODULE:    LSSMGR
CONTAINS:  MicroCANopen Plus implementation, LSS Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#include "mco.h"
#include "mcop.h"
#include "mcohw.h"
#include "comgr.h"
#include "lssmgr.h"


#if USE_LSS_MANAGER

/**************************************************************************
EXTERNAL GLOBAL VARIABLES
**************************************************************************/ 

// this structure holds all node specific configuration
extern MCO_CONFIG MEM_FAR gMCOConfig;


/**************************************************************************
INTERNAL MODUL VARIABLES
**************************************************************************/ 
// Pair of transmit and receive messages
CAN_MSG MEM_BUF mCANTx; 
CAN_MSG MEM_BUF mCANRx; 

/*******************************************************************************
PRIVATE FUNCTIONS
*******************************************************************************/

/**************************************************************************
DOES:    Initializes the LSS Master message for transmission
RETURNS: Nothing
***************************************************************************/ 
static void ClearCANTx (
  void
  )
{
  // Init the CAN transmit message
  mCANTx.ID = 2021; 
  mCANTx.LEN = 8;
  mCANTx.BUF[0] = 0;
  mCANTx.BUF[1] = 0;
  mCANTx.BUF[2] = 0;
  mCANTx.BUF[3] = 0;
  mCANTx.BUF[4] = 0;
  mCANTx.BUF[5] = 0;
  mCANTx.BUF[6] = 0;
  mCANTx.BUF[7] = 0;
}

/**************************************************************************
DOES:    Handles a LSS manager command sequence including timeout
RETURNS: TRUE, if sequence executed successful
***************************************************************************/ 
static UNSIGNED8 CmdSequence (
  UNSIGNED8 cmd,
  UNSIGNED8 dat1,
  UNSIGNED8 dat2,
  UNSIGNED16 timeout
  )
{
  timeout = MCOHW_GetTime() + timeout;
  ClearCANTx();

  // Send command
  mCANTx.BUF[0] = cmd;
  mCANTx.BUF[1] = dat1;
  mCANTx.BUF[2] = dat2;
  if (!MCOHW_PushMessage(&mCANTx))
  {
    return FALSE;
  }

  while ((!MCOHW_IsTimeExpired(timeout)) && (MCOHW_GetStatus() & HW_TXBSY))
  { // wait until all transmitted or timeout
  }
  if (MCOHW_GetStatus() & HW_TXBSY)
  { // transmit not yet completed
    return FALSE;
  }

  while (!MCOHW_IsTimeExpired(timeout));
  { // do until timeout
    if (MCOHW_PullMessage(&mCANRx))
    {
      if (mCANRx.ID == 2020)
      { // response received, data is in mCANRx.BUF
        return TRUE;
      }
    }
  }

  return FALSE;
}

/*******************************************************************************
PUBLIC FUNCTIONS
*******************************************************************************/

/**************************************************************************
Description in lssmgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_Init (
  UNSIGNED16 bps
  )
{
  if (MCOHW_Init(bps))
  {
    if (MCOHW_SetCANFilter(2020))
    {
      return TRUE;
    }
  }
  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_SwitchGlobal (
  UNSIGNED8 mode, // 0 for operation mode, 1 for configuration mode
  UNSIGNED16 timeout
  )
{
  timeout = MCOHW_GetTime() + timeout;

  // Prepare Tx message
  ClearCANTx();
  mCANTx.BUF[0] = 4;
  mCANTx.BUF[1] = mode;

  if (!MCOHW_PushMessage(&mCANTx))
  {
    return FALSE;
  }

  while ((!MCOHW_IsTimeExpired(timeout)) && (MCOHW_GetStatus() & HW_TXBSY))
  { // wait until transmitted or timeout
  }

  if (MCOHW_GetStatus() & HW_TXBSY)
  { // message not transmitted
    return FALSE;
  }

  return TRUE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_SwitchSelective (
  UNSIGNED32 lssid[4], // 128bit LSS ID
  UNSIGNED16 timeout
  )
{
  timeout = MCOHW_GetTime() + timeout;
  ClearCANTx();

  // 1st message, vendor ID
  mCANTx.BUF[0] = 64;
  mCANTx.BUF[1] = (UNSIGNED8) lssid[0];
  mCANTx.BUF[2] = (UNSIGNED8) (lssid[0] >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (lssid[0] >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (lssid[0] >> 24);
  if (!MCOHW_PushMessage(&mCANTx))
  {
    return FALSE;
  }

  // 2nd message, product code
  mCANTx.BUF[0] = 65;
  mCANTx.BUF[1] = (UNSIGNED8) lssid[1];
  mCANTx.BUF[2] = (UNSIGNED8) (lssid[1] >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (lssid[1] >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (lssid[1] >> 24);
  if (!MCOHW_PushMessage(&mCANTx))
  {
    return FALSE;
  }

  // 3rd message, revision
  mCANTx.BUF[0] = 66;
  mCANTx.BUF[1] = (UNSIGNED8) lssid[2];
  mCANTx.BUF[2] = (UNSIGNED8) (lssid[2] >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (lssid[2] >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (lssid[2] >> 24);
  if (!MCOHW_PushMessage(&mCANTx))
  {
    return FALSE;
  }

  // 4th message, serial
  mCANTx.BUF[0] = 67;
  mCANTx.BUF[1] = (UNSIGNED8) lssid[3];
  mCANTx.BUF[2] = (UNSIGNED8) (lssid[3] >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (lssid[3] >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (lssid[3] >> 24);
  if (!MCOHW_PushMessage(&mCANTx))
  {
    return FALSE;
  }

  while ((!MCOHW_IsTimeExpired(timeout)) && (MCOHW_GetStatus() & HW_TXBSY))
  { // wait until all transmitted or timeout
  }
  if (MCOHW_GetStatus() & HW_TXBSY)
  { // transmit not yet completed
    return FALSE;
  }

  do
  { // do until timeout
    if (MCOHW_PullMessage(&mCANRx))
    {
      if ((mCANRx.ID == 2020) && (mCANRx.BUF[0] == 68))
      { // response received
        return TRUE;
      }
    }
  }
  while (!MCOHW_IsTimeExpired(timeout));

  return FALSE;
}

/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_ConfigureNodeID (
  UNSIGNED8 nodeid, // 1-127
  UNSIGNED16 timeout
  )
{
  // execute command sequence
  if (CmdSequence(17,nodeid,0,timeout))
  {
    if ((mCANRx.BUF[0] == 17) && (mCANRx.BUF[1] == 0))
    { // return values indicate success
      return TRUE;
    }
  }
  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_ConfigureBitTiming (
  UNSIGNED8 bittime, 
  UNSIGNED16 timeout
  )
{
  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_ActivateBitTiming (
  UNSIGNED16 delay,
  UNSIGNED16 timeout
  )
{
  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_StoreConfiguration (
  UNSIGNED16 timeout
  )
{
  // execute command sequence
  if (CmdSequence(23,0,0,timeout))
  {
    if ((mCANRx.BUF[0] == 23) && (mCANRx.BUF[1] == 0))
    { // return values indicate success
      return TRUE;
    }
  }
  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_InquireID (
  UNSIGNED32 *plssid,
  UNSIGNED16 timeout
  )
{
  // execute command sequence, inquire vendor ID
  if (!(CmdSequence(90,0,0,timeout)))
  {
    return 0;
  }
  if (mCANRx.BUF[0] == 90)
  { // return values indicate success
    plssid[0] = mCANRx.BUF[4];
    plssid[0] <<= 8;
    plssid[0] += mCANRx.BUF[3];
    plssid[0] <<= 8;
    plssid[0] += mCANRx.BUF[2];
    plssid[0] <<= 8;
    plssid[0] += mCANRx.BUF[1];
  }

  // execute command sequence, inquire product ID
  if (!(CmdSequence(91,0,0,timeout)))
  {
    return 0;
  }
  if (mCANRx.BUF[0] == 91)
  { // return values indicate success
    plssid[1] = mCANRx.BUF[4];
    plssid[1] <<= 8;
    plssid[1] += mCANRx.BUF[3];
    plssid[1] <<= 8;
    plssid[1] += mCANRx.BUF[2];
    plssid[1] <<= 8;
    plssid[1] += mCANRx.BUF[1];
  }

  // execute command sequence, inquire revision
  if (!(CmdSequence(92,0,0,timeout)))
  {
    return 0;
  }
  if (mCANRx.BUF[0] == 92)
  { // return values indicate success
    plssid[2] = mCANRx.BUF[4];
    plssid[2] <<= 8;
    plssid[2] += mCANRx.BUF[3];
    plssid[2] <<= 8;
    plssid[2] += mCANRx.BUF[2];
    plssid[2] <<= 8;
    plssid[2] += mCANRx.BUF[1];
  }

  // execute command sequence, inquire serial
  if (!(CmdSequence(93,0,0,timeout)))
  {
    return 0;
  }
  if (mCANRx.BUF[0] == 93)
  { // return values indicate success
    plssid[3] = mCANRx.BUF[4];
    plssid[3] <<= 8;
    plssid[3] += mCANRx.BUF[3];
    plssid[3] <<= 8;
    plssid[3] += mCANRx.BUF[2];
    plssid[3] <<= 8;
    plssid[3] += mCANRx.BUF[1];
  }

  // execute command sequence, inquire node ID
  if (!(CmdSequence(94,0,0,timeout)))
  {
    return 0;
  }
  if (mCANRx.BUF[0] == 94)
  { // return values indicate success
    return mCANRx.BUF[1]; // node ID
  }

  return 0;
}



/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_IdentifyNonConfig (
  UNSIGNED16 timeout
  )
{
  // execute command sequence
  if (CmdSequence(76,0,0,timeout))
  {
    if (mCANRx.BUF[0] == 80)
    { // return values indicate success
      return TRUE;
    }
  }
  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_Identify (
  UNSIGNED32 vendor,
  UNSIGNED32 product,
  UNSIGNED32 rev_lo, // low value for revision
  UNSIGNED32 rev_hi, // high value for revision
  UNSIGNED32 ser_lo, // low value for serial
  UNSIGNED32 ser_hi, // high value for serial
  UNSIGNED16 timeout
  )
{
  // Clr receive queue
  while (MCOHW_PullMessage(&mCANRx))
  {
  }

  timeout = MCOHW_GetTime() + timeout;
  ClearCANTx();

  // 1st message, vendor ID
  mCANTx.BUF[0] = 70;
  mCANTx.BUF[1] = (UNSIGNED8) vendor;
  mCANTx.BUF[2] = (UNSIGNED8) (vendor >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (vendor >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (vendor >> 24);
  MCOHW_PushMessage(&mCANTx);

  // 2nd message, product code
  mCANTx.BUF[0] = 71;
  mCANTx.BUF[1] = (UNSIGNED8) product;
  mCANTx.BUF[2] = (UNSIGNED8) (product >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (product >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (product >> 24);
  MCOHW_PushMessage(&mCANTx);

  // 3rd message, revision low
  mCANTx.BUF[0] = 72;
  mCANTx.BUF[1] = (UNSIGNED8) rev_lo;
  mCANTx.BUF[2] = (UNSIGNED8) (rev_lo >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (rev_lo >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (rev_lo >> 24);
  MCOHW_PushMessage(&mCANTx);

  // 4th message, revision high
  mCANTx.BUF[0] = 73;
  mCANTx.BUF[1] = (UNSIGNED8) rev_hi;
  mCANTx.BUF[2] = (UNSIGNED8) (rev_hi >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (rev_hi >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (rev_hi >> 24);
  MCOHW_PushMessage(&mCANTx);

  // 5th message, serial low
  mCANTx.BUF[0] = 74;
  mCANTx.BUF[1] = (UNSIGNED8) ser_lo;
  mCANTx.BUF[2] = (UNSIGNED8) (ser_lo >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (ser_lo >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (ser_lo >> 24);
  MCOHW_PushMessage(&mCANTx);

  // final clr of receive queue
  while (MCOHW_PullMessage(&mCANRx))
  {
  }

  // 6th message, serial high
  mCANTx.BUF[0] = 75;
  mCANTx.BUF[1] = (UNSIGNED8) ser_hi;
  mCANTx.BUF[2] = (UNSIGNED8) (ser_hi >> 8);
  mCANTx.BUF[3] = (UNSIGNED8) (ser_hi >> 16);
  mCANTx.BUF[4] = (UNSIGNED8) (ser_hi >> 24);
  MCOHW_PushMessage(&mCANTx);

  while ((!MCOHW_IsTimeExpired(timeout)) && (MCOHW_GetStatus() & HW_TXBSY))
  { // wait until all transmitted or timeout
  }
  if (MCOHW_GetStatus() & HW_TXBSY)
  { // transmit not yet completed
    MCOUSER_FatalError(ERR_FATAL + 0x1543);
  }

  do
  { // do until timeout
    if (MCOHW_PullMessage(&mCANRx))
    {
      if (mCANRx.ID == 2020)
      { // response received
        // Clr receive queue from all other responses, wait at least 5ms
		timeout = MCOHW_GetTime() + 5;
        while (!MCOHW_IsTimeExpired(timeout))
		{
		  if (MCOHW_PullMessage(&mCANRx))
		  {
            if (mCANRx.ID == 2020)
			{ // this is another response, wait another 5ms
    		  timeout = MCOHW_GetTime() + 5;
			}
		  }
        }
	    return TRUE;
      }
    }
  }
  while (!MCOHW_IsTimeExpired(timeout));

  return FALSE;
}


/**************************************************************************
Description in comgr.h
***************************************************************************/ 
UNSIGNED8 LSSM_SearchDevice (
  UNSIGNED32 lss_id_lo[4], // lss_id with lo values for revision and serial
  UNSIGNED32 rev_hi, // high value for revision
  UNSIGNED32 ser_hi, // high value for serial
  UNSIGNED16 timeout
  )
{
UNSIGNED8 find_lo;
UNSIGNED32 middle;

  if (!LSSM_Identify(lss_id_lo[0],lss_id_lo[1],lss_id_lo[2],rev_hi,lss_id_lo[3],ser_hi,timeout))
  { // none found in range
    return FALSE;
  }

  // found in range, binary search for revision
  while (lss_id_lo[2] != rev_hi)
  {
    middle = (lss_id_lo[2] >> 1) + (rev_hi >> 1); // calculate middle
    // search from lo to middle
    find_lo = LSSM_Identify(lss_id_lo[0],lss_id_lo[1],lss_id_lo[2],middle,lss_id_lo[3],ser_hi,timeout);
    if (find_lo)
    { // make rev_mid new upper level
      rev_hi = middle;
    }
    else
    { // make rev_mid new lower level
      lss_id_lo[2] = middle+1;
    }
  }
  // now revision is found in rev_lo and rev_hi

  // binary search for serial
  while (lss_id_lo[3] != ser_hi)
  {
    middle = (lss_id_lo[3] >> 1) + (ser_hi >> 1); // calculate middle
    // search from lo to middle
    find_lo = LSSM_Identify(lss_id_lo[0],lss_id_lo[1],lss_id_lo[2],lss_id_lo[2],lss_id_lo[3],middle,timeout);
    if (find_lo)
    { // make rev_mid new upper level
      ser_hi = middle;
    }
    else
    { // make rev_mid new lower level
      lss_id_lo[3] = middle+1;
    }
  }
  // now serial is found in rev_lo and rev_hi

  return TRUE;
}

#endif // USE_LSS_MANAGER

/*******************************************************************************
END OF FILE
*******************************************************************************/
