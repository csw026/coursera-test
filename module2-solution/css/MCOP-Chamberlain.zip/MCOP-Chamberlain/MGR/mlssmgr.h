/**************************************************************************
MODULE:    MLSSMGR
CONTAINS:  MicroCANopen Plus implementation, MicroLSS/LSS FastScan Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#ifndef _MLSSMGR_H
#define _MLSSMGR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mco.h"


#if USE_MLSS_MANAGER


/**************************************************************************
MicroLSS Scan states of Master
***************************************************************************/ 
#define MLSS_INITOK       1 // Inititlaization OK, ready for next scan
#define MLSS_WAIT_NONCFG  2 // Waiting for response from non configured nodes
#define MLSS_SCANLPGO     3 // Scanning for next bit
#define MLSS_SCANLPWAIT   4 // Wait for response of current scan
#define MLSS_SCANCOMPLETE 5 // Scan completed, one node found
#define MLSS_CONFNODEWAIT 6 // configure node
#define MLSS_STORNODEWAIT 7 // node store config

// Definitions for optimized scan cycles
#define MLSS_BYTETRY      1
#define MLSS_BYTEFAIL     2

/**************************************************************************
Data structure with global (module level) data
***************************************************************************/ 
typedef struct
{
  CAN_MSG CANTx;        // LSS transmit msg
  CAN_MSG CANRx;        // LSS receive msg
  UNSIGNED32 lssids[4]; // ID scanned
  UNSIGNED16 Timeout;   // Timeout value
  UNSIGNED8 FailCnt;    // Failed counter
  UNSIGNED8 BitChecked; // MLSS control variable
  UNSIGNED8 LSSSub;     // MLSS control variable
  UNSIGNED8 LSSNext;    // MLSS control variable
  UNSIGNED8 State;      // Current LSS master state
  UNSIGNED8 Response;   // Response received?
  UNSIGNED8 NxtNodeID;  // next node ID to assign
#if MLSSM_BYTEOPTIMIZE == 1
  UNSIGNED8 Optimize;   // Optimized scan cycles supported
#endif
} MLSS_CONFIG;


/**************************************************************************
DOES:    Initializes the LSS Master/Manager, init of CAN interface
         and CAN receive filter for LSS response
RETURNS: TRUE, if initalization sucess
***************************************************************************/ 
UNSIGNED8 MLSSM_Init (
  UNSIGNED16 bps,        // CAN bit rate
  UNSIGNED8 startnodeid  // starting node id for configuration
  );


/**************************************************************************
DOES:    Processes MicroLSS scans in the background, one step at the time
         Call repeatedly to realize continous background scanning
RETURNS: TRUE as long as scanning is in progress, only returns FALSE when
         no non configured node was detetced
***************************************************************************/ 
UNSIGNED8 MLSSM_ProcessScan (
  void
  );


/**************************************************************************
DOES:    Scans the network for MicroLSS/LSS FastScan slaves and configures
         them using sequential node IDs
RETURNS: -
***************************************************************************/ 
void MLSSM_ScanAndConfig (
  UNSIGNED16 timeout      // slave response timeout in ms
  );


/**************************************************************************
DOES:    Call-back to application, response to a store configuration
         confirmation received
RETURNS: -
***************************************************************************/ 
void MGRCB_LSSIdentified (
  MEM_FAR UNSIGNED8 *pDat // Pointer to 8 data bytes received
  );


#endif // USE_MLSS_MANAGER

#ifdef __cplusplus
}
#endif

#endif // _MLSSMGR_H
/**************************************************************************
END OF FILE
**************************************************************************/
