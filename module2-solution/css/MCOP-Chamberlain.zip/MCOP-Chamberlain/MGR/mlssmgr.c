/**************************************************************************
MODULE:    MLSSMGR
CONTAINS:  MicroCANopen Plus implementation, MicroLSS/LSS FastScan Manager
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS FILE IS PART OF THE MICROCANOPEN PLUS CANOPEN MANAGER
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-10-07 10:26:03 -0500 (Sat, 07 Oct 2017) $
           $LastChangedRevision: 4017 $
***************************************************************************/ 

#include "mco.h"
#include "mcop.h"
#include "mcohw.h"
#include "comgr.h"
#include "mlssmgr.h"


#if USE_MLSS_MANAGER

/**************************************************************************
EXTERNAL GLOBAL VARIABLES
**************************************************************************/ 

// this structure holds all node specific configuration
extern MCO_CONFIG MEM_FAR gMCOConfig;


/**************************************************************************
INTERNAL MODULE VARIABLES
**************************************************************************/ 
MLSS_CONFIG MEM_FAR mLSSM; // holds all variables needed by MicroLSS Master

/*******************************************************************************
PRIVATE FUNCTIONS
*******************************************************************************/

/**************************************************************************
DOES:    Initializes the LSS Master message for transmission
RETURNS: Nothing
***************************************************************************/ 
static void MLSSM_ClearCANTx (
  void
  )
{
  // Init the CAN transmit message
  mLSSM.CANTx.ID = 2021; 
  mLSSM.CANTx.LEN = 8;
  mLSSM.CANTx.BUF[0] = 0;
  mLSSM.CANTx.BUF[1] = 0;
  mLSSM.CANTx.BUF[2] = 0;
  mLSSM.CANTx.BUF[3] = 0;
  mLSSM.CANTx.BUF[4] = 0;
  mLSSM.CANTx.BUF[5] = 0;
  mLSSM.CANTx.BUF[6] = 0;
  mLSSM.CANTx.BUF[7] = 0;
}


/**************************************************************************
DOES:    Transmits an LSS identify message
RETURNS: TRUE if message transmitted successfully, otherwise returns FALSE
***************************************************************************/ 
static UNSIGNED8 MLSSM_TxIdentifyMsg (
  UNSIGNED32 IDNumber,           // id number
  UNSIGNED8  BitChecked,         // bit checked value
  UNSIGNED8  LSSSub,             // id number selector
  UNSIGNED8  LSSNext             // next id number selector
  )
{
  // Init the CAN transmit message
  mLSSM.CANTx.ID     = 2021; 
  mLSSM.CANTx.LEN    = 8;
  mLSSM.CANTx.BUF[0] = 81;
  mLSSM.CANTx.BUF[1] = (UNSIGNED8) IDNumber;
  mLSSM.CANTx.BUF[2] = (UNSIGNED8)(IDNumber >> 8);
  mLSSM.CANTx.BUF[3] = (UNSIGNED8)(IDNumber >> 16);
  mLSSM.CANTx.BUF[4] = (UNSIGNED8)(IDNumber >> 24);
  mLSSM.CANTx.BUF[5] = BitChecked;
  mLSSM.CANTx.BUF[6] = LSSSub;
  mLSSM.CANTx.BUF[7] = LSSNext;

  mLSSM.Response = 0; // no response received

  if (MCOHW_PushMessage(&(mLSSM.CANTx)))
  {
    return TRUE;
  }

  return FALSE;
}


#if USE_CiA447
/**************************************************************************
DOES:    Find an unsudes node ID startin at a given node number.
         Looking in nodelist for free entry.
RETURNS: TRUE if new value set to mLSSM.NxtNodeID
***************************************************************************/ 
static UNSIGNED8 MLSSM_FindUnusedNodeID (
  UNSIGNED8 start // start looking at this node ID
  )
{
UNSIGNED8 loop;

  // First check if node was previously used
  loop = 0;
  while (loop < MAX_NR_OF_NODES)
  {
    if ( ( gNodeList[loop].id_1018[0] == mLSSM.lssids[0]) &&
         ( gNodeList[loop].id_1018[1] == mLSSM.lssids[1]) &&
         ( gNodeList[loop].id_1018[2] == mLSSM.lssids[2]) &&
         ( gNodeList[loop].id_1018[3] == mLSSM.lssids[3])
       )
    {
      mLSSM.NxtNodeID = loop+1;
      return TRUE;
    }
    loop++; 
  }

  start--; // Adjust from 1,MAX_NR_OF_NODES to 0,MAX_NR_OF_NODES-1
  while (start < MAX_NR_OF_NODES)
  { 
    if (gNodeList[start].id_scanstat == IDSCAN_NONE)
    { // unused entry found
        mLSSM.NxtNodeID = start+1;
        return TRUE;
    }
    start++;
  }
  return FALSE;
}
#endif


/**************************************************************************
DOES:    Configures the selected LSS node to use a specific node ID
         The LSS node must already be in configuration mode and the only
         LSS node on the network to be in that mode
RETURNS: TRUE if transmit completed, otherwise returns FALSE
***************************************************************************/ 
static UNSIGNED8 MLSSM_ConfigureNode (
  UNSIGNED8 nodeid                  // node id to use
  )
{
  MLSSM_ClearCANTx();

  // construct nodeid configuration message
  mLSSM.CANTx.BUF[0] = 0x11;
  mLSSM.CANTx.BUF[1] = nodeid;

  mLSSM.Response = 0; // no response received

  return(MCOHW_PushMessage(&(mLSSM.CANTx)));
}


/**************************************************************************
DOES:    Requests that the current LSS nodes stores the configuration
RETURNS: TRUE if transmit completed, otherwise returns FALSE
***************************************************************************/ 
static UNSIGNED8 MLSSM_StoreConfig (
  void
  )
{
  MLSSM_ClearCANTx();

  // construct store configuration message
  mLSSM.CANTx.BUF[0] = 0x17;

  mLSSM.Response = 0; // no response received

  return(MCOHW_PushMessage(&(mLSSM.CANTx)));
}


/**************************************************************************
DOES:    Requests that the current LSS nodes switches to operational
RETURNS: TRUE if transmit completed, otherwise returns FALSE
***************************************************************************/ 
static UNSIGNED8 MLSSM_SwitchOperational (
  void
  )
{
  MLSSM_ClearCANTx();

  // construct switch global operation message
  mLSSM.CANTx.BUF[0] = 0x04;

  mLSSM.Response = 0; // no response received

  return(MCOHW_PushMessage(&(mLSSM.CANTx)));
}

/*******************************************************************************
PUBLIC FUNCTIONS
*******************************************************************************/

/**************************************************************************
Description in lssmgr.h
***************************************************************************/ 
UNSIGNED8 MLSSM_Init (
  UNSIGNED16 bps,
  UNSIGNED8 nodeid
  )
{
  mLSSM.State = 0; // nothing done yet
  mLSSM.Response = 0; // no response received
  mLSSM.Timeout = MCOHW_GetTime(); // start immediately (no timeout)
  mLSSM.FailCnt = 0; // no failure yet
  mLSSM.NxtNodeID = nodeid;
  if (MCOHW_Init(bps))
  {
#if MGR_MONITOR_ALL_NODES
    if (MCOHWMGR_SetCANFilter())
#endif
    {
      mLSSM.State = MLSS_INITOK;
      return TRUE;
    }
  }
  return FALSE;
}


/**************************************************************************
Description in lssmgr.h
***************************************************************************/ 
UNSIGNED8 MLSSM_ProcessScan (
  void
  )
{
UNSIGNED8 ret_value = FALSE;

  switch (mLSSM.State)
  {

  case MLSS_INITOK: // initialized
    if (MCOHW_IsTimeExpired(mLSSM.Timeout))
    {
      mLSSM.BitChecked = 0x80;            // start with init/restart value
      mLSSM.LSSSub = 0;                   // start with vendor ID
      mLSSM.LSSNext = 0;                  // start with vendor ID
      mLSSM.lssids[0] = 0x00000000;       // set lss id back to zero
      mLSSM.lssids[1] = 0x00000000;       
      mLSSM.lssids[2] = 0x00000000;       
      mLSSM.lssids[3] = 0x00000000;       
      // send initial message
      MLSSM_TxIdentifyMsg(mLSSM.lssids[0], mLSSM.BitChecked, mLSSM.LSSSub, mLSSM.LSSNext);
      // next state
      mLSSM.State = MLSS_WAIT_NONCFG; // wait for non configured nodes
      mLSSM.Timeout = MCOHW_GetTime() + MLSSM_TIMEOUT + (mLSSM.FailCnt * MLSSM_TIMEOUTINCREASE);
    }
    break;

  case MLSS_WAIT_NONCFG:
    if (MCOHW_IsTimeExpired(mLSSM.Timeout))
    {
      if (mLSSM.Response != 0)
      { // non configured node detected, start scan
        mLSSM.LSSSub = 0;
        mLSSM.lssids[mLSSM.LSSSub] = 0;
        mLSSM.BitChecked = 32;
        mLSSM.State = MLSS_SCANLPGO; // start scan loop
        ret_value = TRUE; // currently scanning
      }
      else
      { // no non configured node, try again later
        mLSSM.State = MLSS_INITOK; // start over
        mLSSM.Timeout = MCOHW_GetTime() + MLSSM_SCANTIME;
        mLSSM.FailCnt = 0; // no failure
      }
    }
    break;

  case MLSS_SCANLPGO:
    if (mLSSM.BitChecked == 0)
    { // end of 32 bit cycle
      mLSSM.LSSSub++; // next 32 bits
      mLSSM.BitChecked = 32;
    }
    // work on next bit
    mLSSM.BitChecked--;
#if MLSSM_BYTEOPTIMIZE == 1
    if (((mLSSM.BitChecked & 7) == 7) && (mLSSM.BitChecked != 7))
    {
      if (mLSSM.Optimize & MLSS_BYTEFAIL)
      { // already tried this and it failed
        mLSSM.Optimize &= ~MLSS_BYTEFAIL;  
      }
      else
      {
        mLSSM.BitChecked -= 7;
        mLSSM.Optimize |= MLSS_BYTETRY;
      }
    }
#endif
    if (mLSSM.BitChecked == 0)
    { // this is the last of 32 bits
      mLSSM.LSSNext = mLSSM.LSSSub + 1;
    }
    if (mLSSM.LSSSub <= 3)
    { // send next identification message
      MLSSM_TxIdentifyMsg(mLSSM.lssids[mLSSM.LSSSub], mLSSM.BitChecked, mLSSM.LSSSub, mLSSM.LSSNext);
      mLSSM.State = MLSS_SCANLPWAIT;
      mLSSM.Timeout = MCOHW_GetTime() + MLSSM_TIMEOUT + (mLSSM.FailCnt * MLSSM_TIMEOUTINCREASE);
      ret_value = TRUE; // currently scanning
    }
    else
    { // scan completed!
      mLSSM.State = MLSS_SCANCOMPLETE;
    }
    break;

  case MLSS_SCANLPWAIT:
    if (MCOHW_IsTimeExpired(mLSSM.Timeout))
    {
      mLSSM.State = MLSS_SCANLPGO; // next bit

      if (mLSSM.Response != 0x4F)
      { // no response
#if MLSSM_BYTEOPTIMIZE == 1
        if (mLSSM.Optimize & MLSS_BYTETRY)
        { // byte test failed
          mLSSM.BitChecked += 8; // test byte again
          mLSSM.Optimize |= MLSS_BYTEFAIL;
          mLSSM.Optimize &= ~MLSS_BYTETRY;
        }
        else
        {
#endif
        // endless-loop check
        if (mLSSM.lssids[mLSSM.LSSSub] & (1ul << (mLSSM.BitChecked)))
        { // this bit already set -> something went wrong
          mLSSM.State = MLSS_INITOK; // reset state machine, start over
          mLSSM.FailCnt++;
          if (mLSSM.FailCnt > MLSSM_MAXFAIL)
          { 
            mLSSM.FailCnt =	MLSSM_MAXFAIL;
          }
          mLSSM.Timeout = MCOHW_GetTime() + MLSSM_SCANTIME;
        }
        else
        {
          // no match with zero, so set bit
          mLSSM.lssids[mLSSM.LSSSub] |= (1ul << (mLSSM.BitChecked));
          // Verify that complete 32 bit value matches
          if (mLSSM.lssids[mLSSM.LSSSub] & 1ul) // this is the last bit
          { // send one more request to match entire 32 bits
            MLSSM_TxIdentifyMsg(mLSSM.lssids[mLSSM.LSSSub], mLSSM.BitChecked, mLSSM.LSSSub, mLSSM.LSSNext);
            mLSSM.State = MLSS_SCANLPWAIT; // wait for response on this
            mLSSM.Timeout = MCOHW_GetTime() + MLSSM_TIMEOUT + (mLSSM.FailCnt * MLSSM_TIMEOUTINCREASE);
          }
        }
#if MLSSM_BYTEOPTIMIZE == 1
        }
#endif
      }
#if MLSSM_BYTEOPTIMIZE == 1
      else
      {
        mLSSM.Optimize &= ~MLSS_BYTETRY;
      }
#endif
    }
    break;

  case MLSS_SCANCOMPLETE:
#if USE_CiA447
    if (MLSSM_FindUnusedNodeID(mLSSM.NxtNodeID))
    { // Assign next unused node ID
      MLSSM_ConfigureNode(mLSSM.NxtNodeID);
    }
#else
    MLSSM_ConfigureNode(mLSSM.NxtNodeID);
#endif
    mLSSM.NxtNodeID++;
    mLSSM.State = MLSS_CONFNODEWAIT; // wait for response on this
    mLSSM.Timeout = MCOHW_GetTime() + MLSSM_TIMEOUT + (mLSSM.FailCnt * MLSSM_TIMEOUTINCREASE);
    break;

  case MLSS_CONFNODEWAIT:
    if ((MCOHW_IsTimeExpired(mLSSM.Timeout)) || (mLSSM.Response == 0x11))
    {
      if (mLSSM.Response == 0x11)
      {
        MLSSM_StoreConfig();
        mLSSM.State = MLSS_STORNODEWAIT; // wait for response on this
      }
      else
      { // Timeout
        mLSSM.State = MLSS_INITOK; // start over
        mLSSM.FailCnt++; // failure
        if (mLSSM.FailCnt > MLSSM_MAXFAIL)
        { 
          mLSSM.FailCnt = MLSSM_MAXFAIL;
        }
      }
      mLSSM.Timeout = MCOHW_GetTime() + MLSSM_SCANTIME;
    }
    break;

  case MLSS_STORNODEWAIT:
    if ((MCOHW_IsTimeExpired(mLSSM.Timeout)) || (mLSSM.Response == 0x17u))
    {
      MLSSM_SwitchOperational();
      mLSSM.State = MLSS_INITOK; // reset state machine / start over
      mLSSM.Timeout = MCOHW_GetTime() + MLSSM_TIMEOUT + (mLSSM.FailCnt * MLSSM_TIMEOUTINCREASE);
    }
    break;

  default:
    mLSSM.State = MLSS_INITOK; // reset state machine
    break;
  }
  
  return ret_value;
}


/**************************************************************************
Description in lssmgr.h
***************************************************************************/ 
void MLSSM_ScanAndConfig(
  UNSIGNED16 timeout
  )
{
UNSIGNED8 cont_scan;
UNSIGNED16 cont_time;

  cont_scan = TRUE;
  cont_time = MCOHW_GetTime() + timeout;

  while((cont_scan) || !MCOHW_IsTimeExpired(cont_time))
  { // as long as unconfigured nodes are found, and timeout not expired, continue

    // operate on scanning
    cont_scan = MLSSM_ProcessScan();
    if (cont_scan)
    { // as long as there is scanning to do, increase timeout
      cont_time = MCOHW_GetTime() + timeout;
    }

    // Operate on CANopen protocol stack
    MCO_ProcessStack();

#if MGR_MONITOR_ALL_NODES
    // Operate on Manager functionality
    MGR_ProcessMgr();
#endif
  }
}


/**************************************************************************
Description in lssmgr.h
***************************************************************************/ 
void MGRCB_LSSIdentified (
  MEM_FAR UNSIGNED8 *pDat
  )
{
  if (pDat[0] != 0)
  {
    mLSSM.Response = pDat[0]; // report first byte to LSS Master
  }
}

#endif // USE_MLSS_MANAGER

/*******************************************************************************
END OF FILE
*******************************************************************************/
