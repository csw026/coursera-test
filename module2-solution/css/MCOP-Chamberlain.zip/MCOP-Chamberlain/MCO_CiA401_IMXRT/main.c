/**************************************************************************
MODULE:    MAIN
CONTAINS:  Example application using MicroCANopen
           NXP i.MX RT 105x derivatives with CAN interface.
           Compiled and Tested with MCUXpresso 10.2
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-04-11 12:07:31 +0200 (Wed, 11 Apr 2018) $
           $LastChangedRevision: 4275 $
***************************************************************************/ 

// Include all MicroCANopen Plus relevant files
#include "mcop_inc.h"


/**************************************************************************
GLOBAL VARIABLES
**************************************************************************/

// external declaration for the process image array
extern UNSIGNED8 MEM_PROC gProcImg[];


/**************************************************************************
DOES:    The main function
RETURNS: nothing
**************************************************************************/
int main(
  void
  )
{
UNSIGNED32 pot;      // Analog value / counter
UNSIGNED8 buf[4];    // buffer to process image

  /* Board pin, clock, debug console init */
  BOARD_ConfigMPU();
  BOARD_InitPins();
  BOARD_BootClockRUN();
  BOARD_InitDebugConsole();

  /* Enable clock gate for GPIO1 */
  CLOCK_EnableClock(kCLOCK_Gpio1);

  /* Set PERCLK_CLK source to OSC_CLK*/
  CLOCK_SetMux(kCLOCK_PerclkMux, 1U);
  /* Set PERCLK_CLK divider to 2 */
  CLOCK_SetDiv(kCLOCK_PerclkDiv, 1U);

  /* Initialize and enable LED */
  USER_LED_INIT(LOGIC_LED_OFF);
 
  // Reset/Initialize CANopen communication
  MCOUSER_ResetCommunication();

  // foreground loop
  while(1)
  {
    // Operate on CANopen protocol stack
    MCO_ProcessStack();

    // Test: echo some data
    gProcImg[P600003_DIGINPUT8_3] = gProcImg[P620003_DIGOUTPUT8_3];
    gProcImg[P600004_DIGINPUT8_4] = gProcImg[P620004_DIGOUTPUT8_4];

    // Update process data

    // Read output value from PI
    MCO_ReadProcessData(buf,4,P641101_ANALOGOUTPUT16_1+1);
    // Add: Output to physical I/O

    // first analog input is a counter
    pot++;

    buf[0] = pot & 0x000000FF; // lo byte
    buf[1] = (pot >> 8) & 0x000000FF; // hi byte
    // Write analog data to process image
    MCO_WriteProcessData(P640101_ANALOGINPUT16_1,2,buf);

    // Check for CAN Err, auto-recover
    if (MCOHW_GetStatus() & HW_BOFF)
    {
      MCOUSER_FatalError(0xF6F6);
    }

  } // end of while(1)
} // end of main

