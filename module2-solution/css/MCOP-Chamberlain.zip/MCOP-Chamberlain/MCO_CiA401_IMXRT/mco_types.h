/**************************************************************************
MODULE:    MCO_TYPES.H
CONTAINS:  Data types used by MicroCANopen
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-04-11 12:07:31 +0200 (Wed, 11 Apr 2018) $
           $LastChangedRevision: 4275 $
***************************************************************************/ 

#ifndef _MCO_TYPES_H
#define _MCO_TYPES_H


/**************************************************************************
DEFINES: MEMORY TYPE OPTIMIZATION
**************************************************************************/

// CONST Object Dictionary Data
#define MEM_CONST const

// Process data
#define MEM_PROC

// buffers
#define MEM_BUF

// non-process data
#define MEM_FAR


/**************************************************************************
DEFINES: TRUE AND FALSE
**************************************************************************/
#ifndef TRUE
#define TRUE  (1==1)
#endif
#ifndef FALSE
#define FALSE (!TRUE)
#endif

#ifndef NOT_SET
#define NOT_SET 2
#endif


/**************************************************************************
TYPEDEF: CANOPEN DATA TYPES
**************************************************************************/
typedef unsigned char UNSIGNED8;
typedef unsigned short UNSIGNED16;
typedef unsigned int UNSIGNED32;
typedef char INTEGER8;
typedef short INTEGER16;
typedef int INTEGER32;


/**************************************************************************
TYPEDEF: CAN IDENTIFIER TYPE
         Plain CANopen does not use 29-bit IDs, use 16 here for memory
         optimization.
**************************************************************************/
#define CAN_ID_SIZE 16

#if CAN_ID_SIZE == 16
typedef UNSIGNED16 COBID_TYPE;
#define COBID_DISABLED 0x8000U
#define COBID_RTR      0x4000U
#define COBID_EXT      0x2000U
#define COBID_MASK     0xE000U
#elif CAN_ID_SIZE == 32
typedef UNSIGNED32 COBID_TYPE;
#define COBID_DISABLED 0x80000000UL
#define COBID_RTR      0x40000000UL
#define COBID_EXT      0x20000000UL
#define COBID_MASK     0xE0000000UL
#else
#error Only CAN_ID_SIZE 16 or 32 is possible
#endif

#endif  // _MCO_TYPES_H
