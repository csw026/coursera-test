/**************************************************************************
MODULE:    MCOHW_LED
CONTAINS:  Macro definition for LED switching
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   This file may be freely distributed.
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-04-11 12:07:31 +0200 (Wed, 11 Apr 2018) $
           $LastChangedRevision: 4275 $
***************************************************************************/ 

#ifndef _LED_H
#define _LED_H

#if USE_LEDS

#ifdef __SIMULATION__

#define LED_RUN_ON SimDriver_UpdateLEDState(SIMDRV_RUNLED, 1) 
#define LED_RUN_OFF SimDriver_UpdateLEDState(SIMDRV_RUNLED, 0)
#define LED_ERR_ON SimDriver_UpdateLEDState(SIMDRV_ERRLED, 1) 
#define LED_ERR_OFF SimDriver_UpdateLEDState(SIMDRV_ERRLED, 0) 

#else

#ifndef MCO_INSTANCE
  #define LED_RUN_ON {USER_LED_ON();}
  #define LED_RUN_OFF {USER_LED_OFF();}
  #define LED_ERR_ON {}
  #define LED_ERR_OFF {}
#else
  #if (MCO_INSTANCE == 1)
    #define LED_RUN_ON {USER_LED_ON();}
    #define LED_RUN_OFF {USER_LED_OFF();}
    #define LED_ERR_ON {}
    #define LED_ERR_OFF {}
  #elif (MCO_INSTANCE == 2)
    #define LED_RUN_ON {}
    #define LED_RUN_OFF {}
    #define LED_ERR_ON {}
    #define LED_ERR_OFF {}
  #endif
#endif

#endif // __SIMULATION__

#endif // USE_LEDS

#endif
