/**************************************************************************
MODULE:    MCOHW_NVOL_SIM
CONTAINS:  Simulation of non-volatile memory, here in regular RAM
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN PLUS
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt or
           www.microcanopen.com/license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2017-09-18 08:57:32 +0200 (Mon, 18 Sep 2017) $
           $LastChangedRevision: 3997 $
***************************************************************************/ 

#include "mcohw.h"

#if USE_STORE_PARAMETERS

// Simulated non-volatile memory, here: regular RAM, must not be initialized on startup!

#if !defined(MCO_INSTANCE) || (MCO_INSTANCE==1)
UNSIGNED8 *mNVOL = (UNSIGNED8 *)(0x20000000ul+0x20000ul - NVOL_STORE_SIZE);
#elif (MCO_INSTANCE==2)
UNSIGNED8 *mNVOL = (UNSIGNED8 *)(0x20000000ul+0x20000ul - NVOL_STORE_SIZE - NVOL_STORE_SIZE);
#endif

/**************************************************************************
DOES:    Initializes access to non-volatile memory.
**************************************************************************/
void NVOL_Init (
  void
  )
{
  return;
}

/**************************************************************************
DOES:    Reads a data byte from non-volatile memory
NOTE:    The address is relative, an offset to NVOL_STORE_START
RETURNS: The data read from memory
**************************************************************************/
UNSIGNED8 NVOL_ReadByte (
  UNSIGNED16 address // location of byte in NVOL memory
  )
{
  // Protect from illegal address access
  if (address >= NVOL_STORE_SIZE) return 0;
  return mNVOL[address];
}


/**************************************************************************
DOES:    Writes a data byte to non-volatile memory
NOTE:    The address is relative, an offset to NVOL_STORE_START
RETURNS: nothing
**************************************************************************/
void NVOL_WriteByte (
  UNSIGNED16 address, // location of byte in NVOL memory
  UNSIGNED8 data
  )
{
  // Protect from illegal address access
  if (address >= NVOL_STORE_SIZE) return;
  mNVOL[address] = data;
}


/**************************************************************************
DOES:    Is called when a block of write cycles is complete. The driver
         may buffer the data from calls to NVOL_WriteByte in RAM and then
         write the entire buffer to non-volatile memory upon a call to
         this function.
**************************************************************************/
void NVOL_WriteComplete (
  void
  )
{
  return;
}
#endif // USE_STORE_PARAMETERS

/*----------------------- END OF FILE ----------------------------------*/

