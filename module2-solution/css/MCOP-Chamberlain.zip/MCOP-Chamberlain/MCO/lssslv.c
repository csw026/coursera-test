/**************************************************************************
MODULE:    LSSSLV
CONTAINS:  MicroCANopen Plus - Support for Layer Setting Services
COPYRIGHT: Embedded Systems Academy, Inc. 2002-2017
           All rights reserved. www.microcanopen.com
DISCLAIM:  Read and understand our disclaimer before using this code!
           www.esacademy.com/disclaim.htm
           This software was written in accordance to the guidelines at
           www.esacademy.com/software/softwarestyleguide.pdf
LICENSE:   THIS IS THE COMMERCIAL VERSION OF MICROCANOPEN
           ONLY USERS WHO PURCHASED A LICENSE MAY USE THIS SOFTWARE
           See file license_commercial_plus.txt
VERSION:   6.30, ESA 18-SEP-17
           $LastChangedDate: 2018-03-13 08:02:44 -0500 (Tue, 13 Mar 2018) $
           $LastChangedRevision: 4241 $
DEFINES:   USE_MICROLSS and USE_LSS_SLAVE must both be defined.
***************************************************************************/

#include "mcop_inc.h"
#include "stackinit.h"
#include <string.h>

#if USE_STORE_PARAMETERS
// usage areas of the nvol memory
static UNSIGNED16 nvol_offsets[5];

// External function for NVOL storage of LSS info
extern void MCOSP_GetNVOLUsage (UNSIGNED16 pLoc[5]);
#endif

#if USE_LSS_SLAVE
// Only use all functions if project is configured for LSS Slave

#if ! USE_MICROLSS
#error "USE_LSS_SLAVE and USE_MICROLSS must be defined to use this module"
#endif

#if MLSS_ONLY
#error "MLSS_ONLY option (fastscan-only) is not supported by this module"
#endif



/**************************************************************************
EXTERNAL GLOBAL VARIABLES
**************************************************************************/

// This structure holds all node specific configuration
extern MCO_CONFIG MEM_FAR gMCOConfig;

// Process Image
extern UNSIGNED8 MEM_PROC gProcImg[];


/**************************************************************************
PRIVATE VARIABLES
**************************************************************************/

typedef enum {
  LSSID_IND_VENDORID = 0,
  LSSID_IND_PRODCODE,
  LSSID_IND_REVNUM,
  LSSID_IND_SERNUM
} LSSID_INDEX;

static struct {
  UNSIGNED32 lss_id[4];        // contains the 1018h Object, the LSSID
  UNSIGNED8  active;           // TRUE if node is in LSS mode
  UNSIGNED8  operation_mode;   // Node is in operation mode. If not=>configuration
  UNSIGNED8  lss_state;        // In MicroLSS mode, shows which 32-bit part we
                               // are currently working on
  UNSIGNED8  new_node_id;      // New configured node ID
  UNSIGNED8  old_node_id;      // Original (pre-configured) node ID
  UNSIGNED8  new_node_bps;     // New configured baudrate
  UNSIGNED8  node_id_set;      // Flag to indicate if node ID is configured
  UNSIGNED8  confbt_mode;      // Node is in "Configure bit timing" mode
  UNSIGNED8  match_vid;        // Match of Vendor ID from "Switch Mode Selective" command
  UNSIGNED8  match_pid;        // Match of Product Code from "Switch Mode Selective" command
  UNSIGNED8  match_rev;        // Match of Revision Number from "Switch Mode Selective" command
  UNSIGNED8  idr_match_vid;    // Match of Vendor ID from "Identify Remote Slave" command
  UNSIGNED8  idr_match_pid;    // Match of Product Code from "Identify Remote Slave" command
  UNSIGNED32 idr_rev_lo;       // Low boundary of revision from "Identify Remote Slave" command
  UNSIGNED8  idr_match_rev_lo; // Match of Revision Number low boundary from "Identify Remote Slave" command
  UNSIGNED32 idr_rev_hi;       // High boundary of revision from "Identify Remote Slave" command
  UNSIGNED8  idr_match_rev_hi; // Match of Revision Number high boundary from "Identify Remote Slave" command
  UNSIGNED32 idr_ser_lo;       // Low boundary of serial from "Identify Remote Slave" command
  UNSIGNED8  idr_match_ser_lo; // Match of Serial Number low boundary from "Identify Remote Slave" command
  UNSIGNED16 actbt_sw_delay;   // Time in ms after which LSS switches the baudrate, and after which it is ready again
  UNSIGNED16 actbt_delay;      // Timestamp to switch or be ready to receive/transmit again
  UNSIGNED8  actbt_waitswitch; // If true, we wait until we can switch the baudrate
  UNSIGNED8  actbt_waitready;  // If true, we have swiched the baudrate and wait until we can send/receive again
} MEM_FAR mLSS;


// This structure holds the current transmit message
static CAN_MSG MEM_BUF mTxCAN;


/*******************************************************************************
PRIVATE FUNCTIONS
*******************************************************************************/

static UNSIGNED32 LSS_GetDword (UNSIGNED8 *pDat);
static void LSS_PutDword (UNSIGNED32 lvalue,UNSIGNED8 *pDat);
static void LSS_ResetInquireRemoteSlave(void);
static void LSS_FeedBackResponse (UNSIGNED8 BitChecked,UNSIGNED8 LSSNext);
static UNSIGNED8 LSS_SwitchModeGlobal (UNSIGNED8 *pDat);
static void LSS_ConfigureNodeID (UNSIGNED8 *pDat);
static void LSS_ConfigureBitTiming (UNSIGNED8 *pDat);
static void LSS_ActivateBitTiming (UNSIGNED8 *pDat);
static void LSS_StoreConfiguration(void);
static void LSS_InquireIdentity (UNSIGNED8 *pDat);
static void LSS_InquireNodeID (void);
static void LSS_IdentifyRemoteSlaves (UNSIGNED8 *pDat);
static void LSS_ResetSwitchMode(void);
static void LSS_IdentifyNonconfigRemoteSlaves(void);
static void LSS_SwitchModeSelective (UNSIGNED8 *pDat);


/****************************************************************
DOES:    Extracts dword in CANopen byte order from memory location
RETURNS: UNSIGNED32
*****************************************************************/
static UNSIGNED32 LSS_GetDword (
  UNSIGNED8 *pDat
  )
{
  return GEN_RD32(pDat);
}


/****************************************************************
DOES:    Inserts dword in CANopen byte order into memory location
RETURNS: UNSIGNED32
*****************************************************************/
static void LSS_PutDword (
  UNSIGNED32 lvalue,
  UNSIGNED8 *pDat
  )
{
  GEN_WR32(pDat,lvalue);
  return;
}


/****************************************************************
DOES:    Initializes CAN buffer for LSS response, sets byte 0
RETURNS:
*****************************************************************/
static void LSS_InitResponse (
  UNSIGNED8 data0
  )
{
  UNSIGNED8 i;

  mTxCAN.ID      = LSS_SLAVE_ID;
  mTxCAN.LEN     = 8;
  mTxCAN.BUF[0]  = data0;
  for (i = 1; i < 8; i++)
  {
    mTxCAN.BUF[i] = 0;
  }

  return;
}


/****************************************************************
DOES:    Reset the control flags for the Identify Remote Slave commands
RETURNS:
*****************************************************************/
static void LSS_ResetInquireRemoteSlave(void)
{
  mLSS.idr_match_vid     = FALSE;
  mLSS.idr_match_pid     = FALSE;
  mLSS.idr_rev_lo        = 0xFFFFFFFFUL;
  mLSS.idr_match_rev_lo  = FALSE;
  mLSS.idr_rev_hi        = 0xFFFFFFFFUL;
  mLSS.idr_match_rev_hi  = FALSE;
  mLSS.idr_ser_lo        = 0xFFFFFFFFUL;
  mLSS.idr_match_ser_lo  = FALSE;
}


/****************************************************************
DOES:    Initializes CAN buffer for LSS response with feedback
RETURNS:
*****************************************************************/
static void LSS_FeedBackResponse (
  UNSIGNED8 BitChecked, // bit currently checked
  UNSIGNED8 LSSNext // ID step checked
  )
{
UNSIGNED32 feedback = (LSS_SLAVE_ID << 18);

  if ((BitChecked == 0x80) || (BitChecked == 0))
  { // respond with hi word
    feedback += (((mLSS.lss_id[LSSNext]) & 0xFFFF0000UL) >> 16);
  }
  else
  { // respond with low word, set toggle
    feedback += ((mLSS.lss_id[LSSNext]) & 0x0000FFFFUL) + 0x00010000UL;
  }
#if USE_29BIT_LSSFEEDBACK == 1
#ifdef __SIMULATION__
  SimDriver_printf(" [LSSfeedback:%08xh]\n",feedback & 0x0000FFFFUL);
#endif
  MCOHW_Push29Message(feedback);
#endif
}


/****************************************************************
DOES:    LSS Switch Mode Global Command
GLOBALS: Sets mLSS.active status flag to FALSE if end-of-LSS
RETURNS:
*****************************************************************/
static UNSIGNED8 LSS_SwitchModeGlobal (
  UNSIGNED8 *pDat
  )
{
UNSIGNED8 ret_val;

  ret_val = FALSE;

  LSS_ResetInquireRemoteSlave();

  if (pDat[1] == LSS_MODE_CONFIG)
  { // configuration mode
    mLSS.operation_mode = LSS_MODE_CONFIG;

    if (MY_NMT_STATE != NMTSTATE_LSS)
    {
      MY_NMT_STATE = NMTSTATE_LSS;
      mLSS.active = TRUE;
    }
  }
  else if (pDat[1] == LSS_MODE_OPERATION)
  { // configuration mode
    LSS_ResetSwitchMode();

    mLSS.operation_mode = LSS_MODE_OPERATION;

    // If a node is configured, a switch back into operation mode
    // means the node leaves LSS and initializes into CANopen NMT
    if (mLSS.node_id_set)
    {
      // Set module-internal LSS status to leave mLSS. The next call
      // of LSS_Do_LSS() will then re-initialize the node with LSS
      // parameters.
      mLSS.active = FALSE;

      ret_val = TRUE;
    }
  }
  else if (pDat[1] == LSS_MODE_PASSIVE)
  { // passive mode
    if (mLSS.operation_mode == LSS_MODE_CONFIG)
    { // only allow switch to passive when in config mode
      mLSS.operation_mode = LSS_MODE_PASSIVE;
      
      ret_val = TRUE;
    }
  }
  else
  { // unknown mode value
    // ??? !!!
  }
  return ret_val;
}


/****************************************************************
DOES:    LSS Configure Node ID Command
RETURNS: -
*****************************************************************/
static void LSS_ConfigureNodeID (
  UNSIGNED8 *pDat
  )
{
UNSIGNED8 node_id;

  // This command is only accepted in configuration mode but
  // outside of "configure bit timing"!
  if ((mLSS.operation_mode == LSS_MODE_CONFIG) && !(mLSS.confbt_mode))
  {
    // Prepare answer
    LSS_InitResponse(LSS_CONF_NID);

    node_id = *(pDat+1);  // Byte 1 in message is node id

    if (IS_NODE_ID_VALID(node_id))
    {
      mTxCAN.BUF[1] = 0;  // Node ID accepted

      mLSS.new_node_id = node_id;
      mLSS.node_id_set = TRUE;

      MY_NODE_ID = node_id;

      // Memorize this as old node ID for inquiry command
      mLSS.old_node_id = node_id;
    }
    else
    {
      mTxCAN.BUF[1] = 1;  // Node ID out of range

#if USE_STORE_PARAMETERS
      // Get offsets
      MCOSP_GetNVOLUsage(nvol_offsets);
      // Erase all current settings
      NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSNID,0xFF);
      NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSBPS,0xFF);
      NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSENA,0xFF);
      NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSCHK,0xFF);
      // No further consecutive writes after this
      NVOL_WriteComplete();
#endif // USE_STORE_PARAMETERS
      // start over
      LSS_Init(0);
    }

#ifdef __SIMULATION__
    SimDriver_printf("\nNode ID assigned by LSS: %d",MY_NODE_ID);
#endif

    // Sending message
    if (!MCOHW_PushMessage(&mTxCAN))
    {
      MCOUSER_FatalError(0x0602);
    }
  }

  return;
}


/****************************************************************
DOES:    LSS Configure Bit Timing Command
RETURNS: -
*****************************************************************/
static void LSS_ConfigureBitTiming (
  UNSIGNED8 *pDat
  )
{
  // This command is only accepted in configuration mode
  if (mLSS.operation_mode == LSS_MODE_CONFIG)
  {
    LSS_InitResponse(LSS_CONF_BIT);

    if (CAN_BITRATE_SUPPORTED & (1U << pDat[2]))
    { // => bit timing supported
      mLSS.new_node_bps = pDat[2];  // Set new baudrate
      mLSS.confbt_mode  = TRUE;     // Configure bit timing mode is active
    }
    else
    { // => bit timing not supported
      mTxCAN.BUF[1] = 1;
      mLSS.confbt_mode  = FALSE;    // Configure bit timing mode is not active
    }

    mLSS.actbt_waitswitch = FALSE;
    mLSS.actbt_waitready  = FALSE;

    // Sending message
    if (!MCOHW_PushMessage(&mTxCAN))
    {
      MCOUSER_FatalError(0x0602);
    }
  }

  return;
}


/****************************************************************
DOES:    LSS Activate Bit Timing Command
RETURNS: -
*****************************************************************/
static void LSS_ActivateBitTiming (
  UNSIGNED8 *pDat
  )
{
  // This command is only accepted in configure bit timing mode
  if (mLSS.confbt_mode)
  {
    pDat++;   // Point to switch delay LSB
    mLSS.actbt_sw_delay  = *pDat++;
    mLSS.actbt_sw_delay |= (*pDat << 8);

    mLSS.actbt_waitswitch = TRUE;
    mLSS.actbt_waitready  = FALSE;

    // Calculate the timestamp to switch
    mLSS.actbt_delay = MCOHW_GetTime() + mLSS.actbt_sw_delay;
  }

  return;
}


/****************************************************************
DOES:    LSS Store Configuration Command
RETURNS: -
*****************************************************************/
static void LSS_StoreConfiguration(void)
{
#if USE_STORE_PARAMETERS
UNSIGNED8 lss_chk;
#endif

  // This command is only accepted in configuration mode
  if (mLSS.operation_mode == LSS_MODE_CONFIG)
  {
    LSS_InitResponse(LSS_STOR_CONF);

#if USE_STORE_PARAMETERS

    // Get offsets
    MCOSP_GetNVOLUsage(nvol_offsets);
    // Build checksum
    lss_chk = 0;
    lss_chk -= mLSS.new_node_id;
    lss_chk -= mLSS.new_node_bps;
    lss_chk -= NVOL_LSSENA_VAL;

    // Write data
    NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSNID,mLSS.new_node_id);
    NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSBPS,mLSS.new_node_bps);
    NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSENA,NVOL_LSSENA_VAL);
    NVOL_WriteByte(nvol_offsets[0]+NVOL_LSSCHK,lss_chk);
    NVOL_WriteComplete();

    // Verify
    if ( (NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSNID) != mLSS.new_node_id)  ||
         (NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSBPS) != mLSS.new_node_bps) ||
         (NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSENA) != NVOL_LSSENA_VAL)   ||
         (NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSCHK) != lss_chk)
       )
    {
      // Storage media access error
      mTxCAN.BUF[1] = 0x02;
    }

#else // USE_STORE_PARAMETERS

    // If NVOL configuration storage not supported, respond
    // with "not supported"
    mTxCAN.BUF[1] = 0x01;

#endif // USE_STORE_PARAMETERS

    // Sending response
    if (!MCOHW_PushMessage(&mTxCAN))
    {
      MCOUSER_FatalError(0x0602);
    }
  }

  return;
}


/****************************************************************
DOES:    LSS Inquire Identity Commands
RETURNS: -
*****************************************************************/
static void LSS_InquireIdentity (
  UNSIGNED8 *pDat
  )
{
  UNSIGNED32 lvalue;  // dword for response

  // These commands are only accepted in configuration mode but
  // outside of "configure bit timing"!
  if ((mLSS.operation_mode == LSS_MODE_CONFIG) && !(mLSS.confbt_mode))
  {
    switch (*pDat)
    {
      case LSS_INQ_VID:
        lvalue = mLSS.lss_id[LSSID_IND_VENDORID];
        break;
      case LSS_INQ_PID:
        lvalue = mLSS.lss_id[LSSID_IND_PRODCODE];
        break;
      case LSS_INQ_REV:
        lvalue = mLSS.lss_id[LSSID_IND_REVNUM];
        break;
      case LSS_INQ_SER:
        lvalue = mLSS.lss_id[LSSID_IND_SERNUM];
        break;
      default:
        lvalue = 0L;
        break;
    }

    LSS_InitResponse(*pDat);

    // store 32-bit value in CAN message bytes 1-4
    LSS_PutDword(lvalue,&mTxCAN.BUF[1]);

    // Sending message
    if (!MCOHW_PushMessage(&mTxCAN))
    {
      MCOUSER_FatalError(0x0602);
    }
  }

  return;
}


/****************************************************************
DOES:    LSS Inquire Node ID Command
RETURNS: -
*****************************************************************/
static void LSS_InquireNodeID (void)
{
  // This command is only accepted in configuration mode but
  // outside of "configure bit timing"!
  if ((mLSS.operation_mode == LSS_MODE_CONFIG) && !(mLSS.confbt_mode))
  {
    LSS_InitResponse(LSS_INQ_NID);

    // Respond with the original (not LSS-configured) Node ID
    mTxCAN.BUF[1] = mLSS.old_node_id;

    // Sending message
    if (!MCOHW_PushMessage(&mTxCAN))
    {
      MCOUSER_FatalError(0x0602);
    }
  }

  return;
}


/****************************************************************
DOES:    LSS Identify Remote Slaves Commands
RETURNS: -
*****************************************************************/
static void LSS_IdentifyRemoteSlaves (
  UNSIGNED8 *pDat
  )
{
// Values received in MicroLSS Master Message
UNSIGNED32 IDNumber;    // current LSS_ID Subindex IDnumber (32bit)
UNSIGNED8  BitChecked;  // current bit requested 0..31 (0x80 for init/restart)
UNSIGNED8  LSSSub;      // current LSS_ID subindex 0..3 (vendor,product,rev,serial)
UNSIGNED8  LSSNext;     // next state for the MicroLSS states

UNSIGNED32 mask;        // compare mask
UNSIGNED8 found;        // return value

  // These commands are accepted in either operation and configuration mode
  // but outside of "configure bit timing"!
  if (!mLSS.confbt_mode)
  {
    // Initialize variables
    mask = 0;
    found = 0;

    // extract 32-bit value from CAN message bytes 1-4
    IDNumber = LSS_GetDword(pDat+1);
    BitChecked = pDat[5]; // 0..31
    LSSSub = pDat[6]; // 0..3
    LSSNext = pDat[7];

    switch (*pDat)
    {
      case LSS_MICROLSS:
        found = 0;
        if (BitChecked & 0x80)
        { // MicroLSS initialization
          found = 1;
          mLSS.lss_state = 0;
          LSS_FeedBackResponse(BitChecked,LSSNext);
        }
        else if (LSSSub == mLSS.lss_state)
        { // we are still "on go" for the next 32bit value
          mask = 0xFFFFFFFF << BitChecked;
          if ((mLSS.lss_id[LSSSub] & mask) == (IDNumber & mask))
          { // match
            if ((BitChecked == 0x10) || (BitChecked == 0))
            {
              if (LSSNext < 4)
              {
                LSS_FeedBackResponse(BitChecked,LSSNext);
              }
            }
            found = 1;
            // Set new state as commanded by MicroLSS master
            mLSS.lss_state = LSSNext;
            if (BitChecked == 0)
            { // 32bit scan completed with success
              if (LSSSub == 3)
              { // All done and matched, scan completed, NODE IDENTIFIED
                // Switch node to configuration mode now!
                mLSS.operation_mode = LSS_MODE_CONFIG;
                mLSS.active = TRUE;
                MY_NMT_STATE = NMTSTATE_LSS;
              }
            }
          }
        }

        if (found == 1)
        { // Send a response as long as found
          // Send confirmation
          LSS_InitResponse(LSS_ID_SLAVE);
          // Sending message
          if (!MCOHW_PushMessage(&mTxCAN))
          {
            MCOUSER_FatalError(0x0602);
          }
        }

      case LSS_REQID_VID:
        if (IDNumber == OD_VENDOR_ID)
        {
          mLSS.idr_match_vid = TRUE;
        }
        else
        {
          LSS_ResetInquireRemoteSlave();
        }
        break;

      case LSS_REQID_PID:
        if ( mLSS.idr_match_vid  &&
            (IDNumber == OD_PRODUCT_CODE) )
        {
          mLSS.idr_match_pid = TRUE;
        }
        else
        {
          LSS_ResetInquireRemoteSlave();
        }
        break;

      case LSS_REQID_REV_LO:
        if ( mLSS.idr_match_vid && mLSS.idr_match_pid &&
            (IDNumber <= OD_REVISION) )
        {
          mLSS.idr_match_rev_lo = TRUE;
        }
        else
        {
          LSS_ResetInquireRemoteSlave();
        }
        break;

      case LSS_REQID_REV_HI:
        if ( mLSS.idr_match_vid     && mLSS.idr_match_pid &&
             mLSS.idr_match_rev_lo  &&
            ((IDNumber > OD_REVISION) || (IDNumber == OD_REVISION)) )
        {
          mLSS.idr_match_rev_hi = TRUE;
        }
        else
        {
          LSS_ResetInquireRemoteSlave();
        }
        break;

      case LSS_REQID_SER_LO:
        if ( mLSS.idr_match_vid     && mLSS.idr_match_pid    &&
             mLSS.idr_match_rev_lo  && mLSS.idr_match_rev_hi &&
            (IDNumber <= mLSS.lss_id[LSSID_IND_SERNUM]) )
        {
          mLSS.idr_match_ser_lo = TRUE;
        }
        else
        {
          LSS_ResetInquireRemoteSlave();
        }
        break;

      case LSS_REQID_SER_HI:
        if ( mLSS.idr_match_vid     && mLSS.idr_match_pid    &&
             mLSS.idr_match_rev_lo  && mLSS.idr_match_rev_hi &&
             mLSS.idr_match_ser_lo  &&
            (IDNumber >= mLSS.lss_id[LSSID_IND_SERNUM]) )
        {
          // Send confirmation
          LSS_InitResponse(LSS_ID_SLAVE);
          // Sending message
          if (!MCOHW_PushMessage(&mTxCAN))
          {
            MCOUSER_FatalError(0x0602);
          }
        }
        else
        {
          LSS_ResetInquireRemoteSlave();
        }

      default:
        break;
    }
  }

  return;
}


/****************************************************************
DOES:    Reset the control flags for the Switch Mode Selective commands
RETURNS:
*****************************************************************/
static void LSS_ResetSwitchMode(void)
{
  mLSS.match_vid      = FALSE;
  mLSS.match_pid      = FALSE;
  mLSS.match_rev      = FALSE;
  // go back to operation, even in case we were in config mode
  mLSS.operation_mode = LSS_MODE_OPERATION; 

  return;
}


/****************************************************************
DOES:    LSS Identify Non-configured Remote Slaves
RETURNS: -
*****************************************************************/
static void LSS_IdentifyNonconfigRemoteSlaves(void)
{
  // This command is accepted in either operation and configuration mode
  // if we are still unconfigured but outside of "configure bit timing"!
  if (!mLSS.node_id_set && !mLSS.confbt_mode)
  {
    // Send confirmation
    LSS_InitResponse(LSS_ID_NCONF_SLAVE);
    // Sending message
    if (!MCOHW_PushMessage(&mTxCAN))
    {
      MCOUSER_FatalError(0x0602);
    }
    // Force operation mode, to deal with faulty LSS master implementation or when
    // the switch global message is not received for whatever reason.
    // Not part of CiA 305.
    LSS_ResetSwitchMode();
  }

  return;
}


/****************************************************************
DOES:    LSS Switch Mode Selective Commands
RETURNS: -
*****************************************************************/
static void LSS_SwitchModeSelective (
  UNSIGNED8 *pDat
  )
{
  UNSIGNED32 lvalue;  // dword to compare
  UNSIGNED8  command; // Command Specifier Byte

  // These commands are only accepted in operation mode but
  // outside of "configure bit timing"!
  if ((mLSS.operation_mode == LSS_MODE_CONFIG) || (mLSS.confbt_mode))
  {
    LSS_ResetSwitchMode();
  }
  else
  {
    command = *pDat++;

    // extract 32-bit value from CAN message bytes 1-4
    lvalue = LSS_GetDword(pDat);

    switch (command)
    {
      case LSS_SWMOD_VID:
        if (lvalue == mLSS.lss_id[LSSID_IND_VENDORID])
        {
          mLSS.match_vid = TRUE;
        }
        else
        {
          LSS_ResetSwitchMode();
        }
        break;

      case LSS_SWMOD_PID:
        if ( mLSS.match_vid  &&
            (lvalue == mLSS.lss_id[LSSID_IND_PRODCODE]) )
        {
          mLSS.match_pid = TRUE;
        }
        else
        {
          LSS_ResetSwitchMode();
        }
        break;

      case LSS_SWMOD_REV:
        if ( mLSS.match_vid && mLSS.match_pid &&
            (lvalue == mLSS.lss_id[LSSID_IND_REVNUM]) )
        {
          mLSS.match_rev = TRUE;
        }
        else
        {
          LSS_ResetSwitchMode();
        }
        break;

      case LSS_SWMOD_SER:
        if ( mLSS.match_vid && mLSS.match_pid && mLSS.match_rev &&
            (lvalue == mLSS.lss_id[LSSID_IND_SERNUM]) )
        {
          // Send confirmation
          LSS_InitResponse(LSS_SWMOD_RESP);
          // Sending message
          if (!MCOHW_PushMessage(&mTxCAN))
          {
            MCOUSER_FatalError(0x0602);
          }

          // This node is in configuration mode now!
          mLSS.operation_mode = LSS_MODE_CONFIG;

          if (MY_NMT_STATE != NMTSTATE_LSS)
          {
            MY_NMT_STATE = NMTSTATE_LSS;
            mLSS.active = TRUE;
          }
        }
        else
        {
          LSS_ResetSwitchMode();
        }

      default:
        break;
    }
  }

  return;
}


/*******************************************************************************
GLOBAL FUNCTIONS
*******************************************************************************/

/****************************************************************
DOES:    Process all LSS messages.
RETURNS:
*****************************************************************/
void LSS_HandleMsg (
  UNSIGNED8 Len,
  UNSIGNED8 *pDat
  )
{
  // After "Activate Bit Timing Parameter" command, don't execute
  // any commands for the time of 2*mLSS.actbt_sw_delay (ms) => LSS_Do_LSS()
  // Allow LSS commands only in pure-LSS and stopped mode
  if ( !(mLSS.actbt_waitswitch) && !(mLSS.actbt_waitready) &&
       ( (MY_NMT_STATE == NMTSTATE_LSS) ||
         (MY_NMT_STATE == NMTSTATE_STOP) ) )
  {
    if (Len == 8)   // must be 8 bytes long!
    {      
      switch (*pDat)
      {
        case LSS_SWMOD_GLOB:
          LSS_SwitchModeGlobal(pDat);
          break;

        case LSS_SWMOD_VID:
        case LSS_SWMOD_PID:
        case LSS_SWMOD_REV:
        case LSS_SWMOD_SER:
          LSS_SwitchModeSelective(pDat);
          break;

        case LSS_CONF_NID:
            LSS_ConfigureNodeID(pDat);
          break;

        case LSS_CONF_BIT:
            LSS_ConfigureBitTiming(pDat);
          break;
        case LSS_ACT_BIT:
            LSS_ActivateBitTiming(pDat);
          break;
        case LSS_STOR_CONF:
            LSS_StoreConfiguration();
          break;

        case LSS_MICROLSS:
            LSS_IdentifyRemoteSlaves(pDat);
          break;

        case LSS_INQ_VID:
        case LSS_INQ_PID:
        case LSS_INQ_REV:
        case LSS_INQ_SER:
            LSS_InquireIdentity(pDat);
          break;

        case LSS_INQ_NID:
            LSS_InquireNodeID();
          break;

        case LSS_REQID_VID:
        case LSS_REQID_PID:
        case LSS_REQID_REV_LO:
        case LSS_REQID_REV_HI:
        case LSS_REQID_SER_LO:
        case LSS_REQID_SER_HI:
            LSS_IdentifyRemoteSlaves(pDat);
          break;

        case LSS_REQID_NCONF:
            LSS_IdentifyNonconfigRemoteSlaves();
          break;

        default:
          break;
      }
    }
  }

  return;
}


/****************************************************************
DOES:    Check and update LSS status
RETURNS: FALSE: LSS is finished for this node
         TRUE:  Otherwise (LSS is still in process)
*****************************************************************/
UNSIGNED8 LSS_DoLSS(void)
{
UNSIGNED8 ret_val;

  ret_val = TRUE;

  if (mLSS.active)
  {
#if USE_LEDS
    if (MY_NMT_STATE != NMTSTATE_STOP)
    { // in stopped mode, still show blinking pattern for stopped,
      // else if LEDs are used, toggle all 50ms
      if (MCOHW_IsTimeExpired(gMCOConfig.LED_timestamp))
      {
        if (gMCOConfig.LED_timestamp & 1)
        {
          LED_RUN_ON;
          LED_ERR_OFF;
          gMCOConfig.LED_timestamp = (MCOHW_GetTime() + 50) & 0xFFFE;
        }
        else
        {
          LED_RUN_OFF;
          LED_ERR_ON;
          gMCOConfig.LED_timestamp = (MCOHW_GetTime() + 50) | 0x0001;
        }
      }
    }
#endif //USE_LEDS
  }
  else
  {
    // Has LSS just been finished?
    if (MY_NMT_STATE == NMTSTATE_LSS)
    {

#if USE_LEDS
      LED_RUN_OFF;
      LED_ERR_OFF;
#endif // USE_LEDS

      // Re-init
      // apply new node ID NOW
      MY_NODE_ID = mLSS.new_node_id;
      MCOUSER_ResetCommunication();
    }

    ret_val = FALSE;
  }

  // After "Activate Bit Timing" command, wait until we can actually
  // switch the baudrate
  if (mLSS.actbt_waitswitch && ret_val)
  {
    if (MCOHW_IsTimeExpired(mLSS.actbt_delay))
    {
      // Calculate the timestamp to be ready to receive/transmit again
      mLSS.actbt_delay = MCOHW_GetTime() + mLSS.actbt_sw_delay;

      // Set baudrate for CANopen stack
      switch(mLSS.new_node_bps)
      {
      case LSS_BPS_1000:
        gMCOConfig.Baudrate = 1000;
        break;
      case LSS_BPS_800:
        gMCOConfig.Baudrate = 800;
        break;
      case LSS_BPS_500:
        gMCOConfig.Baudrate = 500;
        break;
      case LSS_BPS_250:
        gMCOConfig.Baudrate = 250;
        break;
      case LSS_BPS_125:
       default:
        gMCOConfig.Baudrate = 125;
        break;
      case LSS_BPS_50:
        gMCOConfig.Baudrate = 50;
        break;
      case LSS_BPS_20:
        gMCOConfig.Baudrate = 20;
        break;
      case LSS_BPS_10:
        gMCOConfig.Baudrate = 10;
        break;
      }

      // Reset CAN controller, set new baudrate
      MCOHW_Init(gMCOConfig.Baudrate);

      // Set receive filter for LSS master message
      if (!MCOHW_SetCANFilter(LSS_MASTER_ID))
      {
        MCOUSER_FatalError(0x0601);
      }

       // We are no longer in "configure bit timing" mode
      mLSS.confbt_mode      = FALSE;

      mLSS.actbt_waitswitch = FALSE;
      mLSS.actbt_waitready  = TRUE;
    }
  }

  // After the baudrate has changed, wait until we are ready to receive/
  // transmit again
  if (mLSS.actbt_waitready)
  {
    if (MCOHW_IsTimeExpired(mLSS.actbt_delay))
    {
      mLSS.actbt_waitready = FALSE;
    }
  }

  return ret_val;
}


/****************************************************************
DOES:    Gets the LSS ID that LSS_Init() determined.
         Call after LSS_Init().
RETURNS: LSS ID in passed array - has to be writable.
*****************************************************************/
void LSS_GetLSSID(
  UNSIGNED32 lssid[4]
)
{
LSSID_INDEX lp;
  
  for(lp = LSSID_IND_VENDORID; lp <= LSSID_IND_SERNUM; lp++)
  {
    lssid[lp] = mLSS.lss_id[lp];
  }
}


/****************************************************************
DOES:    Sets the LSS ID. Use, if LSS ID is not hard coded and
         does not come from process image locations.
         Call after LSS_Init() and before LSS processing starts.
RETURNS: nothing
*****************************************************************/
void LSS_SetLSSID(
  UNSIGNED32 lssid[4]
)
{
LSSID_INDEX lp;
  
  for(lp = LSSID_IND_VENDORID; lp <= LSSID_IND_SERNUM; lp++)
  {
    mLSS.lss_id[lp] = lssid[lp];
  }
}


/****************************************************************
DOES:    Initialize LSS mechanism (variables etc.)
GLOBALS: Sets mLSS.active status flag to TRUE
         Sets gMCOConfig.nmt_state to NMTSTATE_LSS if there is
         no node ID set.
RETURNS: -
*****************************************************************/
void LSS_Init(
  UNSIGNED8 node_id
  )
{
UNSIGNED8 i;
UNSIGNED16 offset;  // offset into process image

  LSS_ResetSwitchMode();
  LSS_ResetInquireRemoteSlave();

  mLSS.lss_id[LSSID_IND_VENDORID] = OD_VENDOR_ID;
  mLSS.lss_id[LSSID_IND_PRODCODE] = OD_PRODUCT_CODE;
  mLSS.lss_id[LSSID_IND_REVNUM] = OD_REVISION;
#if USECB_ODSERIAL
  mLSS.lss_id[LSSID_IND_SERNUM] = MCOUSER_GetSerial();
#else
  mLSS.lss_id[LSSID_IND_SERNUM] = OD_SERIAL;
#endif
  for (i=LSSID_IND_VENDORID; i<=LSSID_IND_SERNUM; i++)
  { // if data is in process image, take from there
    offset = OD_GetPIEntryOffset(0x1018,i+1);
    if (offset != 0xFFFF)
    {
      PI_READ(PIACC_APP,offset,&(mLSS.lss_id[i]),4);
    }
  }
  
  // Init LSS state machine
  mLSS.lss_state = 0;

  // The Node ID is not yet set
  mLSS.node_id_set    = FALSE;

  // After reset, the node is in operation mode
  mLSS.operation_mode = LSS_MODE_OPERATION;

  // After reset, the node is not in "configure bit timing" mode
  mLSS.confbt_mode    = FALSE;

  // Pre-set LSS baudrate and node ID to default values
  mLSS.new_node_bps   = LSS_BPS_125; // 125kbps
  mLSS.new_node_id    = node_id;

  // Memorize the old node ID for inquiry command
  mLSS.old_node_id    = node_id;

  if (node_id == 0)
  { // No node ID, remain in LSS mode
    MY_NMT_STATE = NMTSTATE_LSS;
    mLSS.active = TRUE;
  }

  return;
}

#endif


// Allow use of the functions below that apply to NVOL configuration of node ID and bitrate
// also when LSS is not otherwise enabled.

#if !defined(NLSSLOADCONF)
/****************************************************************
DOES:    LSS Load Configuration Command
RETURNS: -
*****************************************************************/
void LSS_LoadConfiguration (
  UNSIGNED16 *Baudrate,  // returns CAN baudrate in kbit
  UNSIGNED8 *Node_ID    // returns CANopen node ID (0-127)
  )
{
#if USE_STORE_PARAMETERS
UNSIGNED8 cfg[4];
#endif

  // only read configuration if node id is unknown, otherwise return current config
  if (MY_NODE_ID != 0)
  { 
    *Baudrate = gMCOConfig.Baudrate;
    *Node_ID = MY_NODE_ID;
  }
  else
  {
#if USE_STORE_PARAMETERS
    // Initialize access to non-volatile memory
    NVOL_Init();

    // Get offsets
    MCOSP_GetNVOLUsage(nvol_offsets);
    
    // Read record
    cfg[NVOL_LSSNID] = NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSNID);
    cfg[NVOL_LSSBPS] = NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSBPS);
    cfg[NVOL_LSSENA] = NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSENA);
    cfg[NVOL_LSSCHK] = NVOL_ReadByte(nvol_offsets[0]+NVOL_LSSCHK);
    
    // Record OK?
    if (LSS_CheckConfiguration(cfg))
    { // data ok

      if (cfg[NVOL_LSSENA] == NVOL_LSSENA_VAL)
      {
        *Node_ID = cfg[NVOL_LSSNID];
      }
      else
      {
        *Node_ID = 0;
      }
      switch(cfg[NVOL_LSSBPS])
      {
      case LSS_BPS_1000:
        *Baudrate = 1000;
        break;
      case LSS_BPS_800:
        *Baudrate = 800;
        break;
      case LSS_BPS_500:
        *Baudrate = 500;
        break;
      case LSS_BPS_250:
        *Baudrate = 250;
        break;
      case LSS_BPS_125:
      default:
        *Baudrate = 125;
        break;
      case LSS_BPS_50:
        *Baudrate = 50;
        break;
      case LSS_BPS_20:
        *Baudrate = 20;
        break;
      case LSS_BPS_10:
        *Baudrate = 10;
        break;
      }
      return;
    }
    else
    {
      *Baudrate = 125;
      *Node_ID = 0;
    }
#else // USE_STORE_PARAMETERS
    *Baudrate = 0;
    *Node_ID = 0;
#endif // USE_STORE_PARAMETERS
  }

  return;
}
#endif


/****************************************************************
DOES:    Verifies a 4-byte configuration record
         from NVOL_LSSNID to NVOL_LSSCHK for plausible values
RETURNS: TRUE, if configuration is valid
*****************************************************************/
UNSIGNED8 LSS_CheckConfiguration (
  UNSIGNED8 cfg[4]
)
{
UNSIGNED8 chk;
UNSIGNED8 ret_val = FALSE;
  
  // Build checksum
  chk = 0;
  chk -= cfg[NVOL_LSSNID];
  chk -= cfg[NVOL_LSSBPS];
  chk -= cfg[NVOL_LSSENA];
  
  if (chk == cfg[NVOL_LSSCHK])
  { // Checksum OK
    if ( ( ((cfg[NVOL_LSSNID] > 0) && (cfg[NVOL_LSSNID] < 128)) || (cfg[NVOL_LSSNID] == 0xFF) ) && 
         ((cfg[NVOL_LSSBPS] <= LSS_BPS_10) || (cfg[NVOL_LSSBPS] == 0xFF)) &&
         ((cfg[NVOL_LSSENA] == NVOL_LSSENA_VAL) || (cfg[NVOL_LSSENA] == NVOL_DOLSS_VAL))
       )
    { // Plausability checks ok
      ret_val = TRUE;
    }
  }

return ret_val;
}

/*******************************************************************************
END OF FILE
*******************************************************************************/
